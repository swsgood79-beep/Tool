# main.tray @ 0x14079a920
   14079a920:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   14079a924:	0f 86 b5 01 00 00    	jbe    0x14079aadf
   14079a92a:	55                   	push   %rbp
   14079a92b:	48 89 e5             	mov    %rsp,%rbp
   14079a92e:	48 83 ec 40          	sub    $0x40,%rsp
   14079a932:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   14079a937:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   14079a93c:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   14079a941:	48 8d 05 98 00 c6 00 	lea    0xc60098(%rip),%rax        # 0x1413fa9e0
   14079a948:	e8 b3 74 88 ff       	call   0x140021e00
   14079a94d:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   14079a952:	48 8b 0d 17 ab 2f 04 	mov    0x42fab17(%rip),%rcx        # 0x144a95470
   14079a959:	48 89 c2             	mov    %rax,%rdx
   14079a95c:	bb 0f 00 00 00       	mov    $0xf,%ebx
   14079a961:	44 0f 11 38          	movups %xmm15,(%rax)
   14079a965:	44 0f 11 78 10       	movups %xmm15,0x10(%rax)
   14079a96a:	44 0f 11 78 20       	movups %xmm15,0x20(%rax)
   14079a96f:	44 0f 11 78 30       	movups %xmm15,0x30(%rax)
   14079a974:	48 83 c0 40          	add    $0x40,%rax
   14079a978:	ff cb                	dec    %ebx
   14079a97a:	75 e5                	jne    0x14079a961
   14079a97c:	44 0f 11 38          	movups %xmm15,(%rax)
   14079a980:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
   14079a984:	c7 42 10 01 00 00 00 	movl   $0x1,0x10(%rdx)
   14079a98b:	48 b9 07 00 00 00 02 	movabs $0x800200000007,%rcx
   14079a992:	80 00 00 
   14079a995:	48 89 4a 14          	mov    %rcx,0x14(%rdx)
   14079a999:	c7 02 d0 03 00 00    	movl   $0x3d0,(%rdx)
   14079a99f:	b8 10 00 00 00       	mov    $0x10,%eax
   14079a9a4:	48 8d 1d 9d 3e b2 00 	lea    0xb23e9d(%rip),%rbx        # 0x1412be848
   14079a9ab:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079a9b0:	e8 ab 96 88 ff       	call   0x140024060
   14079a9b5:	48 c7 40 08 04 7f 00 	movq   $0x7f04,0x8(%rax)
   14079a9bc:	00 
   14079a9bd:	48 8b 0d 84 05 25 04 	mov    0x4250584(%rip),%rcx        # 0x1449eaf48
   14079a9c4:	48 8d 1d ee 01 0f 00 	lea    0xf01ee(%rip),%rbx        # 0x14088abb9
   14079a9cb:	48 89 c7             	mov    %rax,%rdi
   14079a9ce:	be 02 00 00 00       	mov    $0x2,%esi
   14079a9d3:	41 89 f0             	mov    %esi,%r8d
   14079a9d6:	48 89 c8             	mov    %rcx,%rax
   14079a9d9:	b9 09 00 00 00       	mov    $0x9,%ecx
   14079a9de:	66 90                	xchg   %ax,%ax
   14079a9e0:	e8 bb ef ff ff       	call   0x1407999a0
   14079a9e5:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   14079a9ea:	48 89 41 20          	mov    %rax,0x20(%rcx)
   14079a9ee:	48 8d 41 28          	lea    0x28(%rcx),%rax
   14079a9f2:	bb 80 00 00 00       	mov    $0x80,%ebx
   14079a9f7:	89 d9                	mov    %ebx,%ecx
   14079a9f9:	48 8d 3d fa e1 12 00 	lea    0x12e1fa(%rip),%rdi        # 0x1408c8bfa
   14079aa00:	be 3e 00 00 00       	mov    $0x3e,%esi
   14079aa05:	e8 16 fe ff ff       	call   0x14079a820
   14079aa0a:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   14079aa0f:	48 85 c9             	test   %rcx,%rcx
   14079aa12:	74 55                	je     0x14079aa69
   14079aa14:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   14079aa19:	c7 40 14 10 00 00 00 	movl   $0x10,0x14(%rax)
   14079aa20:	c7 80 b4 03 00 00 01 	movl   $0x1,0x3b4(%rax)
   14079aa27:	00 00 00 
   14079aa2a:	48 05 34 03 00 00    	add    $0x334,%rax
   14079aa30:	bb 40 00 00 00       	mov    $0x40,%ebx
   14079aa35:	89 d9                	mov    %ebx,%ecx
   14079aa37:	48 8d 3d 18 1a 10 00 	lea    0x101a18(%rip),%rdi        # 0x14089c456
   14079aa3e:	be 14 00 00 00       	mov    $0x14,%esi
   14079aa43:	e8 d8 fd ff ff       	call   0x14079a820
   14079aa48:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   14079aa4d:	48 05 30 01 00 00    	add    $0x130,%rax
   14079aa53:	bb 00 01 00 00       	mov    $0x100,%ebx
   14079aa58:	89 d9                	mov    %ebx,%ecx
   14079aa5a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   14079aa5f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   14079aa64:	e8 b7 fd ff ff       	call   0x14079a820
   14079aa69:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   14079aa6e:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   14079aa73:	b8 10 00 00 00       	mov    $0x10,%eax
   14079aa78:	48 8d 1d c9 3d b2 00 	lea    0xb23dc9(%rip),%rbx        # 0x1412be848
   14079aa7f:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079aa84:	e8 d7 95 88 ff       	call   0x140024060
   14079aa89:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   14079aa8e:	48 89 10             	mov    %rdx,(%rax)
   14079aa91:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   14079aa96:	48 89 50 08          	mov    %rdx,0x8(%rax)
   14079aa9a:	48 8b 15 bf 04 25 04 	mov    0x42504bf(%rip),%rdx        # 0x1449eaf60
   14079aaa1:	48 8d 1d c8 ce 0f 00 	lea    0xfcec8(%rip),%rbx        # 0x140897970
   14079aaa8:	b9 11 00 00 00       	mov    $0x11,%ecx
   14079aaad:	48 89 c7             	mov    %rax,%rdi
   14079aab0:	be 02 00 00 00       	mov    $0x2,%esi
   14079aab5:	41 89 f0             	mov    %esi,%r8d
   14079aab8:	48 89 d0             	mov    %rdx,%rax
   14079aabb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079aac0:	e8 db ee ff ff       	call   0x1407999a0
   14079aac5:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   14079aaca:	48 85 d2             	test   %rdx,%rdx
   14079aacd:	75 0a                	jne    0x14079aad9
   14079aacf:	48 85 c0             	test   %rax,%rax
   14079aad2:	0f 95 05 6f a8 2f 04 	setne  0x42fa86f(%rip)        # 0x144a95348
   14079aad9:	48 83 c4 40          	add    $0x40,%rsp
   14079aadd:	5d                   	pop    %rbp
   14079aade:	c3                   	ret
   14079aadf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   14079aae4:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   14079aae9:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   14079aaee:	e8 4d 18 8f ff       	call   0x14008c340
   14079aaf3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   14079aaf8:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
   14079aafd:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   14079ab02:	e9 19 fe ff ff       	jmp    0x14079a920
   14079ab07:	cc                   	int3
   14079ab08:	cc                   	int3
   14079ab09:	cc                   	int3
   14079ab0a:	cc                   	int3
   14079ab0b:	cc                   	int3
   14079ab0c:	cc                   	int3
   14079ab0d:	cc                   	int3
   14079ab0e:	cc                   	int3
   14079ab0f:	cc                   	int3
   14079ab10:	cc                   	int3
   14079ab11:	cc                   	int3
   14079ab12:	cc                   	int3
   14079ab13:	cc                   	int3
   14079ab14:	cc                   	int3
   14079ab15:	cc                   	int3
   14079ab16:	cc                   	int3
   14079ab17:	cc                   	int3
   14079ab18:	cc                   	int3
   14079ab19:	cc                   	int3
   14079ab1a:	cc                   	int3
   14079ab1b:	cc                   	int3
   14079ab1c:	cc                   	int3
   14079ab1d:	cc                   	int3
   14079ab1e:	cc                   	int3
   14079ab1f:	cc                   	int3

# main.windowProc @ 0x14079ab20
   14079ab20:	4c 8d a4 24 e0 fe ff 	lea    -0x120(%rsp),%r12
   14079ab27:	ff 
   14079ab28:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   14079ab2c:	0f 86 cd 07 00 00    	jbe    0x14079b2ff
   14079ab32:	55                   	push   %rbp
   14079ab33:	48 89 e5             	mov    %rsp,%rbp
   14079ab36:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
   14079ab3d:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
   14079ab44:	00 
   14079ab45:	89 9c 24 b0 01 00 00 	mov    %ebx,0x1b0(%rsp)
   14079ab4c:	48 89 8c 24 b8 01 00 	mov    %rcx,0x1b8(%rsp)
   14079ab53:	00 
   14079ab54:	48 89 bc 24 c0 01 00 	mov    %rdi,0x1c0(%rsp)
   14079ab5b:	00 
   14079ab5c:	0f 1f 40 00          	nopl   0x0(%rax)
   14079ab60:	83 fb 2c             	cmp    $0x2c,%ebx
   14079ab63:	0f 86 c8 04 00 00    	jbe    0x14079b031
   14079ab69:	81 fb 38 01 00 00    	cmp    $0x138,%ebx
   14079ab6f:	0f 87 10 04 00 00    	ja     0x14079af85
   14079ab75:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   14079ab7c:	00 00 
   14079ab7e:	66 90                	xchg   %ax,%ax
   14079ab80:	81 fb 13 01 00 00    	cmp    $0x113,%ebx
   14079ab86:	0f 87 c9 03 00 00    	ja     0x14079af55
   14079ab8c:	81 fb 11 01 00 00    	cmp    $0x111,%ebx
   14079ab92:	0f 85 98 03 00 00    	jne    0x14079af30
   14079ab98:	0f b7 d1             	movzwl %cx,%edx
   14079ab9b:	48 83 c2 99          	add    $0xffffffffffffff99,%rdx
   14079ab9f:	90                   	nop
   14079aba0:	48 83 fa 09          	cmp    $0x9,%rdx
   14079aba4:	0f 87 7b 03 00 00    	ja     0x14079af25
   14079abaa:	48 8d 05 4f 72 44 00 	lea    0x44724f(%rip),%rax        # 0x140be1e00
   14079abb1:	ff 24 d0             	jmp    *(%rax,%rdx,8)
   14079abb4:	e8 67 5b ff ff       	call   0x140790720
   14079abb9:	e9 67 03 00 00       	jmp    0x14079af25
   14079abbe:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   14079abc3:	44 0f 11 3a          	movups %xmm15,(%rdx)
   14079abc7:	44 0f 11 7a 10       	movups %xmm15,0x10(%rdx)
   14079abcc:	44 0f 11 7a 20       	movups %xmm15,0x20(%rdx)
   14079abd1:	44 0f 11 7a 30       	movups %xmm15,0x30(%rdx)
   14079abd6:	44 0f 11 7a 40       	movups %xmm15,0x40(%rdx)
   14079abdb:	44 0f 11 7a 50       	movups %xmm15,0x50(%rdx)
   14079abe0:	44 0f 11 7a 60       	movups %xmm15,0x60(%rdx)
   14079abe5:	44 0f 11 7a 70       	movups %xmm15,0x70(%rdx)
   14079abea:	44 0f 11 ba 80 00 00 	movups %xmm15,0x80(%rdx)
   14079abf1:	00 
   14079abf2:	44 0f 11 ba 90 00 00 	movups %xmm15,0x90(%rdx)
   14079abf9:	00 
   14079abfa:	44 0f 11 ba 98 00 00 	movups %xmm15,0x98(%rdx)
   14079ac01:	00 
   14079ac02:	48 8d 35 57 e1 0e 00 	lea    0xee157(%rip),%rsi        # 0x140888d60
   14079ac09:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
   14079ac0e:	48 c7 84 24 80 00 00 	movq   $0x8,0x80(%rsp)
   14079ac15:	00 08 00 00 00 
   14079ac1a:	48 8d 35 a1 ff 0e 00 	lea    0xeffa1(%rip),%rsi        # 0x14088abc2
   14079ac21:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
   14079ac28:	00 
   14079ac29:	48 c7 84 24 a0 00 00 	movq   $0x9,0xa0(%rsp)
   14079ac30:	00 09 00 00 00 
   14079ac35:	48 8d 35 04 34 10 00 	lea    0x103404(%rip),%rsi        # 0x14089e040
   14079ac3c:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
   14079ac43:	00 
   14079ac44:	48 c7 84 24 b0 00 00 	movq   $0x15,0xb0(%rsp)
   14079ac4b:	00 15 00 00 00 
   14079ac50:	48 8d 35 70 4b 0f 00 	lea    0xf4b70(%rip),%rsi        # 0x14088f7c7
   14079ac57:	48 89 b4 24 b8 00 00 	mov    %rsi,0xb8(%rsp)
   14079ac5e:	00 
   14079ac5f:	48 c7 84 24 c0 00 00 	movq   $0xc,0xc0(%rsp)
   14079ac66:	00 0c 00 00 00 
   14079ac6b:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
   14079ac72:	00 
   14079ac73:	44 0f 11 38          	movups %xmm15,(%rax)
   14079ac77:	44 0f 11 78 10       	movups %xmm15,0x10(%rax)
   14079ac7c:	44 0f 11 78 20       	movups %xmm15,0x20(%rax)
   14079ac81:	44 0f 11 78 30       	movups %xmm15,0x30(%rax)
   14079ac86:	44 0f 11 78 40       	movups %xmm15,0x40(%rax)
   14079ac8b:	44 0f 11 78 50       	movups %xmm15,0x50(%rax)
   14079ac90:	44 0f 11 78 60       	movups %xmm15,0x60(%rax)
   14079ac95:	44 0f 11 78 70       	movups %xmm15,0x70(%rax)
   14079ac9a:	44 0f 11 b8 80 00 00 	movups %xmm15,0x80(%rax)
   14079aca1:	00 
   14079aca2:	44 0f 11 b8 90 00 00 	movups %xmm15,0x90(%rax)
   14079aca9:	00 
   14079acaa:	44 0f 11 b8 98 00 00 	movups %xmm15,0x98(%rax)
   14079acb1:	00 
   14079acb2:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   14079acb9:	00 
   14079acba:	44 0f 10 32          	movups (%rdx),%xmm14
   14079acbe:	44 0f 11 36          	movups %xmm14,(%rsi)
   14079acc2:	44 0f 10 72 10       	movups 0x10(%rdx),%xmm14
   14079acc7:	44 0f 11 76 10       	movups %xmm14,0x10(%rsi)
   14079accc:	44 0f 10 72 20       	movups 0x20(%rdx),%xmm14
   14079acd1:	44 0f 11 76 20       	movups %xmm14,0x20(%rsi)
   14079acd6:	44 0f 10 72 30       	movups 0x30(%rdx),%xmm14
   14079acdb:	44 0f 11 76 30       	movups %xmm14,0x30(%rsi)
   14079ace0:	44 0f 10 72 40       	movups 0x40(%rdx),%xmm14
   14079ace5:	44 0f 11 76 40       	movups %xmm14,0x40(%rsi)
   14079acea:	44 0f 10 72 50       	movups 0x50(%rdx),%xmm14
   14079acef:	44 0f 11 76 50       	movups %xmm14,0x50(%rsi)
   14079acf4:	44 0f 10 72 60       	movups 0x60(%rdx),%xmm14
   14079acf9:	44 0f 11 76 60       	movups %xmm14,0x60(%rsi)
   14079acfe:	44 0f 10 72 70       	movups 0x70(%rdx),%xmm14
   14079ad03:	44 0f 11 76 70       	movups %xmm14,0x70(%rsi)
   14079ad08:	44 0f 10 b2 80 00 00 	movups 0x80(%rdx),%xmm14
   14079ad0f:	00 
   14079ad10:	44 0f 11 b6 80 00 00 	movups %xmm14,0x80(%rsi)
   14079ad17:	00 
   14079ad18:	44 0f 10 b2 90 00 00 	movups 0x90(%rdx),%xmm14
   14079ad1f:	00 
   14079ad20:	44 0f 11 b6 90 00 00 	movups %xmm14,0x90(%rsi)
   14079ad27:	00 
   14079ad28:	44 0f 10 b2 98 00 00 	movups 0x98(%rdx),%xmm14
   14079ad2f:	00 
   14079ad30:	44 0f 11 b6 98 00 00 	movups %xmm14,0x98(%rsi)
   14079ad37:	00 
   14079ad38:	bb 01 00 00 00       	mov    $0x1,%ebx
   14079ad3d:	89 d9                	mov    %ebx,%ecx
   14079ad3f:	90                   	nop
   14079ad40:	e8 5b 0b 03 00       	call   0x1407cb8a0
   14079ad45:	e9 db 01 00 00       	jmp    0x14079af25
   14079ad4a:	e8 31 5e ff ff       	call   0x140790b80
   14079ad4f:	e9 d1 01 00 00       	jmp    0x14079af25
   14079ad54:	48 8d 05 b6 80 13 00 	lea    0x1380b6(%rip),%rax        # 0x1408d2e11
   14079ad5b:	bb 59 00 00 00       	mov    $0x59,%ebx
   14079ad60:	e8 bb eb ff ff       	call   0x140799920
   14079ad65:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   14079ad6c:	00 
   14079ad6d:	48 8d 05 24 04 12 00 	lea    0x120424(%rip),%rax        # 0x1408bb198
   14079ad74:	bb 2c 00 00 00       	mov    $0x2c,%ebx
   14079ad79:	e8 a2 eb ff ff       	call   0x140799920
   14079ad7e:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
   14079ad85:	00 
   14079ad86:	b8 20 00 00 00       	mov    $0x20,%eax
   14079ad8b:	48 8d 1d 4e 4b b2 00 	lea    0xb24b4e(%rip),%rbx        # 0x1412bf8e0
   14079ad92:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079ad97:	e8 84 97 88 ff       	call   0x140024520
   14079ad9c:	48 8b 0d cd a6 2f 04 	mov    0x42fa6cd(%rip),%rcx        # 0x144a95470
   14079ada3:	48 89 08             	mov    %rcx,(%rax)
   14079ada6:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   14079adad:	00 
   14079adae:	48 89 48 08          	mov    %rcx,0x8(%rax)
   14079adb2:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   14079adb9:	00 
   14079adba:	48 89 48 10          	mov    %rcx,0x10(%rax)
   14079adbe:	48 c7 40 18 24 00 00 	movq   $0x24,0x18(%rax)
   14079adc5:	00 
   14079adc6:	48 8b 0d 7b 01 25 04 	mov    0x425017b(%rip),%rcx        # 0x1449eaf48
   14079adcd:	48 8d 1d 47 34 0f 00 	lea    0xf3447(%rip),%rbx        # 0x14088e21b
   14079add4:	48 89 c7             	mov    %rax,%rdi
   14079add7:	be 04 00 00 00       	mov    $0x4,%esi
   14079addc:	41 89 f0             	mov    %esi,%r8d
   14079addf:	48 89 c8             	mov    %rcx,%rax
   14079ade2:	b9 0b 00 00 00       	mov    $0xb,%ecx
   14079ade7:	e8 b4 eb ff ff       	call   0x1407999a0
   14079adec:	48 83 f8 06          	cmp    $0x6,%rax
   14079adf0:	0f 85 2f 01 00 00    	jne    0x14079af25
   14079adf6:	b8 08 00 00 00       	mov    $0x8,%eax
   14079adfb:	48 8d 1d 6e 27 b2 00 	lea    0xb2276e(%rip),%rbx        # 0x1412bd570
   14079ae02:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079ae07:	e8 74 8f 88 ff       	call   0x140023d80
   14079ae0c:	48 8b 15 5d a6 2f 04 	mov    0x42fa65d(%rip),%rdx        # 0x144a95470
   14079ae13:	48 89 10             	mov    %rdx,(%rax)
   14079ae16:	48 8b 15 2b 01 25 04 	mov    0x425012b(%rip),%rdx        # 0x1449eaf48
   14079ae1d:	48 8d 1d 61 65 0f 00 	lea    0xf6561(%rip),%rbx        # 0x140891385
   14079ae24:	b9 0d 00 00 00       	mov    $0xd,%ecx
   14079ae29:	48 89 c7             	mov    %rax,%rdi
   14079ae2c:	be 01 00 00 00       	mov    $0x1,%esi
   14079ae31:	41 89 f0             	mov    %esi,%r8d
   14079ae34:	48 89 d0             	mov    %rdx,%rax
   14079ae37:	e8 64 eb ff ff       	call   0x1407999a0
   14079ae3c:	0f 1f 40 00          	nopl   0x0(%rax)
   14079ae40:	e9 e0 00 00 00       	jmp    0x14079af25
   14079ae45:	e8 d6 61 ff ff       	call   0x140791020
   14079ae4a:	e9 d6 00 00 00       	jmp    0x14079af25
   14079ae4f:	48 c1 e9 10          	shr    $0x10,%rcx
   14079ae53:	0f b7 d1             	movzwl %cx,%edx
   14079ae56:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   14079ae5d:	00 00 
   14079ae5f:	90                   	nop
   14079ae60:	48 83 fa 02          	cmp    $0x2,%rdx
   14079ae64:	0f 85 bb 00 00 00    	jne    0x14079af25
   14079ae6a:	b8 20 00 00 00       	mov    $0x20,%eax
   14079ae6f:	48 8d 1d 6a 4a b2 00 	lea    0xb24a6a(%rip),%rbx        # 0x1412bf8e0
   14079ae76:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079ae7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079ae80:	e8 9b 96 88 ff       	call   0x140024520
   14079ae85:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   14079ae8c:	00 
   14079ae8d:	48 8b 1d ec f5 2a 04 	mov    0x42af5ec(%rip),%rbx        # 0x144a4a480
   14079ae94:	48 8d 05 85 f9 b4 00 	lea    0xb4f985(%rip),%rax        # 0x1412ea820
   14079ae9b:	b9 6d 00 00 00       	mov    $0x6d,%ecx
   14079aea0:	e8 1b 0f 87 ff       	call   0x14000bdc0
   14079aea5:	48 8b 10             	mov    (%rax),%rdx
   14079aea8:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
   14079aeaf:	00 
   14079aeb0:	48 89 17             	mov    %rdx,(%rdi)
   14079aeb3:	48 c7 47 08 88 01 00 	movq   $0x188,0x8(%rdi)
   14079aeba:	00 
   14079aebb:	44 0f 11 7f 10       	movups %xmm15,0x10(%rdi)
   14079aec0:	48 8b 05 81 00 25 04 	mov    0x4250081(%rip),%rax        # 0x1449eaf48
   14079aec7:	48 8d 1d e1 48 0f 00 	lea    0xf48e1(%rip),%rbx        # 0x14088f7af
   14079aece:	b9 0c 00 00 00       	mov    $0xc,%ecx
   14079aed3:	be 04 00 00 00       	mov    $0x4,%esi
   14079aed8:	41 89 f0             	mov    %esi,%r8d
   14079aedb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079aee0:	e8 bb ea ff ff       	call   0x1407999a0
   14079aee5:	48 85 c0             	test   %rax,%rax
   14079aee8:	7c 3b                	jl     0x14079af25
   14079aeea:	48 39 05 37 0e 2b 04 	cmp    %rax,0x42b0e37(%rip)        # 0x144a4bd28
   14079aef1:	7e 32                	jle    0x14079af25
   14079aef3:	48 8b 0d 26 0e 2b 04 	mov    0x42b0e26(%rip),%rcx        # 0x144a4bd20
   14079aefa:	48 69 d0 a8 00 00 00 	imul   $0xa8,%rax,%rdx
   14079af01:	48 8b 44 11 60       	mov    0x60(%rcx,%rdx,1),%rax
   14079af06:	e8 f5 70 ff ff       	call   0x140792000
   14079af0b:	eb 18                	jmp    0x14079af25
   14079af0d:	e8 2e 35 04 00       	call   0x1407de440
   14079af12:	eb 11                	jmp    0x14079af25
   14079af14:	e8 a7 36 04 00       	call   0x1407de5c0
   14079af19:	eb 0a                	jmp    0x14079af25
   14079af1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079af20:	e8 bb f7 02 00       	call   0x1407ca6e0
   14079af25:	31 c0                	xor    %eax,%eax
   14079af27:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079af2e:	5d                   	pop    %rbp
   14079af2f:	c3                   	ret
   14079af30:	81 fb 13 01 00 00    	cmp    $0x113,%ebx
   14079af36:	0f 85 3b 03 00 00    	jne    0x14079b277
   14079af3c:	0f 1f 40 00          	nopl   0x0(%rax)
   14079af40:	e8 7b f1 02 00       	call   0x1407ca0c0
   14079af45:	e8 56 57 ff ff       	call   0x1407906a0
   14079af4a:	31 c0                	xor    %eax,%eax
   14079af4c:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079af53:	5d                   	pop    %rbp
   14079af54:	c3                   	ret
   14079af55:	8d 93 cd fe ff ff    	lea    -0x133(%rbx),%edx
   14079af5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079af60:	83 fa 01             	cmp    $0x1,%edx
   14079af63:	76 0c                	jbe    0x14079af71
   14079af65:	81 fb 38 01 00 00    	cmp    $0x138,%ebx
   14079af6b:	0f 85 06 03 00 00    	jne    0x14079b277
   14079af71:	48 89 c8             	mov    %rcx,%rax
   14079af74:	48 89 fb             	mov    %rdi,%rbx
   14079af77:	e8 a4 e7 ff ff       	call   0x140799720
   14079af7c:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079af83:	5d                   	pop    %rbp
   14079af84:	c3                   	ret
   14079af85:	81 fb 03 80 00 00    	cmp    $0x8003,%ebx
   14079af8b:	77 53                	ja     0x14079afe0
   14079af8d:	81 fb 02 80 00 00    	cmp    $0x8002,%ebx
   14079af93:	75 2d                	jne    0x14079afc2
   14079af95:	48 81 ff 03 02 00 00 	cmp    $0x203,%rdi
   14079af9c:	74 14                	je     0x14079afb2
   14079af9e:	66 90                	xchg   %ax,%ax
   14079afa0:	48 81 ff 05 02 00 00 	cmp    $0x205,%rdi
   14079afa7:	74 09                	je     0x14079afb2
   14079afa9:	48 81 ff 02 02 00 00 	cmp    $0x202,%rdi
   14079afb0:	75 05                	jne    0x14079afb7
   14079afb2:	e8 89 ef ff ff       	call   0x140799f40
   14079afb7:	31 c0                	xor    %eax,%eax
   14079afb9:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079afc0:	5d                   	pop    %rbp
   14079afc1:	c3                   	ret
   14079afc2:	81 fb 03 80 00 00    	cmp    $0x8003,%ebx
   14079afc8:	0f 85 a9 02 00 00    	jne    0x14079b277
   14079afce:	e8 cd 56 ff ff       	call   0x1407906a0
   14079afd3:	31 c0                	xor    %eax,%eax
   14079afd5:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079afdc:	5d                   	pop    %rbp
   14079afdd:	c3                   	ret
   14079afde:	66 90                	xchg   %ax,%ax
   14079afe0:	81 fb 04 80 00 00    	cmp    $0x8004,%ebx
   14079afe6:	74 39                	je     0x14079b021
   14079afe8:	81 fb 05 80 00 00    	cmp    $0x8005,%ebx
   14079afee:	74 20                	je     0x14079b010
   14079aff0:	81 fb 06 80 00 00    	cmp    $0x8006,%ebx
   14079aff6:	0f 85 7b 02 00 00    	jne    0x14079b277
   14079affc:	0f 1f 40 00          	nopl   0x0(%rax)
   14079b000:	e8 bb f0 02 00       	call   0x1407ca0c0
   14079b005:	31 c0                	xor    %eax,%eax
   14079b007:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b00e:	5d                   	pop    %rbp
   14079b00f:	c3                   	ret
   14079b010:	e8 0b 61 ff ff       	call   0x140791120
   14079b015:	31 c0                	xor    %eax,%eax
   14079b017:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b01e:	5d                   	pop    %rbp
   14079b01f:	90                   	nop
   14079b020:	c3                   	ret
   14079b021:	e8 9a 5c ff ff       	call   0x140790cc0
   14079b026:	31 c0                	xor    %eax,%eax
   14079b028:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b02f:	5d                   	pop    %rbp
   14079b030:	c3                   	ret
   14079b031:	83 fb 10             	cmp    $0x10,%ebx
   14079b034:	0f 87 d7 01 00 00    	ja     0x14079b211
   14079b03a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   14079b040:	83 fb 05             	cmp    $0x5,%ebx
   14079b043:	0f 87 ea 00 00 00    	ja     0x14079b133
   14079b049:	83 fb 02             	cmp    $0x2,%ebx
   14079b04c:	0f 85 be 00 00 00    	jne    0x14079b110
   14079b052:	90                   	nop
   14079b053:	48 83 3d 2d a4 2f 04 	cmpq   $0x0,0x42fa42d(%rip)        # 0x144a95488
   14079b05a:	00 
   14079b05b:	74 48                	je     0x14079b0a5
   14079b05d:	b8 08 00 00 00       	mov    $0x8,%eax
   14079b062:	48 8d 1d 07 25 b2 00 	lea    0xb22507(%rip),%rbx        # 0x1412bd570
   14079b069:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079b06e:	e8 0d 8d 88 ff       	call   0x140023d80
   14079b073:	48 8b 15 0e a4 2f 04 	mov    0x42fa40e(%rip),%rdx        # 0x144a95488
   14079b07a:	48 89 10             	mov    %rdx,(%rax)
   14079b07d:	48 8b 15 c4 fe 24 04 	mov    0x424fec4(%rip),%rdx        # 0x1449eaf48
   14079b084:	48 8d 1d fa 62 0f 00 	lea    0xf62fa(%rip),%rbx        # 0x140891385
   14079b08b:	b9 0d 00 00 00       	mov    $0xd,%ecx
   14079b090:	48 89 c7             	mov    %rax,%rdi
   14079b093:	be 01 00 00 00       	mov    $0x1,%esi
   14079b098:	41 89 f0             	mov    %esi,%r8d
   14079b09b:	48 89 d0             	mov    %rdx,%rax
   14079b09e:	66 90                	xchg   %ax,%ax
   14079b0a0:	e8 fb e8 ff ff       	call   0x1407999a0
   14079b0a5:	48 c7 05 e0 a3 2f 04 	movq   $0x0,0x42fa3e0(%rip)        # 0x144a95490
   14079b0ac:	00 00 00 00 
   14079b0b0:	e8 cb 5d 03 00       	call   0x1407d0e80
   14079b0b5:	b8 02 00 00 00       	mov    $0x2,%eax
   14079b0ba:	31 db                	xor    %ebx,%ebx
   14079b0bc:	31 c9                	xor    %ecx,%ecx
   14079b0be:	66 90                	xchg   %ax,%ax
   14079b0c0:	e8 5b f8 ff ff       	call   0x14079a920
   14079b0c5:	b8 08 00 00 00       	mov    $0x8,%eax
   14079b0ca:	48 8d 1d 9f 24 b2 00 	lea    0xb2249f(%rip),%rbx        # 0x1412bd570
   14079b0d1:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079b0d6:	e8 a5 8c 88 ff       	call   0x140023d80
   14079b0db:	48 8b 0d 66 fe 24 04 	mov    0x424fe66(%rip),%rcx        # 0x1449eaf48
   14079b0e2:	48 8d 1d 02 8b 0f 00 	lea    0xf8b02(%rip),%rbx        # 0x140893beb
   14079b0e9:	48 89 c7             	mov    %rax,%rdi
   14079b0ec:	be 01 00 00 00       	mov    $0x1,%esi
   14079b0f1:	41 89 f0             	mov    %esi,%r8d
   14079b0f4:	48 89 c8             	mov    %rcx,%rax
   14079b0f7:	b9 0f 00 00 00       	mov    $0xf,%ecx
   14079b0fc:	0f 1f 40 00          	nopl   0x0(%rax)
   14079b100:	e8 9b e8 ff ff       	call   0x1407999a0
   14079b105:	31 c0                	xor    %eax,%eax
   14079b107:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b10e:	5d                   	pop    %rbp
   14079b10f:	c3                   	ret
   14079b110:	83 fb 05             	cmp    $0x5,%ebx
   14079b113:	0f 85 5e 01 00 00    	jne    0x14079b277
   14079b119:	0f b7 c7             	movzwl %di,%eax
   14079b11c:	48 c1 ef 10          	shr    $0x10,%rdi
   14079b120:	48 89 fb             	mov    %rdi,%rbx
   14079b123:	e8 b8 c4 ff ff       	call   0x1407975e0
   14079b128:	31 c0                	xor    %eax,%eax
   14079b12a:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b131:	5d                   	pop    %rbp
   14079b132:	c3                   	ret
   14079b133:	83 fb 0f             	cmp    $0xf,%ebx
   14079b136:	0f 84 c5 00 00 00    	je     0x14079b201
   14079b13c:	0f 1f 40 00          	nopl   0x0(%rax)
   14079b140:	83 fb 10             	cmp    $0x10,%ebx
   14079b143:	0f 85 2e 01 00 00    	jne    0x14079b277
   14079b149:	80 3d f8 a1 2f 04 00 	cmpb   $0x0,0x42fa1f8(%rip)        # 0x144a95348
   14079b150:	74 55                	je     0x14079b1a7
   14079b152:	b8 10 00 00 00       	mov    $0x10,%eax
   14079b157:	48 8d 1d ea 36 b2 00 	lea    0xb236ea(%rip),%rbx        # 0x1412be848
   14079b15e:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079b163:	e8 f8 8e 88 ff       	call   0x140024060
   14079b168:	48 8b 15 01 a3 2f 04 	mov    0x42fa301(%rip),%rdx        # 0x144a95470
   14079b16f:	48 89 10             	mov    %rdx,(%rax)
   14079b172:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
   14079b179:	00 
   14079b17a:	48 8b 15 c7 fd 24 04 	mov    0x424fdc7(%rip),%rdx        # 0x1449eaf48
   14079b181:	48 8d 1d 30 16 0f 00 	lea    0xf1630(%rip),%rbx        # 0x14088c7b8
   14079b188:	b9 0a 00 00 00       	mov    $0xa,%ecx
   14079b18d:	48 89 c7             	mov    %rax,%rdi
   14079b190:	be 02 00 00 00       	mov    $0x2,%esi
   14079b195:	41 89 f0             	mov    %esi,%r8d
   14079b198:	48 89 d0             	mov    %rdx,%rax
   14079b19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079b1a0:	e8 fb e7 ff ff       	call   0x1407999a0
   14079b1a5:	eb 4e                	jmp    0x14079b1f5
   14079b1a7:	b8 10 00 00 00       	mov    $0x10,%eax
   14079b1ac:	48 8d 1d 95 36 b2 00 	lea    0xb23695(%rip),%rbx        # 0x1412be848
   14079b1b3:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079b1b8:	e8 a3 8e 88 ff       	call   0x140024060
   14079b1bd:	48 8b 15 ac a2 2f 04 	mov    0x42fa2ac(%rip),%rdx        # 0x144a95470
   14079b1c4:	48 89 10             	mov    %rdx,(%rax)
   14079b1c7:	48 c7 40 08 06 00 00 	movq   $0x6,0x8(%rax)
   14079b1ce:	00 
   14079b1cf:	48 8b 15 72 fd 24 04 	mov    0x424fd72(%rip),%rdx        # 0x1449eaf48
   14079b1d6:	48 8d 1d db 15 0f 00 	lea    0xf15db(%rip),%rbx        # 0x14088c7b8
   14079b1dd:	b9 0a 00 00 00       	mov    $0xa,%ecx
   14079b1e2:	48 89 c7             	mov    %rax,%rdi
   14079b1e5:	be 02 00 00 00       	mov    $0x2,%esi
   14079b1ea:	41 89 f0             	mov    %esi,%r8d
   14079b1ed:	48 89 d0             	mov    %rdx,%rax
   14079b1f0:	e8 ab e7 ff ff       	call   0x1407999a0
   14079b1f5:	31 c0                	xor    %eax,%eax
   14079b1f7:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b1fe:	5d                   	pop    %rbp
   14079b1ff:	90                   	nop
   14079b200:	c3                   	ret
   14079b201:	e8 7a d3 ff ff       	call   0x140798580
   14079b206:	31 c0                	xor    %eax,%eax
   14079b208:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b20f:	5d                   	pop    %rbp
   14079b210:	c3                   	ret
   14079b211:	83 fb 24             	cmp    $0x24,%ebx
   14079b214:	77 36                	ja     0x14079b24c
   14079b216:	83 fb 14             	cmp    $0x14,%ebx
   14079b219:	74 23                	je     0x14079b23e
   14079b21b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   14079b220:	83 fb 24             	cmp    $0x24,%ebx
   14079b223:	75 52                	jne    0x14079b277
   14079b225:	48 b9 f8 02 00 00 da 	movabs $0x2da000002f8,%rcx
   14079b22c:	02 00 00 
   14079b22f:	48 89 4f 18          	mov    %rcx,0x18(%rdi)
   14079b233:	31 c0                	xor    %eax,%eax
   14079b235:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b23c:	5d                   	pop    %rbp
   14079b23d:	c3                   	ret
   14079b23e:	b8 01 00 00 00       	mov    $0x1,%eax
   14079b243:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b24a:	5d                   	pop    %rbp
   14079b24b:	c3                   	ret
   14079b24c:	83 fb 2b             	cmp    $0x2b,%ebx
   14079b24f:	0f 84 99 00 00 00    	je     0x14079b2ee
   14079b255:	83 fb 2c             	cmp    $0x2c,%ebx
   14079b258:	75 1d                	jne    0x14079b277
   14079b25a:	83 7f 04 6d          	cmpl   $0x6d,0x4(%rdi)
   14079b25e:	66 90                	xchg   %ax,%ax
   14079b260:	75 15                	jne    0x14079b277
   14079b262:	c7 47 10 3c 00 00 00 	movl   $0x3c,0x10(%rdi)
   14079b269:	b8 01 00 00 00       	mov    $0x1,%eax
   14079b26e:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b275:	5d                   	pop    %rbp
   14079b276:	c3                   	ret
   14079b277:	b8 20 00 00 00       	mov    $0x20,%eax
   14079b27c:	48 8d 1d 5d 46 b2 00 	lea    0xb2465d(%rip),%rbx        # 0x1412bf8e0
   14079b283:	b9 01 00 00 00       	mov    $0x1,%ecx
   14079b288:	e8 93 92 88 ff       	call   0x140024520
   14079b28d:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   14079b294:	00 
   14079b295:	48 89 10             	mov    %rdx,(%rax)
   14079b298:	8b 94 24 b0 01 00 00 	mov    0x1b0(%rsp),%edx
   14079b29f:	89 d2                	mov    %edx,%edx
   14079b2a1:	48 89 50 08          	mov    %rdx,0x8(%rax)
   14079b2a5:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
   14079b2ac:	00 
   14079b2ad:	48 89 50 10          	mov    %rdx,0x10(%rax)
   14079b2b1:	48 8b 94 24 c0 01 00 	mov    0x1c0(%rsp),%rdx
   14079b2b8:	00 
   14079b2b9:	48 89 50 18          	mov    %rdx,0x18(%rax)
   14079b2bd:	48 8b 15 84 fc 24 04 	mov    0x424fc84(%rip),%rdx        # 0x1449eaf48
   14079b2c4:	48 8d 1d 93 73 0f 00 	lea    0xf7393(%rip),%rbx        # 0x14089265e
   14079b2cb:	b9 0e 00 00 00       	mov    $0xe,%ecx
   14079b2d0:	48 89 c7             	mov    %rax,%rdi
   14079b2d3:	be 04 00 00 00       	mov    $0x4,%esi
   14079b2d8:	41 89 f0             	mov    %esi,%r8d
   14079b2db:	48 89 d0             	mov    %rdx,%rax
   14079b2de:	66 90                	xchg   %ax,%ax
   14079b2e0:	e8 bb e6 ff ff       	call   0x1407999a0
   14079b2e5:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b2ec:	5d                   	pop    %rbp
   14079b2ed:	c3                   	ret
   14079b2ee:	48 89 f8             	mov    %rdi,%rax
   14079b2f1:	e8 ca db ff ff       	call   0x140798ec0
   14079b2f6:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   14079b2fd:	5d                   	pop    %rbp
   14079b2fe:	c3                   	ret
   14079b2ff:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   14079b304:	89 5c 24 10          	mov    %ebx,0x10(%rsp)
   14079b308:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   14079b30d:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   14079b312:	e8 29 10 8f ff       	call   0x14008c340
   14079b317:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   14079b31c:	8b 5c 24 10          	mov    0x10(%rsp),%ebx
   14079b320:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   14079b325:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   14079b32a:	e9 f1 f7 ff ff       	jmp    0x14079ab20
   14079b32f:	cc                   	int3
   14079b330:	cc                   	int3
   14079b331:	cc                   	int3
   14079b332:	cc                   	int3
   14079b333:	cc                   	int3
   14079b334:	cc                   	int3
   14079b335:	cc                   	int3
   14079b336:	cc                   	int3
   14079b337:	cc                   	int3
   14079b338:	cc                   	int3
   14079b339:	cc                   	int3
   14079b33a:	cc                   	int3
   14079b33b:	cc                   	int3
   14079b33c:	cc                   	int3
   14079b33d:	cc                   	int3
   14079b33e:	cc                   	int3
   14079b33f:	cc                   	int3

# main.toastTime @ 0x1407ca800
   1407ca800:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407ca804:	0f 86 14 01 00 00    	jbe    0x1407ca91e
   1407ca80a:	55                   	push   %rbp
   1407ca80b:	48 89 e5             	mov    %rsp,%rbp
   1407ca80e:	48 83 ec 58          	sub    $0x58,%rsp
   1407ca812:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   1407ca817:	48 89 c1             	mov    %rax,%rcx
   1407ca81a:	48 89 df             	mov    %rbx,%rdi
   1407ca81d:	48 8d 05 27 97 0d 00 	lea    0xd9727(%rip),%rax        # 0x1408a3f4b
   1407ca824:	bb 19 00 00 00       	mov    $0x19,%ebx
   1407ca829:	e8 f2 af 8e ff       	call   0x1400b5820
   1407ca82e:	48 85 ff             	test   %rdi,%rdi
   1407ca831:	0f 85 c1 00 00 00    	jne    0x1407ca8f8
   1407ca837:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   1407ca83c:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   1407ca841:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   1407ca846:	48 8d 05 cc 5e 0b 00 	lea    0xb5ecc(%rip),%rax        # 0x140880719
   1407ca84d:	bb 03 00 00 00       	mov    $0x3,%ebx
   1407ca852:	b9 90 7e 00 00       	mov    $0x7e90,%ecx
   1407ca857:	e8 e4 31 8f ff       	call   0x1400bda40
   1407ca85c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
   1407ca861:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407ca866:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   1407ca86b:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
   1407ca870:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   1407ca875:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
   1407ca87a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407ca880:	48 85 c0             	test   %rax,%rax
   1407ca883:	0f 84 81 00 00 00    	je     0x1407ca90a
   1407ca889:	90                   	nop
   1407ca88a:	4c 8d 05 ef 45 24 04 	lea    0x42445ef(%rip),%r8        # 0x144a0ee80
   1407ca891:	4c 39 c0             	cmp    %r8,%rax
   1407ca894:	41 b8 00 00 00 00    	mov    $0x0,%r8d
   1407ca89a:	49 0f 44 c0          	cmove  %r8,%rax
   1407ca89e:	48 0f ba e2 3f       	bt     $0x3f,%rdx
   1407ca8a3:	73 27                	jae    0x1407ca8cc
   1407ca8a5:	49 89 d0             	mov    %rdx,%r8
   1407ca8a8:	81 e2 ff ff ff 3f    	and    $0x3fffffff,%edx
   1407ca8ae:	4d 01 c0             	add    %r8,%r8
   1407ca8b1:	49 c1 e8 1f          	shr    $0x1f,%r8
   1407ca8b5:	49 b9 80 7f b1 d7 0d 	movabs $0xdd7b17f80,%r9
   1407ca8bc:	00 00 00 
   1407ca8bf:	4d 01 c8             	add    %r9,%r8
   1407ca8c2:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
   1407ca8c7:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407ca8cc:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   1407ca8d1:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   1407ca8d6:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
   1407ca8db:	48 89 c1             	mov    %rax,%rcx
   1407ca8de:	48 8d 3d e9 7f 0b 00 	lea    0xb7fe9(%rip),%rdi        # 0x1408828ce
   1407ca8e5:	be 05 00 00 00       	mov    $0x5,%esi
   1407ca8ea:	48 89 d0             	mov    %rdx,%rax
   1407ca8ed:	e8 ee 7e 8e ff       	call   0x1400b27e0
   1407ca8f2:	48 83 c4 58          	add    $0x58,%rsp
   1407ca8f6:	5d                   	pop    %rbp
   1407ca8f7:	c3                   	ret
   1407ca8f8:	48 8d 05 7c 4f 0c 00 	lea    0xc4f7c(%rip),%rax        # 0x14088f87b
   1407ca8ff:	bb 0c 00 00 00       	mov    $0xc,%ebx
   1407ca904:	48 83 c4 58          	add    $0x58,%rsp
   1407ca908:	5d                   	pop    %rbp
   1407ca909:	c3                   	ret
   1407ca90a:	48 8d 05 af 2d b8 00 	lea    0xb82daf(%rip),%rax        # 0x14134d6c0
   1407ca911:	48 8d 1d 08 bc 40 00 	lea    0x40bc08(%rip),%rbx        # 0x140bd6520
   1407ca918:	e8 23 c2 8b ff       	call   0x140086b40
   1407ca91d:	90                   	nop
   1407ca91e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1407ca923:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   1407ca928:	e8 13 1a 8c ff       	call   0x14008c340
   1407ca92d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1407ca932:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
   1407ca937:	e9 c4 fe ff ff       	jmp    0x1407ca800
   1407ca93c:	cc                   	int3
   1407ca93d:	cc                   	int3
   1407ca93e:	cc                   	int3
   1407ca93f:	cc                   	int3

# main.toastWorkerLine @ 0x1407ca940
   1407ca940:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407ca944:	0f 86 14 02 00 00    	jbe    0x1407cab5e
   1407ca94a:	55                   	push   %rbp
   1407ca94b:	48 89 e5             	mov    %rsp,%rbp
   1407ca94e:	48 83 ec 48          	sub    $0x48,%rsp
   1407ca952:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   1407ca959:	00 
   1407ca95a:	48 83 bc 24 a8 00 00 	cmpq   $0x4,0xa8(%rsp)
   1407ca961:	00 04 
   1407ca963:	75 31                	jne    0x1407ca996
   1407ca965:	81 3a 6e 6f 74 65    	cmpl   $0x65746f6e,(%rdx)
   1407ca96b:	75 29                	jne    0x1407ca996
   1407ca96d:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   1407ca974:	00 
   1407ca975:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   1407ca97c:	00 
   1407ca97d:	31 c0                	xor    %eax,%eax
   1407ca97f:	48 8d 3d ff 08 0e 00 	lea    0xe08ff(%rip),%rdi        # 0x1408ab285
   1407ca986:	be 1e 00 00 00       	mov    $0x1e,%esi
   1407ca98b:	e8 10 fd 89 ff       	call   0x14006a6a0
   1407ca990:	48 83 c4 48          	add    $0x48,%rsp
   1407ca994:	5d                   	pop    %rbp
   1407ca995:	c3                   	ret
   1407ca996:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
   1407ca99b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407ca9a0:	0f 84 f9 00 00 00    	je     0x1407caa9f
   1407ca9a6:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
   1407ca9ab:	4d 85 e4             	test   %r12,%r12
   1407ca9ae:	7e 33                	jle    0x1407ca9e3
   1407ca9b0:	4c 39 a4 24 b8 00 00 	cmp    %r12,0xb8(%rsp)
   1407ca9b7:	00 
   1407ca9b8:	75 29                	jne    0x1407ca9e3
   1407ca9ba:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   1407ca9c1:	00 
   1407ca9c2:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   1407ca9c9:	00 
   1407ca9ca:	31 c0                	xor    %eax,%eax
   1407ca9cc:	48 8d 3d 87 90 0f 00 	lea    0xf9087(%rip),%rdi        # 0x1408c3a5a
   1407ca9d3:	be 36 00 00 00       	mov    $0x36,%esi
   1407ca9d8:	e8 c3 fc 89 ff       	call   0x14006a6a0
   1407ca9dd:	48 83 c4 48          	add    $0x48,%rsp
   1407ca9e1:	5d                   	pop    %rbp
   1407ca9e2:	c3                   	ret
   1407ca9e3:	4c 8b a4 24 a8 00 00 	mov    0xa8(%rsp),%r12
   1407ca9ea:	00 
   1407ca9eb:	49 83 fc 04          	cmp    $0x4,%r12
   1407ca9ef:	75 16                	jne    0x1407caa07
   1407ca9f1:	81 3a 6e 6f 74 65    	cmpl   $0x65746f6e,(%rdx)
   1407ca9f7:	75 5b                	jne    0x1407caa54
   1407ca9f9:	b8 0d 00 00 00       	mov    $0xd,%eax
   1407ca9fe:	48 8d 0d b0 68 0c 00 	lea    0xc68b0(%rip),%rcx        # 0x1408912b5
   1407caa05:	eb 59                	jmp    0x1407caa60
   1407caa07:	49 83 fc 07          	cmp    $0x7,%r12
   1407caa0b:	75 24                	jne    0x1407caa31
   1407caa0d:	81 3a 73 65 74 74    	cmpl   $0x74746573,(%rdx)
   1407caa13:	75 3f                	jne    0x1407caa54
   1407caa15:	66 81 7a 04 69 6e    	cmpw   $0x6e69,0x4(%rdx)
   1407caa1b:	75 37                	jne    0x1407caa54
   1407caa1d:	80 7a 06 67          	cmpb   $0x67,0x6(%rdx)
   1407caa21:	75 31                	jne    0x1407caa54
   1407caa23:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407caa28:	48 8d 0d f0 4c 0c 00 	lea    0xc4cf0(%rip),%rcx        # 0x14088f71f
   1407caa2f:	eb 2f                	jmp    0x1407caa60
   1407caa31:	49 83 fc 08          	cmp    $0x8,%r12
   1407caa35:	75 1d                	jne    0x1407caa54
   1407caa37:	49 bc 73 68 69 70 70 	movabs $0x676e697070696873,%r12
   1407caa3e:	69 6e 67 
   1407caa41:	4c 39 22             	cmp    %r12,(%rdx)
   1407caa44:	75 0e                	jne    0x1407caa54
   1407caa46:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407caa4b:	48 8d 0d c1 4c 0c 00 	lea    0xc4cc1(%rip),%rcx        # 0x14088f713
   1407caa52:	eb 0c                	jmp    0x1407caa60
   1407caa54:	b8 06 00 00 00       	mov    $0x6,%eax
   1407caa59:	48 8d 0d 3b 9e 0b 00 	lea    0xb9e3b(%rip),%rcx        # 0x14088489b
   1407caa60:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   1407caa67:	00 
   1407caa68:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
   1407caa6f:	00 
   1407caa70:	48 8d 3d a9 e3 0b 00 	lea    0xbe3a9(%rip),%rdi        # 0x140888e20
   1407caa77:	be 08 00 00 00       	mov    $0x8,%esi
   1407caa7c:	49 89 c8             	mov    %rcx,%r8
   1407caa7f:	41 89 c1             	mov    %eax,%r9d
   1407caa82:	4c 8d 15 ce 02 0d 00 	lea    0xd02ce(%rip),%r10        # 0x14089ad57
   1407caa89:	41 bb 13 00 00 00    	mov    $0x13,%r11d
   1407caa8f:	31 c0                	xor    %eax,%eax
   1407caa91:	48 89 d1             	mov    %rdx,%rcx
   1407caa94:	e8 67 fd 89 ff       	call   0x14006a800
   1407caa99:	48 83 c4 48          	add    $0x48,%rsp
   1407caa9d:	5d                   	pop    %rbp
   1407caa9e:	c3                   	ret
   1407caa9f:	4c 8b a4 24 a8 00 00 	mov    0xa8(%rsp),%r12
   1407caaa6:	00 
   1407caaa7:	49 83 fc 04          	cmp    $0x4,%r12
   1407caaab:	75 16                	jne    0x1407caac3
   1407caaad:	81 3a 6e 6f 74 65    	cmpl   $0x65746f6e,(%rdx)
   1407caab3:	75 5e                	jne    0x1407cab13
   1407caab5:	b8 0d 00 00 00       	mov    $0xd,%eax
   1407caaba:	48 8d 0d f4 67 0c 00 	lea    0xc67f4(%rip),%rcx        # 0x1408912b5
   1407caac1:	eb 5c                	jmp    0x1407cab1f
   1407caac3:	49 83 fc 07          	cmp    $0x7,%r12
   1407caac7:	75 24                	jne    0x1407caaed
   1407caac9:	81 3a 73 65 74 74    	cmpl   $0x74746573,(%rdx)
   1407caacf:	75 42                	jne    0x1407cab13
   1407caad1:	66 81 7a 04 69 6e    	cmpw   $0x6e69,0x4(%rdx)
   1407caad7:	75 3a                	jne    0x1407cab13
   1407caad9:	80 7a 06 67          	cmpb   $0x67,0x6(%rdx)
   1407caadd:	75 34                	jne    0x1407cab13
   1407caadf:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407caae4:	48 8d 0d 34 4c 0c 00 	lea    0xc4c34(%rip),%rcx        # 0x14088f71f
   1407caaeb:	eb 32                	jmp    0x1407cab1f
   1407caaed:	49 83 fc 08          	cmp    $0x8,%r12
   1407caaf1:	75 20                	jne    0x1407cab13
   1407caaf3:	49 bc 73 68 69 70 70 	movabs $0x676e697070696873,%r12
   1407caafa:	69 6e 67 
   1407caafd:	0f 1f 00             	nopl   (%rax)
   1407cab00:	4c 39 22             	cmp    %r12,(%rdx)
   1407cab03:	75 0e                	jne    0x1407cab13
   1407cab05:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407cab0a:	48 8d 0d 02 4c 0c 00 	lea    0xc4c02(%rip),%rcx        # 0x14088f713
   1407cab11:	eb 0c                	jmp    0x1407cab1f
   1407cab13:	b8 06 00 00 00       	mov    $0x6,%eax
   1407cab18:	48 8d 0d 7c 9d 0b 00 	lea    0xb9d7c(%rip),%rcx        # 0x14088489b
   1407cab1f:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   1407cab26:	00 
   1407cab27:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
   1407cab2e:	00 
   1407cab2f:	48 8d 3d ea e2 0b 00 	lea    0xbe2ea(%rip),%rdi        # 0x140888e20
   1407cab36:	be 08 00 00 00       	mov    $0x8,%esi
   1407cab3b:	49 89 c8             	mov    %rcx,%r8
   1407cab3e:	41 89 c1             	mov    %eax,%r9d
   1407cab41:	4c 8d 15 80 a9 0c 00 	lea    0xca980(%rip),%r10        # 0x1408954c8
   1407cab48:	41 bb 10 00 00 00    	mov    $0x10,%r11d
   1407cab4e:	31 c0                	xor    %eax,%eax
   1407cab50:	48 89 d1             	mov    %rdx,%rcx
   1407cab53:	e8 a8 fc 89 ff       	call   0x14006a800
   1407cab58:	48 83 c4 48          	add    $0x48,%rsp
   1407cab5c:	5d                   	pop    %rbp
   1407cab5d:	c3                   	ret
   1407cab5e:	66 90                	xchg   %ax,%ax
   1407cab60:	e8 db 17 8c ff       	call   0x14008c340
   1407cab65:	e9 d6 fd ff ff       	jmp    0x1407ca940
   1407cab6a:	cc                   	int3
   1407cab6b:	cc                   	int3
   1407cab6c:	cc                   	int3
   1407cab6d:	cc                   	int3
   1407cab6e:	cc                   	int3
   1407cab6f:	cc                   	int3
   1407cab70:	cc                   	int3
   1407cab71:	cc                   	int3
   1407cab72:	cc                   	int3
   1407cab73:	cc                   	int3
   1407cab74:	cc                   	int3
   1407cab75:	cc                   	int3
   1407cab76:	cc                   	int3
   1407cab77:	cc                   	int3
   1407cab78:	cc                   	int3
   1407cab79:	cc                   	int3
   1407cab7a:	cc                   	int3
   1407cab7b:	cc                   	int3
   1407cab7c:	cc                   	int3
   1407cab7d:	cc                   	int3
   1407cab7e:	cc                   	int3
   1407cab7f:	cc                   	int3

# main.toastNotePreview @ 0x1407cab80
   1407cab80:	4c 8d 64 24 a0       	lea    -0x60(%rsp),%r12
   1407cab85:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407cab89:	0f 86 b2 00 00 00    	jbe    0x1407cac41
   1407cab8f:	55                   	push   %rbp
   1407cab90:	48 89 e5             	mov    %rsp,%rbp
   1407cab93:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
   1407cab9a:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
   1407caba1:	00 
   1407caba2:	48 8b 9c 24 20 01 00 	mov    0x120(%rsp),%rbx
   1407caba9:	00 
   1407cabaa:	e8 31 5a 91 ff       	call   0x1400e05e0
   1407cabaf:	48 8d 3d f2 b1 40 00 	lea    0x40b1f2(%rip),%rdi        # 0x140bd5da8
   1407cabb6:	be 01 00 00 00       	mov    $0x1,%esi
   1407cabbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cabc0:	e8 7b 5f 91 ff       	call   0x1400e0b40
   1407cabc5:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   1407cabcc:	00 
   1407cabcd:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
   1407cabd4:	00 
   1407cabd5:	48 89 d9             	mov    %rbx,%rcx
   1407cabd8:	48 89 c3             	mov    %rax,%rbx
   1407cabdb:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   1407cabe0:	e8 5b 04 8a ff       	call   0x14006b040
   1407cabe5:	48 83 fb 64          	cmp    $0x64,%rbx
   1407cabe9:	7e 3c                	jle    0x1407cac27
   1407cabeb:	48 89 c3             	mov    %rax,%rbx
   1407cabee:	48 89 cf             	mov    %rcx,%rdi
   1407cabf1:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   1407cabf6:	b9 64 00 00 00       	mov    $0x64,%ecx
   1407cabfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cac00:	e8 bb 05 8a ff       	call   0x14006b1c0
   1407cac05:	48 89 d9             	mov    %rbx,%rcx
   1407cac08:	48 8d 3d 31 5b 0b 00 	lea    0xb5b31(%rip),%rdi        # 0x140880740
   1407cac0f:	be 03 00 00 00       	mov    $0x3,%esi
   1407cac14:	48 89 c3             	mov    %rax,%rbx
   1407cac17:	31 c0                	xor    %eax,%eax
   1407cac19:	e8 82 fa 89 ff       	call   0x14006a6a0
   1407cac1e:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
   1407cac25:	5d                   	pop    %rbp
   1407cac26:	c3                   	ret
   1407cac27:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   1407cac2e:	00 
   1407cac2f:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   1407cac36:	00 
   1407cac37:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
   1407cac3e:	5d                   	pop    %rbp
   1407cac3f:	90                   	nop
   1407cac40:	c3                   	ret
   1407cac41:	e8 fa 16 8c ff       	call   0x14008c340
   1407cac46:	e9 35 ff ff ff       	jmp    0x1407cab80
   1407cac4b:	cc                   	int3
   1407cac4c:	cc                   	int3
   1407cac4d:	cc                   	int3
   1407cac4e:	cc                   	int3
   1407cac4f:	cc                   	int3
   1407cac50:	cc                   	int3
   1407cac51:	cc                   	int3
   1407cac52:	cc                   	int3
   1407cac53:	cc                   	int3
   1407cac54:	cc                   	int3
   1407cac55:	cc                   	int3
   1407cac56:	cc                   	int3
   1407cac57:	cc                   	int3
   1407cac58:	cc                   	int3
   1407cac59:	cc                   	int3
   1407cac5a:	cc                   	int3
   1407cac5b:	cc                   	int3
   1407cac5c:	cc                   	int3
   1407cac5d:	cc                   	int3
   1407cac5e:	cc                   	int3
   1407cac5f:	cc                   	int3

# main.toastWorkArea @ 0x1407cac60
   1407cac60:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407cac64:	0f 86 4a 02 00 00    	jbe    0x1407caeb4
   1407cac6a:	55                   	push   %rbp
   1407cac6b:	48 89 e5             	mov    %rsp,%rbp
   1407cac6e:	48 83 ec 60          	sub    $0x60,%rsp
   1407cac72:	b8 10 00 00 00       	mov    $0x10,%eax
   1407cac77:	48 8d 1d ca 3b af 00 	lea    0xaf3bca(%rip),%rbx        # 0x1412be848
   1407cac7e:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cac83:	e8 d8 93 85 ff       	call   0x140024060
   1407cac88:	48 8b 15 e1 a7 2c 04 	mov    0x42ca7e1(%rip),%rdx        # 0x144a95470
   1407cac8f:	48 89 10             	mov    %rdx,(%rax)
   1407cac92:	48 c7 40 08 02 00 00 	movq   $0x2,0x8(%rax)
   1407cac99:	00 
   1407cac9a:	48 8b 15 a7 02 22 04 	mov    0x42202a7(%rip),%rdx        # 0x1449eaf48
   1407caca1:	48 8d 1d c7 cd 0c 00 	lea    0xccdc7(%rip),%rbx        # 0x140897a6f
   1407caca8:	b9 11 00 00 00       	mov    $0x11,%ecx
   1407cacad:	48 89 c7             	mov    %rax,%rdi
   1407cacb0:	be 02 00 00 00       	mov    $0x2,%esi
   1407cacb5:	41 89 f0             	mov    %esi,%r8d
   1407cacb8:	48 89 d0             	mov    %rdx,%rax
   1407cacbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cacc0:	e8 db ec fc ff       	call   0x1407999a0
   1407cacc5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   1407cacca:	b8 28 00 00 00       	mov    $0x28,%eax
   1407caccf:	48 8d 1d 02 01 bf 00 	lea    0xbf0102(%rip),%rbx        # 0x1413badd8
   1407cacd6:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cacdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cace0:	e8 9b 9a 85 ff       	call   0x140024780
   1407cace5:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   1407cacea:	c7 00 28 00 00 00    	movl   $0x28,(%rax)
   1407cacf0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   1407cacf5:	b8 10 00 00 00       	mov    $0x10,%eax
   1407cacfa:	48 8d 1d 47 3b af 00 	lea    0xaf3b47(%rip),%rbx        # 0x1412be848
   1407cad01:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cad06:	e8 55 93 85 ff       	call   0x140024060
   1407cad0b:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   1407cad10:	48 89 10             	mov    %rdx,(%rax)
   1407cad13:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   1407cad18:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407cad1c:	48 8b 15 25 02 22 04 	mov    0x4220225(%rip),%rdx        # 0x1449eaf48
   1407cad23:	48 8d 1d 0c 8f 0c 00 	lea    0xc8f0c(%rip),%rbx        # 0x140893c36
   1407cad2a:	b9 0f 00 00 00       	mov    $0xf,%ecx
   1407cad2f:	48 89 c7             	mov    %rax,%rdi
   1407cad32:	be 02 00 00 00       	mov    $0x2,%esi
   1407cad37:	41 89 f0             	mov    %esi,%r8d
   1407cad3a:	48 89 d0             	mov    %rdx,%rax
   1407cad3d:	0f 1f 00             	nopl   (%rax)
   1407cad40:	e8 5b ec fc ff       	call   0x1407999a0
   1407cad45:	48 85 c0             	test   %rax,%rax
   1407cad48:	75 6a                	jne    0x1407cadb4
   1407cad4a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   1407cad4f:	48 83 c2 14          	add    $0x14,%rdx
   1407cad53:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   1407cad58:	b8 20 00 00 00       	mov    $0x20,%eax
   1407cad5d:	48 8d 1d 7c 4b af 00 	lea    0xaf4b7c(%rip),%rbx        # 0x1412bf8e0
   1407cad64:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cad69:	e8 b2 97 85 ff       	call   0x140024520
   1407cad6e:	48 c7 00 30 00 00 00 	movq   $0x30,(%rax)
   1407cad75:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
   1407cad7c:	00 
   1407cad7d:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407cad82:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407cad86:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
   1407cad8d:	00 
   1407cad8e:	48 8b 15 b3 01 22 04 	mov    0x42201b3(%rip),%rdx        # 0x1449eaf48
   1407cad95:	48 8d 1d ca 33 0d 00 	lea    0xd33ca(%rip),%rbx        # 0x14089e166
   1407cad9c:	b9 15 00 00 00       	mov    $0x15,%ecx
   1407cada1:	48 89 c7             	mov    %rax,%rdi
   1407cada4:	be 04 00 00 00       	mov    $0x4,%esi
   1407cada9:	41 89 f0             	mov    %esi,%r8d
   1407cadac:	48 89 d0             	mov    %rdx,%rax
   1407cadaf:	e8 ec eb fc ff       	call   0x1407999a0
   1407cadb4:	48 8b 15 8d 01 22 04 	mov    0x422018d(%rip),%rdx        # 0x1449eaf48
   1407cadbb:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   1407cadc0:	b8 28 00 00 00       	mov    $0x28,%eax
   1407cadc5:	48 8d 1d 8c 40 bf 00 	lea    0xbf408c(%rip),%rbx        # 0x1413bee58
   1407cadcc:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cadd1:	e8 ea 83 85 ff       	call   0x1400231c0
   1407cadd6:	83 3d 83 ab 2c 04 00 	cmpl   $0x0,0x42cab83(%rip)        # 0x144a95960
   1407caddd:	75 07                	jne    0x1407cade6
   1407caddf:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   1407cade4:	eb 0d                	jmp    0x1407cadf3
   1407cade6:	e8 d5 2f 8c ff       	call   0x14008ddc0
   1407cadeb:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   1407cadf0:	49 89 0b             	mov    %rcx,(%r11)
   1407cadf3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   1407cadf8:	48 89 48 18          	mov    %rcx,0x18(%rax)
   1407cadfc:	48 c7 40 10 0f 00 00 	movq   $0xf,0x10(%rax)
   1407cae03:	00 
   1407cae04:	48 8d 0d 3a 8e 0c 00 	lea    0xc8e3a(%rip),%rcx        # 0x140893c45
   1407cae0b:	48 89 48 08          	mov    %rcx,0x8(%rax)
   1407cae0f:	e8 8c 60 8d ff       	call   0x1400a0ea0
   1407cae14:	48 85 c0             	test   %rax,%rax
   1407cae17:	74 0a                	je     0x1407cae23
   1407cae19:	f2 0f 10 05 b7 af 40 	movsd  0x40afb7(%rip),%xmm0        # 0x140bd5dd8
   1407cae20:	00 
   1407cae21:	eb 7a                	jmp    0x1407cae9d
   1407cae23:	b8 08 00 00 00       	mov    $0x8,%eax
   1407cae28:	48 8d 1d 41 27 af 00 	lea    0xaf2741(%rip),%rbx        # 0x1412bd570
   1407cae2f:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cae34:	e8 47 8f 85 ff       	call   0x140023d80
   1407cae39:	48 8b 15 30 a6 2c 04 	mov    0x42ca630(%rip),%rdx        # 0x144a95470
   1407cae40:	48 89 10             	mov    %rdx,(%rax)
   1407cae43:	48 89 c3             	mov    %rax,%rbx
   1407cae46:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cae4b:	89 cf                	mov    %ecx,%edi
   1407cae4d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1407cae52:	e8 c9 61 8d ff       	call   0x1400a1020
   1407cae57:	48 83 f8 60          	cmp    $0x60,%rax
   1407cae5b:	72 38                	jb     0x1407cae95
   1407cae5d:	0f 1f 00             	nopl   (%rax)
   1407cae60:	48 85 c0             	test   %rax,%rax
   1407cae63:	7c 0a                	jl     0x1407cae6f
   1407cae65:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cae68:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   1407cae6d:	eb 18                	jmp    0x1407cae87
   1407cae6f:	48 89 c2             	mov    %rax,%rdx
   1407cae72:	83 e0 01             	and    $0x1,%eax
   1407cae75:	48 d1 ea             	shr    $1,%rdx
   1407cae78:	48 09 c2             	or     %rax,%rdx
   1407cae7b:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cae7e:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   1407cae83:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   1407cae87:	f2 0f 10 0d f9 af 40 	movsd  0x40aff9(%rip),%xmm1        # 0x140bd5e88
   1407cae8e:	00 
   1407cae8f:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   1407cae93:	eb 08                	jmp    0x1407cae9d
   1407cae95:	f2 0f 10 05 3b af 40 	movsd  0x40af3b(%rip),%xmm0        # 0x140bd5dd8
   1407cae9c:	00 
   1407cae9d:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   1407caea2:	8b 42 14             	mov    0x14(%rdx),%eax
   1407caea5:	8b 5a 18             	mov    0x18(%rdx),%ebx
   1407caea8:	8b 4a 1c             	mov    0x1c(%rdx),%ecx
   1407caeab:	8b 7a 20             	mov    0x20(%rdx),%edi
   1407caeae:	48 83 c4 60          	add    $0x60,%rsp
   1407caeb2:	5d                   	pop    %rbp
   1407caeb3:	c3                   	ret
   1407caeb4:	e8 87 14 8c ff       	call   0x14008c340
   1407caeb9:	e9 a2 fd ff ff       	jmp    0x1407cac60
   1407caebe:	cc                   	int3
   1407caebf:	cc                   	int3

# main.toastCapacity @ 0x1407caec0
   1407caec0:	55                   	push   %rbp
   1407caec1:	48 89 e5             	mov    %rsp,%rbp
   1407caec4:	f2 0f 10 0d d4 af 40 	movsd  0x40afd4(%rip),%xmm1        # 0x140bd5ea0
   1407caecb:	00 
   1407caecc:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407caed0:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407caed5:	48 89 ca             	mov    %rcx,%rdx
   1407caed8:	48 c1 ea 34          	shr    $0x34,%rdx
   1407caedc:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407caee2:	90                   	nop
   1407caee3:	90                   	nop
   1407caee4:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407caeeb:	73 33                	jae    0x1407caf20
   1407caeed:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407caef4:	00 00 80 
   1407caef7:	48 21 f1             	and    %rsi,%rcx
   1407caefa:	49 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%r8
   1407caf01:	00 f0 3f 
   1407caf04:	49 09 c8             	or     %rcx,%r8
   1407caf07:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407caf0e:	49 0f 44 c8          	cmove  %r8,%rcx
   1407caf12:	48 89 ce             	mov    %rcx,%rsi
   1407caf15:	eb 47                	jmp    0x1407caf5e
   1407caf17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1407caf1e:	00 00 
   1407caf20:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407caf27:	73 32                	jae    0x1407caf5b
   1407caf29:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407caf30:	48 89 c8             	mov    %rcx,%rax
   1407caf33:	48 89 d1             	mov    %rdx,%rcx
   1407caf36:	48 be 00 00 00 00 00 	movabs $0x8000000000000,%rsi
   1407caf3d:	00 08 00 
   1407caf40:	48 d3 ee             	shr    %cl,%rsi
   1407caf43:	48 01 c6             	add    %rax,%rsi
   1407caf46:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407caf4d:	ff 0f 00 
   1407caf50:	49 d3 e8             	shr    %cl,%r8
   1407caf53:	49 f7 d0             	not    %r8
   1407caf56:	4c 21 c6             	and    %r8,%rsi
   1407caf59:	eb 03                	jmp    0x1407caf5e
   1407caf5b:	48 89 ce             	mov    %rcx,%rsi
   1407caf5e:	f2 0f 10 0d 82 ae 40 	movsd  0x40ae82(%rip),%xmm1        # 0x140bd5de8
   1407caf65:	00 
   1407caf66:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407caf6a:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407caf6f:	48 89 ca             	mov    %rcx,%rdx
   1407caf72:	48 c1 ea 34          	shr    $0x34,%rdx
   1407caf76:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407caf7c:	90                   	nop
   1407caf7d:	90                   	nop
   1407caf7e:	90                   	nop
   1407caf7f:	90                   	nop
   1407caf80:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407caf87:	73 2a                	jae    0x1407cafb3
   1407caf89:	49 b8 00 00 00 00 00 	movabs $0x8000000000000000,%r8
   1407caf90:	00 00 80 
   1407caf93:	4c 21 c1             	and    %r8,%rcx
   1407caf96:	49 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%r9
   1407caf9d:	00 f0 3f 
   1407cafa0:	49 09 c9             	or     %rcx,%r9
   1407cafa3:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cafaa:	49 0f 44 c9          	cmove  %r9,%rcx
   1407cafae:	49 89 c8             	mov    %rcx,%r8
   1407cafb1:	eb 3e                	jmp    0x1407caff1
   1407cafb3:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cafba:	73 32                	jae    0x1407cafee
   1407cafbc:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cafc3:	48 89 c8             	mov    %rcx,%rax
   1407cafc6:	48 89 d1             	mov    %rdx,%rcx
   1407cafc9:	49 b8 00 00 00 00 00 	movabs $0x8000000000000,%r8
   1407cafd0:	00 08 00 
   1407cafd3:	49 d3 e8             	shr    %cl,%r8
   1407cafd6:	49 01 c0             	add    %rax,%r8
   1407cafd9:	49 b9 ff ff ff ff ff 	movabs $0xfffffffffffff,%r9
   1407cafe0:	ff 0f 00 
   1407cafe3:	49 d3 e9             	shr    %cl,%r9
   1407cafe6:	49 f7 d1             	not    %r9
   1407cafe9:	4d 21 c8             	and    %r9,%r8
   1407cafec:	eb 03                	jmp    0x1407caff1
   1407cafee:	49 89 c8             	mov    %rcx,%r8
   1407caff1:	f2 0f 10 0d 4f ae 40 	movsd  0x40ae4f(%rip),%xmm1        # 0x140bd5e48
   1407caff8:	00 
   1407caff9:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407caffd:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cb002:	48 89 ca             	mov    %rcx,%rdx
   1407cb005:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cb009:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cb00f:	90                   	nop
   1407cb010:	90                   	nop
   1407cb011:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cb018:	73 2a                	jae    0x1407cb044
   1407cb01a:	49 b9 00 00 00 00 00 	movabs $0x8000000000000000,%r9
   1407cb021:	00 00 80 
   1407cb024:	4c 21 c9             	and    %r9,%rcx
   1407cb027:	49 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%r9
   1407cb02e:	00 f0 3f 
   1407cb031:	49 09 c9             	or     %rcx,%r9
   1407cb034:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cb03b:	49 0f 44 c9          	cmove  %r9,%rcx
   1407cb03f:	49 89 c9             	mov    %rcx,%r9
   1407cb042:	eb 3e                	jmp    0x1407cb082
   1407cb044:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cb04b:	73 32                	jae    0x1407cb07f
   1407cb04d:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cb054:	48 89 c8             	mov    %rcx,%rax
   1407cb057:	48 89 d1             	mov    %rdx,%rcx
   1407cb05a:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407cb061:	00 08 00 
   1407cb064:	49 d3 e9             	shr    %cl,%r9
   1407cb067:	49 01 c1             	add    %rax,%r9
   1407cb06a:	49 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%r10
   1407cb071:	ff 0f 00 
   1407cb074:	49 d3 ea             	shr    %cl,%r10
   1407cb077:	49 f7 d2             	not    %r10
   1407cb07a:	4d 21 d1             	and    %r10,%r9
   1407cb07d:	eb 03                	jmp    0x1407cb082
   1407cb07f:	49 89 c9             	mov    %rcx,%r9
   1407cb082:	29 df                	sub    %ebx,%edi
   1407cb084:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407cb089:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cb08d:	66 49 0f 6e c0       	movq   %r8,%xmm0
   1407cb092:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407cb096:	01 d1                	add    %edx,%ecx
   1407cb098:	66 49 0f 6e c1       	movq   %r9,%xmm0
   1407cb09d:	f2 0f 2c d8          	cvttsd2si %xmm0,%ebx
   1407cb0a1:	29 df                	sub    %ebx,%edi
   1407cb0a3:	8d 04 3a             	lea    (%rdx,%rdi,1),%eax
   1407cb0a6:	90                   	nop
   1407cb0a7:	85 c9                	test   %ecx,%ecx
   1407cb0a9:	74 2d                	je     0x1407cb0d8
   1407cb0ab:	83 f9 ff             	cmp    $0xffffffff,%ecx
   1407cb0ae:	75 06                	jne    0x1407cb0b6
   1407cb0b0:	f7 d8                	neg    %eax
   1407cb0b2:	31 d2                	xor    %edx,%edx
   1407cb0b4:	eb 03                	jmp    0x1407cb0b9
   1407cb0b6:	99                   	cltd
   1407cb0b7:	f7 f9                	idiv   %ecx
   1407cb0b9:	48 63 c8             	movslq %eax,%rcx
   1407cb0bc:	48 83 f9 03          	cmp    $0x3,%rcx
   1407cb0c0:	ba 03 00 00 00       	mov    $0x3,%edx
   1407cb0c5:	48 0f 4c d1          	cmovl  %rcx,%rdx
   1407cb0c9:	48 83 fa 01          	cmp    $0x1,%rdx
   1407cb0cd:	b8 01 00 00 00       	mov    $0x1,%eax
   1407cb0d2:	48 0f 4f c2          	cmovg  %rdx,%rax
   1407cb0d6:	5d                   	pop    %rbp
   1407cb0d7:	c3                   	ret
   1407cb0d8:	e8 23 2c 88 ff       	call   0x14004dd00
   1407cb0dd:	90                   	nop
   1407cb0de:	cc                   	int3
   1407cb0df:	cc                   	int3

# main.fontForToast @ 0x1407cb0e0
   1407cb0e0:	4c 8d a4 24 18 ff ff 	lea    -0xe8(%rsp),%r12
   1407cb0e7:	ff 
   1407cb0e8:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407cb0ec:	0f 86 9f 04 00 00    	jbe    0x1407cb591
   1407cb0f2:	55                   	push   %rbp
   1407cb0f3:	48 89 e5             	mov    %rsp,%rbp
   1407cb0f6:	48 81 ec 60 01 00 00 	sub    $0x160,%rsp
   1407cb0fd:	f2 0f 11 84 24 70 01 	movsd  %xmm0,0x170(%rsp)
   1407cb104:	00 00 
   1407cb106:	48 89 9c 24 80 01 00 	mov    %rbx,0x180(%rsp)
   1407cb10d:	00 
   1407cb10e:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
   1407cb115:	00 
   1407cb116:	f2 0f 10 0d 6a ad 40 	movsd  0x40ad6a(%rip),%xmm1        # 0x140bd5e88
   1407cb11d:	00 
   1407cb11e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cb122:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cb127:	48 89 ca             	mov    %rcx,%rdx
   1407cb12a:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cb12e:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cb134:	90                   	nop
   1407cb135:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cb13c:	73 27                	jae    0x1407cb165
   1407cb13e:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407cb145:	00 00 80 
   1407cb148:	48 21 ce             	and    %rcx,%rsi
   1407cb14b:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407cb152:	00 f0 3f 
   1407cb155:	48 09 f7             	or     %rsi,%rdi
   1407cb158:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cb15f:	48 0f 44 f7          	cmove  %rdi,%rsi
   1407cb163:	eb 40                	jmp    0x1407cb1a5
   1407cb165:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cb16c:	73 34                	jae    0x1407cb1a2
   1407cb16e:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cb175:	48 89 ce             	mov    %rcx,%rsi
   1407cb178:	48 89 d1             	mov    %rdx,%rcx
   1407cb17b:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407cb182:	00 08 00 
   1407cb185:	48 d3 ef             	shr    %cl,%rdi
   1407cb188:	48 01 fe             	add    %rdi,%rsi
   1407cb18b:	48 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%rdi
   1407cb192:	ff 0f 00 
   1407cb195:	48 d3 ef             	shr    %cl,%rdi
   1407cb198:	48 f7 d7             	not    %rdi
   1407cb19b:	48 21 fe             	and    %rdi,%rsi
   1407cb19e:	66 90                	xchg   %ax,%ax
   1407cb1a0:	eb 03                	jmp    0x1407cb1a5
   1407cb1a2:	48 89 ce             	mov    %rcx,%rsi
   1407cb1a5:	48 8b 1d 24 f3 27 04 	mov    0x427f324(%rip),%rbx        # 0x144a4a4d0
   1407cb1ac:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407cb1b1:	f2 48 0f 2c c8       	cvttsd2si %xmm0,%rcx
   1407cb1b6:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   1407cb1bb:	90                   	nop
   1407cb1bc:	48 8d 05 4d f5 b1 00 	lea    0xb1f54d(%rip),%rax        # 0x1412ea710
   1407cb1c3:	e8 f8 0b 84 ff       	call   0x14000bdc0
   1407cb1c8:	48 8b 18             	mov    (%rax),%rbx
   1407cb1cb:	48 85 db             	test   %rbx,%rbx
   1407cb1ce:	0f 85 78 01 00 00    	jne    0x1407cb34c
   1407cb1d4:	e8 c7 9d 8b ff       	call   0x140084fa0
   1407cb1d9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   1407cb1de:	48 c7 84 24 80 00 00 	movq   $0x5,0x80(%rsp)
   1407cb1e5:	00 05 00 00 00 
   1407cb1ea:	48 8d 0d ab 76 0b 00 	lea    0xb76ab(%rip),%rcx        # 0x14088289c
   1407cb1f1:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   1407cb1f6:	48 c7 84 24 88 00 00 	movq   $0xb,0x88(%rsp)
   1407cb1fd:	00 0b 00 00 00 
   1407cb202:	48 c7 84 24 90 00 00 	movq   $0x2bc,0x90(%rsp)
   1407cb209:	00 bc 02 00 00 
   1407cb20e:	48 c7 84 24 a0 00 00 	movq   $0x4,0xa0(%rsp)
   1407cb215:	00 04 00 00 00 
   1407cb21a:	48 8d 0d 1f 63 0b 00 	lea    0xb631f(%rip),%rcx        # 0x140881540
   1407cb221:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
   1407cb228:	00 
   1407cb229:	48 c7 84 24 a8 00 00 	movq   $0xb,0xa8(%rsp)
   1407cb230:	00 0b 00 00 00 
   1407cb235:	48 c7 84 24 b0 00 00 	movq   $0x190,0xb0(%rsp)
   1407cb23c:	00 90 01 00 00 
   1407cb241:	48 c7 84 24 c0 00 00 	movq   $0x6,0xc0(%rsp)
   1407cb248:	00 06 00 00 00 
   1407cb24d:	48 8d 0d 5f 96 0b 00 	lea    0xb965f(%rip),%rcx        # 0x1408848b3
   1407cb254:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
   1407cb25b:	00 
   1407cb25c:	48 c7 84 24 c8 00 00 	movq   $0xe,0xc8(%rsp)
   1407cb263:	00 0e 00 00 00 
   1407cb268:	48 c7 84 24 d0 00 00 	movq   $0x258,0xd0(%rsp)
   1407cb26f:	00 58 02 00 00 
   1407cb274:	48 c7 84 24 e0 00 00 	movq   $0x7,0xe0(%rsp)
   1407cb27b:	00 07 00 00 00 
   1407cb280:	48 8d 0d 0c bc 0b 00 	lea    0xbbc0c(%rip),%rcx        # 0x140886e93
   1407cb287:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
   1407cb28e:	00 
   1407cb28f:	48 c7 84 24 e8 00 00 	movq   $0x13,0xe8(%rsp)
   1407cb296:	00 13 00 00 00 
   1407cb29b:	48 c7 84 24 f0 00 00 	movq   $0x2bc,0xf0(%rsp)
   1407cb2a2:	00 bc 02 00 00 
   1407cb2a7:	48 c7 84 24 00 01 00 	movq   $0x5,0x100(%rsp)
   1407cb2ae:	00 05 00 00 00 
   1407cb2b3:	48 8d 0d e7 75 0b 00 	lea    0xb75e7(%rip),%rcx        # 0x1408828a1
   1407cb2ba:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
   1407cb2c1:	00 
   1407cb2c2:	48 c7 84 24 08 01 00 	movq   $0xc,0x108(%rsp)
   1407cb2c9:	00 0c 00 00 00 
   1407cb2ce:	48 c7 84 24 10 01 00 	movq   $0x190,0x110(%rsp)
   1407cb2d5:	00 90 01 00 00 
   1407cb2da:	48 c7 84 24 20 01 00 	movq   $0x6,0x120(%rsp)
   1407cb2e1:	00 06 00 00 00 
   1407cb2e6:	48 8d 0d d4 96 0b 00 	lea    0xb96d4(%rip),%rcx        # 0x1408849c1
   1407cb2ed:	48 89 8c 24 18 01 00 	mov    %rcx,0x118(%rsp)
   1407cb2f4:	00 
   1407cb2f5:	48 c7 84 24 28 01 00 	movq   $0xc,0x128(%rsp)
   1407cb2fc:	00 0c 00 00 00 
   1407cb301:	48 c7 84 24 30 01 00 	movq   $0x258,0x130(%rsp)
   1407cb308:	00 58 02 00 00 
   1407cb30d:	48 c7 84 24 40 01 00 	movq   $0x5,0x140(%rsp)
   1407cb314:	00 05 00 00 00 
   1407cb319:	48 8d 0d b3 75 0b 00 	lea    0xb75b3(%rip),%rcx        # 0x1408828d3
   1407cb320:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
   1407cb327:	00 
   1407cb328:	48 c7 84 24 48 01 00 	movq   $0xb,0x148(%rsp)
   1407cb32f:	00 0b 00 00 00 
   1407cb334:	48 c7 84 24 50 01 00 	movq   $0x258,0x150(%rsp)
   1407cb33b:	00 58 02 00 00 
   1407cb340:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
   1407cb345:	31 d2                	xor    %edx,%edx
   1407cb347:	e9 38 01 00 00       	jmp    0x1407cb484
   1407cb34c:	48 8d 05 5d 42 b2 00 	lea    0xb2425d(%rip),%rax        # 0x1412ef5b0
   1407cb353:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
   1407cb35a:	00 
   1407cb35b:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
   1407cb362:	00 
   1407cb363:	e8 58 15 84 ff       	call   0x14000c8c0
   1407cb368:	48 8b 00             	mov    (%rax),%rax
   1407cb36b:	48 81 c4 60 01 00 00 	add    $0x160,%rsp
   1407cb372:	5d                   	pop    %rbp
   1407cb373:	c3                   	ret
   1407cb374:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   1407cb379:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
   1407cb37d:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   1407cb382:	48 8b 0b             	mov    (%rbx),%rcx
   1407cb385:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   1407cb38a:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
   1407cb38e:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   1407cb393:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407cb398:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cb39c:	f7 d9                	neg    %ecx
   1407cb39e:	48 63 c9             	movslq %ecx,%rcx
   1407cb3a1:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
   1407cb3a6:	90                   	nop
   1407cb3a7:	48 8d 05 e4 5f 0c 00 	lea    0xc5fe4(%rip),%rax        # 0x140891392
   1407cb3ae:	bb 0d 00 00 00       	mov    $0xd,%ebx
   1407cb3b3:	e8 68 e5 fc ff       	call   0x140799920
   1407cb3b8:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
   1407cb3bf:	00 
   1407cb3c0:	48 8d 05 f1 0f af 00 	lea    0xaf0ff1(%rip),%rax        # 0x1412bc3b8
   1407cb3c7:	e8 34 6a 85 ff       	call   0x140021e00
   1407cb3cc:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   1407cb3d1:	48 89 08             	mov    %rcx,(%rax)
   1407cb3d4:	44 0f 11 78 08       	movups %xmm15,0x8(%rax)
   1407cb3d9:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
   1407cb3e0:	00 
   1407cb3e1:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1407cb3e6:	48 89 48 20          	mov    %rcx,0x20(%rax)
   1407cb3ea:	44 0f 11 78 28       	movups %xmm15,0x28(%rax)
   1407cb3ef:	48 c7 40 38 00 00 00 	movq   $0x0,0x38(%rax)
   1407cb3f6:	00 
   1407cb3f7:	48 c7 40 40 01 00 00 	movq   $0x1,0x40(%rax)
   1407cb3fe:	00 
   1407cb3ff:	44 0f 11 78 48       	movups %xmm15,0x48(%rax)
   1407cb404:	48 c7 40 58 05 00 00 	movq   $0x5,0x58(%rax)
   1407cb40b:	00 
   1407cb40c:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
   1407cb413:	00 
   1407cb414:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   1407cb41b:	00 
   1407cb41c:	48 89 48 68          	mov    %rcx,0x68(%rax)
   1407cb420:	48 8b 0d 31 fb 21 04 	mov    0x421fb31(%rip),%rcx        # 0x1449eaf58
   1407cb427:	48 8d 1d d7 2d 0c 00 	lea    0xc2dd7(%rip),%rbx        # 0x14088e205
   1407cb42e:	48 89 c7             	mov    %rax,%rdi
   1407cb431:	be 0e 00 00 00       	mov    $0xe,%esi
   1407cb436:	41 89 f0             	mov    %esi,%r8d
   1407cb439:	48 89 c8             	mov    %rcx,%rax
   1407cb43c:	b9 0b 00 00 00       	mov    $0xb,%ecx
   1407cb441:	e8 5a e5 fc ff       	call   0x1407999a0
   1407cb446:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   1407cb44b:	48 8d 05 5e 41 b2 00 	lea    0xb2415e(%rip),%rax        # 0x1412ef5b0
   1407cb452:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   1407cb457:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   1407cb45c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   1407cb461:	e8 5a 17 84 ff       	call   0x14000cbc0
   1407cb466:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   1407cb46b:	48 89 08             	mov    %rcx,(%rax)
   1407cb46e:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   1407cb473:	48 83 c1 20          	add    $0x20,%rcx
   1407cb477:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   1407cb47c:	48 ff c2             	inc    %rdx
   1407cb47f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   1407cb484:	48 83 fa 07          	cmp    $0x7,%rdx
   1407cb488:	0f 8d bc 00 00 00    	jge    0x1407cb54a
   1407cb48e:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   1407cb493:	48 8b 71 10          	mov    0x10(%rcx),%rsi
   1407cb497:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cb49a:	f2 48 0f 2a c6       	cvtsi2sd %rsi,%xmm0
   1407cb49f:	f2 0f 10 8c 24 70 01 	movsd  0x170(%rsp),%xmm1
   1407cb4a6:	00 00 
   1407cb4a8:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cb4ac:	66 48 0f 7e c6       	movq   %xmm0,%rsi
   1407cb4b1:	48 89 f7             	mov    %rsi,%rdi
   1407cb4b4:	48 c1 ee 34          	shr    $0x34,%rsi
   1407cb4b8:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407cb4be:	90                   	nop
   1407cb4bf:	90                   	nop
   1407cb4c0:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407cb4c7:	73 37                	jae    0x1407cb500
   1407cb4c9:	49 b8 00 00 00 00 00 	movabs $0x8000000000000000,%r8
   1407cb4d0:	00 00 80 
   1407cb4d3:	4c 21 c7             	and    %r8,%rdi
   1407cb4d6:	49 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%r9
   1407cb4dd:	00 f0 3f 
   1407cb4e0:	49 09 f9             	or     %rdi,%r9
   1407cb4e3:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407cb4ea:	49 0f 44 f9          	cmove  %r9,%rdi
   1407cb4ee:	48 89 cb             	mov    %rcx,%rbx
   1407cb4f1:	48 89 fe             	mov    %rdi,%rsi
   1407cb4f4:	e9 7b fe ff ff       	jmp    0x1407cb374
   1407cb4f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407cb500:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407cb507:	73 36                	jae    0x1407cb53f
   1407cb509:	4c 8d 86 01 fc ff ff 	lea    -0x3ff(%rsi),%r8
   1407cb510:	48 89 cb             	mov    %rcx,%rbx
   1407cb513:	4c 89 c1             	mov    %r8,%rcx
   1407cb516:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407cb51d:	00 08 00 
   1407cb520:	49 d3 e9             	shr    %cl,%r9
   1407cb523:	4a 8d 34 0f          	lea    (%rdi,%r9,1),%rsi
   1407cb527:	48 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%rdi
   1407cb52e:	ff 0f 00 
   1407cb531:	48 d3 ef             	shr    %cl,%rdi
   1407cb534:	48 f7 d7             	not    %rdi
   1407cb537:	48 21 fe             	and    %rdi,%rsi
   1407cb53a:	e9 35 fe ff ff       	jmp    0x1407cb374
   1407cb53f:	48 89 cb             	mov    %rcx,%rbx
   1407cb542:	48 89 fe             	mov    %rdi,%rsi
   1407cb545:	e9 2a fe ff ff       	jmp    0x1407cb374
   1407cb54a:	48 8b 1d 7f ef 27 04 	mov    0x427ef7f(%rip),%rbx        # 0x144a4a4d0
   1407cb551:	48 8d 05 b8 f1 b1 00 	lea    0xb1f1b8(%rip),%rax        # 0x1412ea710
   1407cb558:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   1407cb55d:	0f 1f 00             	nopl   (%rax)
   1407cb560:	e8 fb 0a 84 ff       	call   0x14000c060
   1407cb565:	83 3d f4 a3 2c 04 00 	cmpl   $0x0,0x42ca3f4(%rip)        # 0x144a95960
   1407cb56c:	75 07                	jne    0x1407cb575
   1407cb56e:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   1407cb573:	eb 14                	jmp    0x1407cb589
   1407cb575:	48 8b 10             	mov    (%rax),%rdx
   1407cb578:	e8 63 28 8c ff       	call   0x14008dde0
   1407cb57d:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   1407cb582:	49 89 1b             	mov    %rbx,(%r11)
   1407cb585:	49 89 53 08          	mov    %rdx,0x8(%r11)
   1407cb589:	48 89 18             	mov    %rbx,(%rax)
   1407cb58c:	e9 bb fd ff ff       	jmp    0x1407cb34c
   1407cb591:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
   1407cb597:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1407cb59c:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   1407cb5a1:	e8 9a 0d 8c ff       	call   0x14008c340
   1407cb5a6:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
   1407cb5ac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   1407cb5b1:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   1407cb5b6:	e9 25 fb ff ff       	jmp    0x1407cb0e0
   1407cb5bb:	cc                   	int3
   1407cb5bc:	cc                   	int3
   1407cb5bd:	cc                   	int3
   1407cb5be:	cc                   	int3
   1407cb5bf:	cc                   	int3

# main.registerToastClass @ 0x1407cb5c0
   1407cb5c0:	4c 8d 64 24 d8       	lea    -0x28(%rsp),%r12
   1407cb5c5:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407cb5c9:	0f 86 c5 01 00 00    	jbe    0x1407cb794
   1407cb5cf:	55                   	push   %rbp
   1407cb5d0:	48 89 e5             	mov    %rsp,%rbp
   1407cb5d3:	48 81 ec a0 00 00 00 	sub    $0xa0,%rsp
   1407cb5da:	b8 50 00 00 00       	mov    $0x50,%eax
   1407cb5df:	48 8d 1d aa 6c c2 00 	lea    0xc26caa(%rip),%rbx        # 0x1413f2290
   1407cb5e6:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cb5eb:	e8 70 83 85 ff       	call   0x140023960
   1407cb5f0:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   1407cb5f7:	00 
   1407cb5f8:	48 8d 05 89 cb b1 00 	lea    0xb1cb89(%rip),%rax        # 0x1412e8188
   1407cb5ff:	48 8d 1d 6a 1a c5 00 	lea    0xc51a6a(%rip),%rbx        # 0x14141d070
   1407cb606:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cb60b:	e8 f0 ed 8b ff       	call   0x14008a400
   1407cb610:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   1407cb615:	48 8d 05 ce 70 0c 00 	lea    0xc70ce(%rip),%rax        # 0x1408926ea
   1407cb61c:	bb 0e 00 00 00       	mov    $0xe,%ebx
   1407cb621:	e8 fa e2 fc ff       	call   0x140799920
   1407cb626:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   1407cb62b:	b8 10 00 00 00       	mov    $0x10,%eax
   1407cb630:	48 8d 1d 11 32 af 00 	lea    0xaf3211(%rip),%rbx        # 0x1412be848
   1407cb637:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cb63c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cb640:	e8 1b 8a 85 ff       	call   0x140024060
   1407cb645:	48 c7 40 08 89 7f 00 	movq   $0x7f89,0x8(%rax)
   1407cb64c:	00 
   1407cb64d:	48 8b 15 f4 f8 21 04 	mov    0x421f8f4(%rip),%rdx        # 0x1449eaf48
   1407cb654:	48 8d 1d cb 2b 0c 00 	lea    0xc2bcb(%rip),%rbx        # 0x14088e226
   1407cb65b:	b9 0b 00 00 00       	mov    $0xb,%ecx
   1407cb660:	48 89 c7             	mov    %rax,%rdi
   1407cb663:	be 02 00 00 00       	mov    $0x2,%esi
   1407cb668:	41 89 f0             	mov    %esi,%r8d
   1407cb66b:	48 89 d0             	mov    %rdx,%rax
   1407cb66e:	e8 2d e3 fc ff       	call   0x1407999a0
   1407cb673:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   1407cb678:	48 8d 15 11 6b 41 00 	lea    0x416b11(%rip),%rdx        # 0x140be2190
   1407cb67f:	44 0f 10 32          	movups (%rdx),%xmm14
   1407cb683:	44 0f 11 31          	movups %xmm14,(%rcx)
   1407cb687:	44 0f 10 72 10       	movups 0x10(%rdx),%xmm14
   1407cb68c:	44 0f 11 71 10       	movups %xmm14,0x10(%rcx)
   1407cb691:	44 0f 10 72 20       	movups 0x20(%rdx),%xmm14
   1407cb696:	44 0f 11 71 20       	movups %xmm14,0x20(%rcx)
   1407cb69b:	44 0f 10 72 30       	movups 0x30(%rdx),%xmm14
   1407cb6a0:	44 0f 11 71 30       	movups %xmm14,0x30(%rcx)
   1407cb6a5:	44 0f 10 72 40       	movups 0x40(%rdx),%xmm14
   1407cb6aa:	44 0f 11 71 40       	movups %xmm14,0x40(%rcx)
   1407cb6af:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   1407cb6b4:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   1407cb6b9:	48 8b 15 c0 9d 2c 04 	mov    0x42c9dc0(%rip),%rdx        # 0x144a95480
   1407cb6c0:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   1407cb6c5:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407cb6ca:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
   1407cb6d1:	00 
   1407cb6d2:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   1407cb6d7:	83 3d 82 a2 2c 04 00 	cmpl   $0x0,0x42ca282(%rip)        # 0x144a95960
   1407cb6de:	66 90                	xchg   %ax,%ax
   1407cb6e0:	74 19                	je     0x1407cb6fb
   1407cb6e2:	48 8d 05 a7 6b c2 00 	lea    0xc26ba7(%rip),%rax        # 0x1413f2290
   1407cb6e9:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
   1407cb6f0:	00 
   1407cb6f1:	e8 6a a6 85 ff       	call   0x140025d60
   1407cb6f6:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   1407cb6fb:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
   1407cb702:	00 
   1407cb703:	44 0f 10 31          	movups (%rcx),%xmm14
   1407cb707:	44 0f 11 32          	movups %xmm14,(%rdx)
   1407cb70b:	44 0f 10 71 10       	movups 0x10(%rcx),%xmm14
   1407cb710:	44 0f 11 72 10       	movups %xmm14,0x10(%rdx)
   1407cb715:	44 0f 10 71 20       	movups 0x20(%rcx),%xmm14
   1407cb71a:	44 0f 11 72 20       	movups %xmm14,0x20(%rdx)
   1407cb71f:	44 0f 10 71 30       	movups 0x30(%rcx),%xmm14
   1407cb724:	44 0f 11 72 30       	movups %xmm14,0x30(%rdx)
   1407cb729:	44 0f 10 71 40       	movups 0x40(%rcx),%xmm14
   1407cb72e:	44 0f 11 72 40       	movups %xmm14,0x40(%rdx)
   1407cb733:	c7 02 50 00 00 00    	movl   $0x50,(%rdx)
   1407cb739:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407cb73e:	b8 08 00 00 00       	mov    $0x8,%eax
   1407cb743:	48 8d 1d 26 1e af 00 	lea    0xaf1e26(%rip),%rbx        # 0x1412bd570
   1407cb74a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cb74f:	e8 2c 86 85 ff       	call   0x140023d80
   1407cb754:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   1407cb759:	48 89 10             	mov    %rdx,(%rax)
   1407cb75c:	48 8b 15 e5 f7 21 04 	mov    0x421f7e5(%rip),%rdx        # 0x1449eaf48
   1407cb763:	48 8d 1d 5e 9c 0c 00 	lea    0xc9c5e(%rip),%rbx        # 0x1408953c8
   1407cb76a:	b9 10 00 00 00       	mov    $0x10,%ecx
   1407cb76f:	48 89 c7             	mov    %rax,%rdi
   1407cb772:	be 01 00 00 00       	mov    $0x1,%esi
   1407cb777:	41 89 f0             	mov    %esi,%r8d
   1407cb77a:	48 89 d0             	mov    %rdx,%rax
   1407cb77d:	0f 1f 00             	nopl   (%rax)
   1407cb780:	e8 1b e2 fc ff       	call   0x1407999a0
   1407cb785:	48 85 c0             	test   %rax,%rax
   1407cb788:	0f 95 c0             	setne  %al
   1407cb78b:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   1407cb792:	5d                   	pop    %rbp
   1407cb793:	c3                   	ret
   1407cb794:	e8 a7 0b 8c ff       	call   0x14008c340
   1407cb799:	e9 22 fe ff ff       	jmp    0x1407cb5c0
   1407cb79e:	cc                   	int3
   1407cb79f:	cc                   	int3

# main.fillToasts @ 0x1407cbbc0
   1407cbbc0:	4c 8d a4 24 88 fd ff 	lea    -0x278(%rsp),%r12
   1407cbbc7:	ff 
   1407cbbc8:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407cbbcc:	0f 86 63 11 00 00    	jbe    0x1407ccd35
   1407cbbd2:	55                   	push   %rbp
   1407cbbd3:	48 89 e5             	mov    %rsp,%rbp
   1407cbbd6:	48 81 ec f0 02 00 00 	sub    $0x2f0,%rsp
   1407cbbdd:	80 3d 65 97 2c 04 00 	cmpb   $0x0,0x42c9765(%rip)        # 0x144a95349
   1407cbbe4:	75 3f                	jne    0x1407cbc25
   1407cbbe6:	e8 75 8b 00 00       	call   0x1407d4760
   1407cbbeb:	f2 0f 11 84 24 c8 00 	movsd  %xmm0,0xc8(%rsp)
   1407cbbf2:	00 00 
   1407cbbf4:	89 84 24 bc 00 00 00 	mov    %eax,0xbc(%rsp)
   1407cbbfb:	89 8c 24 b8 00 00 00 	mov    %ecx,0xb8(%rsp)
   1407cbc02:	89 bc 24 b4 00 00 00 	mov    %edi,0xb4(%rsp)
   1407cbc09:	e8 b2 f2 ff ff       	call   0x1407caec0
   1407cbc0e:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   1407cbc15:	00 
   1407cbc16:	31 c9                	xor    %ecx,%ecx
   1407cbc18:	31 d2                	xor    %edx,%edx
   1407cbc1a:	31 db                	xor    %ebx,%ebx
   1407cbc1c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cbc20:	e9 87 00 00 00       	jmp    0x1407cbcac
   1407cbc25:	48 81 c4 f0 02 00 00 	add    $0x2f0,%rsp
   1407cbc2c:	5d                   	pop    %rbp
   1407cbc2d:	c3                   	ret
   1407cbc2e:	45 0f 10 31          	movups (%r9),%xmm14
   1407cbc32:	45 0f 11 30          	movups %xmm14,(%r8)
   1407cbc36:	45 0f 10 71 10       	movups 0x10(%r9),%xmm14
   1407cbc3b:	45 0f 11 70 10       	movups %xmm14,0x10(%r8)
   1407cbc40:	45 0f 10 71 20       	movups 0x20(%r9),%xmm14
   1407cbc45:	45 0f 11 70 20       	movups %xmm14,0x20(%r8)
   1407cbc4a:	45 0f 10 71 30       	movups 0x30(%r9),%xmm14
   1407cbc4f:	45 0f 11 70 30       	movups %xmm14,0x30(%r8)
   1407cbc54:	45 0f 10 71 40       	movups 0x40(%r9),%xmm14
   1407cbc59:	45 0f 11 70 40       	movups %xmm14,0x40(%r8)
   1407cbc5e:	45 0f 10 71 50       	movups 0x50(%r9),%xmm14
   1407cbc63:	45 0f 11 70 50       	movups %xmm14,0x50(%r8)
   1407cbc68:	45 0f 10 71 60       	movups 0x60(%r9),%xmm14
   1407cbc6d:	45 0f 11 70 60       	movups %xmm14,0x60(%r8)
   1407cbc72:	45 0f 10 71 70       	movups 0x70(%r9),%xmm14
   1407cbc77:	45 0f 11 70 70       	movups %xmm14,0x70(%r8)
   1407cbc7c:	45 0f 10 b1 80 00 00 	movups 0x80(%r9),%xmm14
   1407cbc83:	00 
   1407cbc84:	45 0f 11 b0 80 00 00 	movups %xmm14,0x80(%r8)
   1407cbc8b:	00 
   1407cbc8c:	45 0f 10 b1 90 00 00 	movups 0x90(%r9),%xmm14
   1407cbc93:	00 
   1407cbc94:	45 0f 11 b0 90 00 00 	movups %xmm14,0x90(%r8)
   1407cbc9b:	00 
   1407cbc9c:	45 0f 10 b1 a0 00 00 	movups 0xa0(%r9),%xmm14
   1407cbca3:	00 
   1407cbca4:	45 0f 11 b0 a0 00 00 	movups %xmm14,0xa0(%r8)
   1407cbcab:	00 
   1407cbcac:	48 39 05 dd 25 28 04 	cmp    %rax,0x42825dd(%rip)        # 0x144a4e290
   1407cbcb3:	0f 8d b4 03 00 00    	jge    0x1407cc06d
   1407cbcb9:	48 83 3d e7 25 28 04 	cmpq   $0x0,0x42825e7(%rip)        # 0x144a4e2a8
   1407cbcc0:	00 
   1407cbcc1:	0f 84 a6 03 00 00    	je     0x1407cc06d
   1407cbcc7:	4c 8b 05 d2 25 28 04 	mov    0x42825d2(%rip),%r8        # 0x144a4e2a0
   1407cbcce:	48 ff 05 ab 25 28 04 	incq   0x42825ab(%rip)        # 0x144a4e280
   1407cbcd5:	4c 8d 8c 24 58 01 00 	lea    0x158(%rsp),%r9
   1407cbcdc:	00 
   1407cbcdd:	45 0f 11 39          	movups %xmm15,(%r9)
   1407cbce1:	45 0f 11 79 10       	movups %xmm15,0x10(%r9)
   1407cbce6:	45 0f 11 79 20       	movups %xmm15,0x20(%r9)
   1407cbceb:	45 0f 11 79 30       	movups %xmm15,0x30(%r9)
   1407cbcf0:	45 0f 11 79 40       	movups %xmm15,0x40(%r9)
   1407cbcf5:	45 0f 11 79 50       	movups %xmm15,0x50(%r9)
   1407cbcfa:	45 0f 11 79 60       	movups %xmm15,0x60(%r9)
   1407cbcff:	45 0f 11 79 70       	movups %xmm15,0x70(%r9)
   1407cbd04:	45 0f 11 b9 80 00 00 	movups %xmm15,0x80(%r9)
   1407cbd0b:	00 
   1407cbd0c:	45 0f 11 b9 90 00 00 	movups %xmm15,0x90(%r9)
   1407cbd13:	00 
   1407cbd14:	45 0f 11 b9 a0 00 00 	movups %xmm15,0xa0(%r9)
   1407cbd1b:	00 
   1407cbd1c:	4c 8b 15 5d 25 28 04 	mov    0x428255d(%rip),%r10        # 0x144a4e280
   1407cbd23:	4c 89 94 24 58 01 00 	mov    %r10,0x158(%rsp)
   1407cbd2a:	00 
   1407cbd2b:	4c 8d 94 24 60 01 00 	lea    0x160(%rsp),%r10
   1407cbd32:	00 
   1407cbd33:	45 0f 10 30          	movups (%r8),%xmm14
   1407cbd37:	45 0f 11 32          	movups %xmm14,(%r10)
   1407cbd3b:	45 0f 10 70 10       	movups 0x10(%r8),%xmm14
   1407cbd40:	45 0f 11 72 10       	movups %xmm14,0x10(%r10)
   1407cbd45:	45 0f 10 70 20       	movups 0x20(%r8),%xmm14
   1407cbd4a:	45 0f 11 72 20       	movups %xmm14,0x20(%r10)
   1407cbd4f:	45 0f 10 70 30       	movups 0x30(%r8),%xmm14
   1407cbd54:	45 0f 11 72 30       	movups %xmm14,0x30(%r10)
   1407cbd59:	45 0f 10 70 40       	movups 0x40(%r8),%xmm14
   1407cbd5e:	45 0f 11 72 40       	movups %xmm14,0x40(%r10)
   1407cbd63:	45 0f 10 70 50       	movups 0x50(%r8),%xmm14
   1407cbd68:	45 0f 11 72 50       	movups %xmm14,0x50(%r10)
   1407cbd6d:	45 0f 10 70 60       	movups 0x60(%r8),%xmm14
   1407cbd72:	45 0f 11 72 60       	movups %xmm14,0x60(%r10)
   1407cbd77:	45 0f 10 70 70       	movups 0x70(%r8),%xmm14
   1407cbd7c:	45 0f 11 72 70       	movups %xmm14,0x70(%r10)
   1407cbd81:	45 0f 10 b0 80 00 00 	movups 0x80(%r8),%xmm14
   1407cbd88:	00 
   1407cbd89:	45 0f 11 b2 80 00 00 	movups %xmm14,0x80(%r10)
   1407cbd90:	00 
   1407cbd91:	45 0f 10 b0 90 00 00 	movups 0x90(%r8),%xmm14
   1407cbd98:	00 
   1407cbd99:	45 0f 11 b2 90 00 00 	movups %xmm14,0x90(%r10)
   1407cbda0:	00 
   1407cbda1:	45 0f 10 b0 98 00 00 	movups 0x98(%r8),%xmm14
   1407cbda8:	00 
   1407cbda9:	45 0f 11 b2 98 00 00 	movups %xmm14,0x98(%r10)
   1407cbdb0:	00 
   1407cbdb1:	4c 8b 05 f0 24 28 04 	mov    0x42824f0(%rip),%r8        # 0x144a4e2a8
   1407cbdb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   1407cbdbf:	00 
   1407cbdc0:	49 83 f8 01          	cmp    $0x1,%r8
   1407cbdc4:	0f 82 65 0f 00 00    	jb     0x1407ccd2f
   1407cbdca:	4c 8b 15 cf 24 28 04 	mov    0x42824cf(%rip),%r10        # 0x144a4e2a0
   1407cbdd1:	4c 8b 1d d8 24 28 04 	mov    0x42824d8(%rip),%r11        # 0x144a4e2b0
   1407cbdd8:	49 ff cb             	dec    %r11
   1407cbddb:	49 ff c8             	dec    %r8
   1407cbdde:	4c 89 05 c3 24 28 04 	mov    %r8,0x42824c3(%rip)        # 0x144a4e2a8
   1407cbde5:	4c 89 1d c4 24 28 04 	mov    %r11,0x42824c4(%rip)        # 0x144a4e2b0
   1407cbdec:	49 f7 db             	neg    %r11
   1407cbdef:	49 c1 fb 3f          	sar    $0x3f,%r11
   1407cbdf3:	41 81 e3 a8 00 00 00 	and    $0xa8,%r11d
   1407cbdfa:	4f 8d 04 1a          	lea    (%r10,%r11,1),%r8
   1407cbdfe:	83 3d 5b 9b 2c 04 00 	cmpl   $0x0,0x42c9b5b(%rip)        # 0x144a95960
   1407cbe05:	74 13                	je     0x1407cbe1a
   1407cbe07:	4c 8b 15 92 24 28 04 	mov    0x4282492(%rip),%r10        # 0x144a4e2a0
   1407cbe0e:	e8 cd 1f 8c ff       	call   0x14008dde0
   1407cbe13:	4d 89 03             	mov    %r8,(%r11)
   1407cbe16:	4d 89 53 08          	mov    %r10,0x8(%r11)
   1407cbe1a:	48 89 94 24 b8 02 00 	mov    %rdx,0x2b8(%rsp)
   1407cbe21:	00 
   1407cbe22:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
   1407cbe29:	00 
   1407cbe2a:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
   1407cbe31:	00 
   1407cbe32:	4c 89 05 67 24 28 04 	mov    %r8,0x4282467(%rip)        # 0x144a4e2a0
   1407cbe39:	4c 8b 05 58 24 28 04 	mov    0x4282458(%rip),%r8        # 0x144a4e298
   1407cbe40:	4c 8b 15 49 24 28 04 	mov    0x4282449(%rip),%r10        # 0x144a4e290
   1407cbe47:	49 ff c2             	inc    %r10
   1407cbe4a:	4c 8b 1d 37 24 28 04 	mov    0x4282437(%rip),%r11        # 0x144a4e288
   1407cbe51:	4d 39 d0             	cmp    %r10,%r8
   1407cbe54:	73 74                	jae    0x1407cbeca
   1407cbe56:	4c 89 d8             	mov    %r11,%rax
   1407cbe59:	4c 89 d3             	mov    %r10,%rbx
   1407cbe5c:	4c 89 c1             	mov    %r8,%rcx
   1407cbe5f:	bf 01 00 00 00       	mov    $0x1,%edi
   1407cbe64:	48 8d 35 d5 15 bc 00 	lea    0xbc15d5(%rip),%rsi        # 0x14138d440
   1407cbe6b:	e8 90 ce 8b ff       	call   0x140088d00
   1407cbe70:	48 89 0d 21 24 28 04 	mov    %rcx,0x4282421(%rip)        # 0x144a4e298
   1407cbe77:	83 3d e2 9a 2c 04 00 	cmpl   $0x0,0x42c9ae2(%rip)        # 0x144a95960
   1407cbe7e:	66 90                	xchg   %ax,%ax
   1407cbe80:	74 13                	je     0x1407cbe95
   1407cbe82:	48 8b 15 ff 23 28 04 	mov    0x42823ff(%rip),%rdx        # 0x144a4e288
   1407cbe89:	e8 52 1f 8c ff       	call   0x14008dde0
   1407cbe8e:	49 89 03             	mov    %rax,(%r11)
   1407cbe91:	49 89 53 08          	mov    %rdx,0x8(%r11)
   1407cbe95:	48 89 05 ec 23 28 04 	mov    %rax,0x42823ec(%rip)        # 0x144a4e288
   1407cbe9c:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   1407cbea3:	00 
   1407cbea4:	48 8b 94 24 b8 02 00 	mov    0x2b8(%rsp),%rdx
   1407cbeab:	00 
   1407cbeac:	4c 8d 8c 24 58 01 00 	lea    0x158(%rsp),%r9
   1407cbeb3:	00 
   1407cbeb4:	49 89 da             	mov    %rbx,%r10
   1407cbeb7:	49 89 c3             	mov    %rax,%r11
   1407cbeba:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   1407cbec1:	00 
   1407cbec2:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
   1407cbec9:	00 
   1407cbeca:	4c 89 15 bf 23 28 04 	mov    %r10,0x42823bf(%rip)        # 0x144a4e290
   1407cbed1:	4d 69 c2 b0 00 00 00 	imul   $0xb0,%r10,%r8
   1407cbed8:	4f 8d 04 03          	lea    (%r11,%r8,1),%r8
   1407cbedc:	4d 8d 80 50 ff ff ff 	lea    -0xb0(%r8),%r8
   1407cbee3:	83 3d 76 9a 2c 04 00 	cmpl   $0x0,0x42c9a76(%rip)        # 0x144a95960
   1407cbeea:	74 4a                	je     0x1407cbf36
   1407cbeec:	4c 89 84 24 e8 02 00 	mov    %r8,0x2e8(%rsp)
   1407cbef3:	00 
   1407cbef4:	48 8d 05 45 15 bc 00 	lea    0xbc1545(%rip),%rax        # 0x14138d440
   1407cbefb:	4c 89 c3             	mov    %r8,%rbx
   1407cbefe:	4c 89 c9             	mov    %r9,%rcx
   1407cbf01:	e8 5a 9e 85 ff       	call   0x140025d60
   1407cbf06:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   1407cbf0d:	00 
   1407cbf0e:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   1407cbf15:	00 
   1407cbf16:	48 8b 94 24 b8 02 00 	mov    0x2b8(%rsp),%rdx
   1407cbf1d:	00 
   1407cbf1e:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
   1407cbf25:	00 
   1407cbf26:	4c 8b 84 24 e8 02 00 	mov    0x2e8(%rsp),%r8
   1407cbf2d:	00 
   1407cbf2e:	4c 8d 8c 24 58 01 00 	lea    0x158(%rsp),%r9
   1407cbf35:	00 
   1407cbf36:	45 0f 10 31          	movups (%r9),%xmm14
   1407cbf3a:	45 0f 11 30          	movups %xmm14,(%r8)
   1407cbf3e:	45 0f 10 71 10       	movups 0x10(%r9),%xmm14
   1407cbf43:	45 0f 11 70 10       	movups %xmm14,0x10(%r8)
   1407cbf48:	45 0f 10 71 20       	movups 0x20(%r9),%xmm14
   1407cbf4d:	45 0f 11 70 20       	movups %xmm14,0x20(%r8)
   1407cbf52:	45 0f 10 71 30       	movups 0x30(%r9),%xmm14
   1407cbf57:	45 0f 11 70 30       	movups %xmm14,0x30(%r8)
   1407cbf5c:	45 0f 10 71 40       	movups 0x40(%r9),%xmm14
   1407cbf61:	45 0f 11 70 40       	movups %xmm14,0x40(%r8)
   1407cbf66:	45 0f 10 71 50       	movups 0x50(%r9),%xmm14
   1407cbf6b:	45 0f 11 70 50       	movups %xmm14,0x50(%r8)
   1407cbf70:	45 0f 10 71 60       	movups 0x60(%r9),%xmm14
   1407cbf75:	45 0f 11 70 60       	movups %xmm14,0x60(%r8)
   1407cbf7a:	45 0f 10 71 70       	movups 0x70(%r9),%xmm14
   1407cbf7f:	45 0f 11 70 70       	movups %xmm14,0x70(%r8)
   1407cbf84:	45 0f 10 b1 80 00 00 	movups 0x80(%r9),%xmm14
   1407cbf8b:	00 
   1407cbf8c:	45 0f 11 b0 80 00 00 	movups %xmm14,0x80(%r8)
   1407cbf93:	00 
   1407cbf94:	45 0f 10 b1 90 00 00 	movups 0x90(%r9),%xmm14
   1407cbf9b:	00 
   1407cbf9c:	45 0f 11 b0 90 00 00 	movups %xmm14,0x90(%r8)
   1407cbfa3:	00 
   1407cbfa4:	45 0f 10 b1 a0 00 00 	movups 0xa0(%r9),%xmm14
   1407cbfab:	00 
   1407cbfac:	45 0f 11 b0 a0 00 00 	movups %xmm14,0xa0(%r8)
   1407cbfb3:	00 
   1407cbfb4:	48 ff c3             	inc    %rbx
   1407cbfb7:	48 39 d9             	cmp    %rbx,%rcx
   1407cbfba:	73 27                	jae    0x1407cbfe3
   1407cbfbc:	48 89 d0             	mov    %rdx,%rax
   1407cbfbf:	bf 01 00 00 00       	mov    $0x1,%edi
   1407cbfc4:	48 8d 35 75 14 bc 00 	lea    0xbc1475(%rip),%rsi        # 0x14138d440
   1407cbfcb:	e8 30 cd 8b ff       	call   0x140088d00
   1407cbfd0:	4c 8d 8c 24 58 01 00 	lea    0x158(%rsp),%r9
   1407cbfd7:	00 
   1407cbfd8:	48 89 c2             	mov    %rax,%rdx
   1407cbfdb:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   1407cbfe2:	00 
   1407cbfe3:	4c 69 c3 b0 00 00 00 	imul   $0xb0,%rbx,%r8
   1407cbfea:	4e 8d 04 02          	lea    (%rdx,%r8,1),%r8
   1407cbfee:	4d 8d 80 50 ff ff ff 	lea    -0xb0(%r8),%r8
   1407cbff5:	83 3d 64 99 2c 04 00 	cmpl   $0x0,0x42c9964(%rip)        # 0x144a95960
   1407cbffc:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cc000:	0f 84 28 fc ff ff    	je     0x1407cbc2e
   1407cc006:	48 89 94 24 e0 02 00 	mov    %rdx,0x2e0(%rsp)
   1407cc00d:	00 
   1407cc00e:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   1407cc015:	00 
   1407cc016:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
   1407cc01d:	00 
   1407cc01e:	4c 89 84 24 e8 02 00 	mov    %r8,0x2e8(%rsp)
   1407cc025:	00 
   1407cc026:	48 8d 05 13 14 bc 00 	lea    0xbc1413(%rip),%rax        # 0x14138d440
   1407cc02d:	4c 89 c3             	mov    %r8,%rbx
   1407cc030:	4c 89 c9             	mov    %r9,%rcx
   1407cc033:	e8 28 9d 85 ff       	call   0x140025d60
   1407cc038:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   1407cc03f:	00 
   1407cc040:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
   1407cc047:	00 
   1407cc048:	48 8b 94 24 e0 02 00 	mov    0x2e0(%rsp),%rdx
   1407cc04f:	00 
   1407cc050:	48 8b 9c 24 48 01 00 	mov    0x148(%rsp),%rbx
   1407cc057:	00 
   1407cc058:	4c 8b 84 24 e8 02 00 	mov    0x2e8(%rsp),%r8
   1407cc05f:	00 
   1407cc060:	4c 8d 8c 24 58 01 00 	lea    0x158(%rsp),%r9
   1407cc067:	00 
   1407cc068:	e9 c1 fb ff ff       	jmp    0x1407cbc2e
   1407cc06d:	eb 1a                	jmp    0x1407cc089
   1407cc06f:	48 8b 94 24 d8 02 00 	mov    0x2d8(%rsp),%rdx
   1407cc076:	00 
   1407cc077:	48 81 c2 b0 00 00 00 	add    $0xb0,%rdx
   1407cc07e:	48 8b 9c 24 48 01 00 	mov    0x148(%rsp),%rbx
   1407cc085:	00 
   1407cc086:	48 ff cb             	dec    %rbx
   1407cc089:	48 85 db             	test   %rbx,%rbx
   1407cc08c:	0f 8e 21 0b 00 00    	jle    0x1407ccbb3
   1407cc092:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   1407cc099:	00 
   1407cc09a:	44 0f 10 32          	movups (%rdx),%xmm14
   1407cc09e:	44 0f 11 36          	movups %xmm14,(%rsi)
   1407cc0a2:	44 0f 10 72 10       	movups 0x10(%rdx),%xmm14
   1407cc0a7:	44 0f 11 76 10       	movups %xmm14,0x10(%rsi)
   1407cc0ac:	44 0f 10 72 20       	movups 0x20(%rdx),%xmm14
   1407cc0b1:	44 0f 11 76 20       	movups %xmm14,0x20(%rsi)
   1407cc0b6:	44 0f 10 72 30       	movups 0x30(%rdx),%xmm14
   1407cc0bb:	44 0f 11 76 30       	movups %xmm14,0x30(%rsi)
   1407cc0c0:	44 0f 10 72 40       	movups 0x40(%rdx),%xmm14
   1407cc0c5:	44 0f 11 76 40       	movups %xmm14,0x40(%rsi)
   1407cc0ca:	44 0f 10 72 50       	movups 0x50(%rdx),%xmm14
   1407cc0cf:	44 0f 11 76 50       	movups %xmm14,0x50(%rsi)
   1407cc0d4:	44 0f 10 72 60       	movups 0x60(%rdx),%xmm14
   1407cc0d9:	44 0f 11 76 60       	movups %xmm14,0x60(%rsi)
   1407cc0de:	44 0f 10 72 70       	movups 0x70(%rdx),%xmm14
   1407cc0e3:	44 0f 11 76 70       	movups %xmm14,0x70(%rsi)
   1407cc0e8:	44 0f 10 b2 80 00 00 	movups 0x80(%rdx),%xmm14
   1407cc0ef:	00 
   1407cc0f0:	44 0f 11 b6 80 00 00 	movups %xmm14,0x80(%rsi)
   1407cc0f7:	00 
   1407cc0f8:	44 0f 10 b2 90 00 00 	movups 0x90(%rdx),%xmm14
   1407cc0ff:	00 
   1407cc100:	44 0f 11 b6 90 00 00 	movups %xmm14,0x90(%rsi)
   1407cc107:	00 
   1407cc108:	44 0f 10 b2 a0 00 00 	movups 0xa0(%rdx),%xmm14
   1407cc10f:	00 
   1407cc110:	44 0f 11 b6 a0 00 00 	movups %xmm14,0xa0(%rsi)
   1407cc117:	00 
   1407cc118:	f2 0f 10 05 a0 9d 40 	movsd  0x409da0(%rip),%xmm0        # 0x140bd5ec0
   1407cc11f:	00 
   1407cc120:	f2 0f 10 8c 24 c8 00 	movsd  0xc8(%rsp),%xmm1
   1407cc127:	00 00 
   1407cc129:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cc12d:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cc132:	48 89 ce             	mov    %rcx,%rsi
   1407cc135:	48 c1 ee 34          	shr    $0x34,%rsi
   1407cc139:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407cc13f:	90                   	nop
   1407cc140:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407cc147:	73 2a                	jae    0x1407cc173
   1407cc149:	48 bf 00 00 00 00 00 	movabs $0x8000000000000000,%rdi
   1407cc150:	00 00 80 
   1407cc153:	48 21 f9             	and    %rdi,%rcx
   1407cc156:	49 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%r8
   1407cc15d:	00 f0 3f 
   1407cc160:	49 09 c8             	or     %rcx,%r8
   1407cc163:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407cc16a:	49 0f 44 c8          	cmove  %r8,%rcx
   1407cc16e:	48 89 cf             	mov    %rcx,%rdi
   1407cc171:	eb 3e                	jmp    0x1407cc1b1
   1407cc173:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407cc17a:	73 32                	jae    0x1407cc1ae
   1407cc17c:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407cc183:	48 89 c8             	mov    %rcx,%rax
   1407cc186:	48 89 f1             	mov    %rsi,%rcx
   1407cc189:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407cc190:	00 08 00 
   1407cc193:	48 d3 ef             	shr    %cl,%rdi
   1407cc196:	48 01 c7             	add    %rax,%rdi
   1407cc199:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407cc1a0:	ff 0f 00 
   1407cc1a3:	49 d3 e8             	shr    %cl,%r8
   1407cc1a6:	49 f7 d0             	not    %r8
   1407cc1a9:	4c 21 c7             	and    %r8,%rdi
   1407cc1ac:	eb 03                	jmp    0x1407cc1b1
   1407cc1ae:	48 89 cf             	mov    %rcx,%rdi
   1407cc1b1:	f2 0f 10 05 77 9c 40 	movsd  0x409c77(%rip),%xmm0        # 0x140bd5e30
   1407cc1b8:	00 
   1407cc1b9:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cc1bd:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cc1c2:	48 89 ce             	mov    %rcx,%rsi
   1407cc1c5:	48 c1 ee 34          	shr    $0x34,%rsi
   1407cc1c9:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407cc1cf:	90                   	nop
   1407cc1d0:	90                   	nop
   1407cc1d1:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407cc1d8:	73 2a                	jae    0x1407cc204
   1407cc1da:	49 b8 00 00 00 00 00 	movabs $0x8000000000000000,%r8
   1407cc1e1:	00 00 80 
   1407cc1e4:	4c 21 c1             	and    %r8,%rcx
   1407cc1e7:	49 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%r9
   1407cc1ee:	00 f0 3f 
   1407cc1f1:	49 09 c9             	or     %rcx,%r9
   1407cc1f4:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407cc1fb:	49 0f 44 c9          	cmove  %r9,%rcx
   1407cc1ff:	49 89 c8             	mov    %rcx,%r8
   1407cc202:	eb 3e                	jmp    0x1407cc242
   1407cc204:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407cc20b:	73 32                	jae    0x1407cc23f
   1407cc20d:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407cc214:	48 89 c8             	mov    %rcx,%rax
   1407cc217:	48 89 f1             	mov    %rsi,%rcx
   1407cc21a:	49 b8 00 00 00 00 00 	movabs $0x8000000000000,%r8
   1407cc221:	00 08 00 
   1407cc224:	49 d3 e8             	shr    %cl,%r8
   1407cc227:	49 01 c0             	add    %rax,%r8
   1407cc22a:	49 b9 ff ff ff ff ff 	movabs $0xfffffffffffff,%r9
   1407cc231:	ff 0f 00 
   1407cc234:	49 d3 e9             	shr    %cl,%r9
   1407cc237:	49 f7 d1             	not    %r9
   1407cc23a:	4d 21 c8             	and    %r9,%r8
   1407cc23d:	eb 03                	jmp    0x1407cc242
   1407cc23f:	49 89 c8             	mov    %rcx,%r8
   1407cc242:	8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%esi
   1407cc249:	44 8b 8c 24 bc 00 00 	mov    0xbc(%rsp),%r9d
   1407cc250:	00 
   1407cc251:	41 89 f2             	mov    %esi,%r10d
   1407cc254:	44 29 ce             	sub    %r9d,%esi
   1407cc257:	f2 0f 10 05 41 9c 40 	movsd  0x409c41(%rip),%xmm0        # 0x140bd5ea0
   1407cc25e:	00 
   1407cc25f:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cc263:	66 48 0f 6e d7       	movq   %rdi,%xmm2
   1407cc268:	f2 0f 2c fa          	cvttsd2si %xmm2,%edi
   1407cc26c:	66 49 0f 6e d0       	movq   %r8,%xmm2
   1407cc271:	f2 44 0f 2c c2       	cvttsd2si %xmm2,%r8d
   1407cc276:	44 29 c6             	sub    %r8d,%esi
   1407cc279:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cc27e:	49 89 c8             	mov    %rcx,%r8
   1407cc281:	49 c1 e8 34          	shr    $0x34,%r8
   1407cc285:	41 81 e0 ff 07 00 00 	and    $0x7ff,%r8d
   1407cc28c:	90                   	nop
   1407cc28d:	90                   	nop
   1407cc28e:	39 f7                	cmp    %esi,%edi
   1407cc290:	0f 4f fe             	cmovg  %esi,%edi
   1407cc293:	49 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8
   1407cc29a:	73 2a                	jae    0x1407cc2c6
   1407cc29c:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407cc2a3:	00 00 80 
   1407cc2a6:	48 21 f1             	and    %rsi,%rcx
   1407cc2a9:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407cc2b0:	00 f0 3f 
   1407cc2b3:	49 09 cb             	or     %rcx,%r11
   1407cc2b6:	49 81 f8 fe 03 00 00 	cmp    $0x3fe,%r8
   1407cc2bd:	49 0f 44 cb          	cmove  %r11,%rcx
   1407cc2c1:	49 89 c8             	mov    %rcx,%r8
   1407cc2c4:	eb 3f                	jmp    0x1407cc305
   1407cc2c6:	49 81 f8 33 04 00 00 	cmp    $0x433,%r8
   1407cc2cd:	73 33                	jae    0x1407cc302
   1407cc2cf:	49 8d b0 01 fc ff ff 	lea    -0x3ff(%r8),%rsi
   1407cc2d6:	48 89 c8             	mov    %rcx,%rax
   1407cc2d9:	48 89 f1             	mov    %rsi,%rcx
   1407cc2dc:	49 b8 00 00 00 00 00 	movabs $0x8000000000000,%r8
   1407cc2e3:	00 08 00 
   1407cc2e6:	49 d3 e8             	shr    %cl,%r8
   1407cc2e9:	49 01 c0             	add    %rax,%r8
   1407cc2ec:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407cc2f3:	ff 0f 00 
   1407cc2f6:	49 d3 eb             	shr    %cl,%r11
   1407cc2f9:	49 f7 d3             	not    %r11
   1407cc2fc:	4d 21 d8             	and    %r11,%r8
   1407cc2ff:	90                   	nop
   1407cc300:	eb 03                	jmp    0x1407cc305
   1407cc302:	49 89 c8             	mov    %rcx,%r8
   1407cc305:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   1407cc30c:	00 
   1407cc30d:	48 89 94 24 d8 02 00 	mov    %rdx,0x2d8(%rsp)
   1407cc314:	00 
   1407cc315:	f2 0f 10 05 db 9a 40 	movsd  0x409adb(%rip),%xmm0        # 0x140bd5df8
   1407cc31c:	00 
   1407cc31d:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cc321:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cc326:	48 89 ce             	mov    %rcx,%rsi
   1407cc329:	48 c1 ee 34          	shr    $0x34,%rsi
   1407cc32d:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407cc333:	90                   	nop
   1407cc334:	90                   	nop
   1407cc335:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407cc33c:	73 2a                	jae    0x1407cc368
   1407cc33e:	49 bb 00 00 00 00 00 	movabs $0x8000000000000000,%r11
   1407cc345:	00 00 80 
   1407cc348:	4c 21 d9             	and    %r11,%rcx
   1407cc34b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cc352:	00 f0 3f 
   1407cc355:	49 09 cc             	or     %rcx,%r12
   1407cc358:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407cc35f:	49 0f 44 cc          	cmove  %r12,%rcx
   1407cc363:	49 89 cb             	mov    %rcx,%r11
   1407cc366:	eb 3e                	jmp    0x1407cc3a6
   1407cc368:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407cc36f:	73 32                	jae    0x1407cc3a3
   1407cc371:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407cc378:	48 89 c8             	mov    %rcx,%rax
   1407cc37b:	48 89 f1             	mov    %rsi,%rcx
   1407cc37e:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407cc385:	00 08 00 
   1407cc388:	49 d3 eb             	shr    %cl,%r11
   1407cc38b:	49 01 c3             	add    %rax,%r11
   1407cc38e:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407cc395:	ff 0f 00 
   1407cc398:	49 d3 ec             	shr    %cl,%r12
   1407cc39b:	49 f7 d4             	not    %r12
   1407cc39e:	4d 21 e3             	and    %r12,%r11
   1407cc3a1:	eb 03                	jmp    0x1407cc3a6
   1407cc3a3:	49 89 cb             	mov    %rcx,%r11
   1407cc3a6:	89 bc 24 b0 00 00 00 	mov    %edi,0xb0(%rsp)
   1407cc3ad:	8b 8c 24 b4 00 00 00 	mov    0xb4(%rsp),%ecx
   1407cc3b4:	48 63 c9             	movslq %ecx,%rcx
   1407cc3b7:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
   1407cc3be:	00 
   1407cc3bf:	48 63 cf             	movslq %edi,%rcx
   1407cc3c2:	48 89 8c 24 30 01 00 	mov    %rcx,0x130(%rsp)
   1407cc3c9:	00 
   1407cc3ca:	66 49 0f 6e c0       	movq   %r8,%xmm0
   1407cc3cf:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cc3d3:	89 8c 24 a8 00 00 00 	mov    %ecx,0xa8(%rsp)
   1407cc3da:	48 63 c9             	movslq %ecx,%rcx
   1407cc3dd:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
   1407cc3e4:	00 
   1407cc3e5:	66 49 0f 6e c3       	movq   %r11,%xmm0
   1407cc3ea:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cc3ee:	41 29 ca             	sub    %ecx,%r10d
   1407cc3f1:	41 29 fa             	sub    %edi,%r10d
   1407cc3f4:	44 89 94 24 ac 00 00 	mov    %r10d,0xac(%rsp)
   1407cc3fb:	00 
   1407cc3fc:	49 63 ca             	movslq %r10d,%rcx
   1407cc3ff:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
   1407cc406:	00 
   1407cc407:	90                   	nop
   1407cc408:	48 8d 05 db 62 0c 00 	lea    0xc62db(%rip),%rax        # 0x1408926ea
   1407cc40f:	bb 0e 00 00 00       	mov    $0xe,%ebx
   1407cc414:	e8 07 d5 fc ff       	call   0x140799920
   1407cc419:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
   1407cc420:	00 
   1407cc421:	48 89 e1             	mov    %rsp,%rcx
   1407cc424:	48 8d 94 24 10 02 00 	lea    0x210(%rsp),%rdx
   1407cc42b:	00 
   1407cc42c:	44 0f 10 32          	movups (%rdx),%xmm14
   1407cc430:	44 0f 11 31          	movups %xmm14,(%rcx)
   1407cc434:	44 0f 10 72 10       	movups 0x10(%rdx),%xmm14
   1407cc439:	44 0f 11 71 10       	movups %xmm14,0x10(%rcx)
   1407cc43e:	44 0f 10 72 20       	movups 0x20(%rdx),%xmm14
   1407cc443:	44 0f 11 71 20       	movups %xmm14,0x20(%rcx)
   1407cc448:	44 0f 10 72 30       	movups 0x30(%rdx),%xmm14
   1407cc44d:	44 0f 11 71 30       	movups %xmm14,0x30(%rcx)
   1407cc452:	44 0f 10 72 40       	movups 0x40(%rdx),%xmm14
   1407cc457:	44 0f 11 71 40       	movups %xmm14,0x40(%rcx)
   1407cc45c:	44 0f 10 72 50       	movups 0x50(%rdx),%xmm14
   1407cc461:	44 0f 11 71 50       	movups %xmm14,0x50(%rcx)
   1407cc466:	44 0f 10 72 60       	movups 0x60(%rdx),%xmm14
   1407cc46b:	44 0f 11 71 60       	movups %xmm14,0x60(%rcx)
   1407cc470:	44 0f 10 72 70       	movups 0x70(%rdx),%xmm14
   1407cc475:	44 0f 11 71 70       	movups %xmm14,0x70(%rcx)
   1407cc47a:	44 0f 10 b2 80 00 00 	movups 0x80(%rdx),%xmm14
   1407cc481:	00 
   1407cc482:	44 0f 11 b1 80 00 00 	movups %xmm14,0x80(%rcx)
   1407cc489:	00 
   1407cc48a:	44 0f 10 b2 90 00 00 	movups 0x90(%rdx),%xmm14
   1407cc491:	00 
   1407cc492:	44 0f 11 b1 90 00 00 	movups %xmm14,0x90(%rcx)
   1407cc499:	00 
   1407cc49a:	44 0f 10 b2 98 00 00 	movups 0x98(%rdx),%xmm14
   1407cc4a1:	00 
   1407cc4a2:	44 0f 11 b1 98 00 00 	movups %xmm14,0x98(%rcx)
   1407cc4a9:	00 
   1407cc4aa:	e8 71 4a fb ff       	call   0x140780f20
   1407cc4af:	e8 6c d4 fc ff       	call   0x140799920
   1407cc4b4:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
   1407cc4bb:	00 
   1407cc4bc:	48 8d 05 4d fb ae 00 	lea    0xaefb4d(%rip),%rax        # 0x1412bc010
   1407cc4c3:	e8 38 59 85 ff       	call   0x140021e00
   1407cc4c8:	48 c7 00 88 00 08 08 	movq   $0x8080088,(%rax)
   1407cc4cf:	48 8b 8c 24 c8 02 00 	mov    0x2c8(%rsp),%rcx
   1407cc4d6:	00 
   1407cc4d7:	48 89 48 08          	mov    %rcx,0x8(%rax)
   1407cc4db:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
   1407cc4e2:	00 
   1407cc4e3:	48 89 48 10          	mov    %rcx,0x10(%rax)
   1407cc4e7:	b9 00 00 00 80       	mov    $0x80000000,%ecx
   1407cc4ec:	48 89 48 18          	mov    %rcx,0x18(%rax)
   1407cc4f0:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   1407cc4f7:	00 
   1407cc4f8:	48 89 48 20          	mov    %rcx,0x20(%rax)
   1407cc4fc:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   1407cc503:	00 
   1407cc504:	48 89 48 28          	mov    %rcx,0x28(%rax)
   1407cc508:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
   1407cc50f:	00 
   1407cc510:	48 89 48 30          	mov    %rcx,0x30(%rax)
   1407cc514:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   1407cc51b:	00 
   1407cc51c:	48 89 48 38          	mov    %rcx,0x38(%rax)
   1407cc520:	44 0f 11 78 40       	movups %xmm15,0x40(%rax)
   1407cc525:	48 8b 0d 54 8f 2c 04 	mov    0x42c8f54(%rip),%rcx        # 0x144a95480
   1407cc52c:	48 89 48 50          	mov    %rcx,0x50(%rax)
   1407cc530:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
   1407cc537:	00 
   1407cc538:	48 8b 0d 09 ea 21 04 	mov    0x421ea09(%rip),%rcx        # 0x1449eaf48
   1407cc53f:	48 8d 1d 96 76 0c 00 	lea    0xc7696(%rip),%rbx        # 0x140893bdc
   1407cc546:	48 89 c7             	mov    %rax,%rdi
   1407cc549:	be 0c 00 00 00       	mov    $0xc,%esi
   1407cc54e:	41 89 f0             	mov    %esi,%r8d
   1407cc551:	48 89 c8             	mov    %rcx,%rax
   1407cc554:	b9 0f 00 00 00       	mov    $0xf,%ecx
   1407cc559:	e8 42 d4 fc ff       	call   0x1407999a0
   1407cc55e:	66 90                	xchg   %ax,%ax
   1407cc560:	48 85 c0             	test   %rax,%rax
   1407cc563:	0f 85 be 00 00 00    	jne    0x1407cc627
   1407cc569:	48 89 e0             	mov    %rsp,%rax
   1407cc56c:	48 8d 8c 24 10 02 00 	lea    0x210(%rsp),%rcx
   1407cc573:	00 
   1407cc574:	44 0f 10 31          	movups (%rcx),%xmm14
   1407cc578:	44 0f 11 30          	movups %xmm14,(%rax)
   1407cc57c:	44 0f 10 71 10       	movups 0x10(%rcx),%xmm14
   1407cc581:	44 0f 11 70 10       	movups %xmm14,0x10(%rax)
   1407cc586:	44 0f 10 71 20       	movups 0x20(%rcx),%xmm14
   1407cc58b:	44 0f 11 70 20       	movups %xmm14,0x20(%rax)
   1407cc590:	44 0f 10 71 30       	movups 0x30(%rcx),%xmm14
   1407cc595:	44 0f 11 70 30       	movups %xmm14,0x30(%rax)
   1407cc59a:	44 0f 10 71 40       	movups 0x40(%rcx),%xmm14
   1407cc59f:	44 0f 11 70 40       	movups %xmm14,0x40(%rax)
   1407cc5a4:	44 0f 10 71 50       	movups 0x50(%rcx),%xmm14
   1407cc5a9:	44 0f 11 70 50       	movups %xmm14,0x50(%rax)
   1407cc5ae:	44 0f 10 71 60       	movups 0x60(%rcx),%xmm14
   1407cc5b3:	44 0f 11 70 60       	movups %xmm14,0x60(%rax)
   1407cc5b8:	44 0f 10 71 70       	movups 0x70(%rcx),%xmm14
   1407cc5bd:	44 0f 11 70 70       	movups %xmm14,0x70(%rax)
   1407cc5c2:	44 0f 10 b1 80 00 00 	movups 0x80(%rcx),%xmm14
   1407cc5c9:	00 
   1407cc5ca:	44 0f 11 b0 80 00 00 	movups %xmm14,0x80(%rax)
   1407cc5d1:	00 
   1407cc5d2:	44 0f 10 b1 90 00 00 	movups 0x90(%rcx),%xmm14
   1407cc5d9:	00 
   1407cc5da:	44 0f 11 b0 90 00 00 	movups %xmm14,0x90(%rax)
   1407cc5e1:	00 
   1407cc5e2:	44 0f 10 b1 98 00 00 	movups 0x98(%rcx),%xmm14
   1407cc5e9:	00 
   1407cc5ea:	44 0f 11 b0 98 00 00 	movups %xmm14,0x98(%rax)
   1407cc5f1:	00 
   1407cc5f2:	e8 29 49 fb ff       	call   0x140780f20
   1407cc5f7:	48 89 d9             	mov    %rbx,%rcx
   1407cc5fa:	48 89 c3             	mov    %rax,%rbx
   1407cc5fd:	b8 01 00 00 00       	mov    $0x1,%eax
   1407cc602:	e8 19 e3 fc ff       	call   0x14079a920
   1407cc607:	48 8b 05 7a 1c 28 04 	mov    0x4281c7a(%rip),%rax        # 0x144a4e288
   1407cc60e:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   1407cc615:	00 
   1407cc616:	48 89 c2             	mov    %rax,%rdx
   1407cc619:	48 8b 1d 70 1c 28 04 	mov    0x4281c70(%rip),%rbx        # 0x144a4e290
   1407cc620:	31 f6                	xor    %esi,%esi
   1407cc622:	e9 a9 05 00 00       	jmp    0x1407ccbd0
   1407cc627:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   1407cc62e:	00 
   1407cc62f:	e8 6c 56 8f ff       	call   0x1400c1ca0
   1407cc634:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   1407cc63b:	00 
   1407cc63c:	48 89 8c 24 d0 02 00 	mov    %rcx,0x2d0(%rsp)
   1407cc643:	00 
   1407cc644:	48 89 9c 24 38 01 00 	mov    %rbx,0x138(%rsp)
   1407cc64b:	00 
   1407cc64c:	48 8d 05 55 e5 c2 00 	lea    0xc2e555(%rip),%rax        # 0x1413faba8
   1407cc653:	e8 a8 57 85 ff       	call   0x140021e00
   1407cc658:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   1407cc65f:	00 
   1407cc660:	f2 0f 10 05 98 97 40 	movsd  0x409798(%rip),%xmm0        # 0x140bd5e00
   1407cc667:	00 
   1407cc668:	f2 0f 10 8c 24 c8 00 	movsd  0xc8(%rsp),%xmm1
   1407cc66f:	00 00 
   1407cc671:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cc675:	f2 0f 11 84 24 c0 00 	movsd  %xmm0,0xc0(%rsp)
   1407cc67c:	00 00 
   1407cc67e:	83 3d db 92 2c 04 00 	cmpl   $0x0,0x42c92db(%rip)        # 0x144a95960
   1407cc685:	74 31                	je     0x1407cc6b8
   1407cc687:	48 89 c3             	mov    %rax,%rbx
   1407cc68a:	48 8d 8c 24 08 02 00 	lea    0x208(%rsp),%rcx
   1407cc691:	00 
   1407cc692:	48 8d 05 a7 0d bc 00 	lea    0xbc0da7(%rip),%rax        # 0x14138d440
   1407cc699:	e8 c2 96 85 ff       	call   0x140025d60
   1407cc69e:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   1407cc6a5:	00 
   1407cc6a6:	f2 0f 10 84 24 c0 00 	movsd  0xc0(%rsp),%xmm0
   1407cc6ad:	00 00 
   1407cc6af:	f2 0f 10 8c 24 c8 00 	movsd  0xc8(%rsp),%xmm1
   1407cc6b6:	00 00 
   1407cc6b8:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
   1407cc6bf:	00 
   1407cc6c0:	44 0f 10 32          	movups (%rdx),%xmm14
   1407cc6c4:	44 0f 11 30          	movups %xmm14,(%rax)
   1407cc6c8:	44 0f 10 72 10       	movups 0x10(%rdx),%xmm14
   1407cc6cd:	44 0f 11 70 10       	movups %xmm14,0x10(%rax)
   1407cc6d2:	44 0f 10 72 20       	movups 0x20(%rdx),%xmm14
   1407cc6d7:	44 0f 11 70 20       	movups %xmm14,0x20(%rax)
   1407cc6dc:	44 0f 10 72 30       	movups 0x30(%rdx),%xmm14
   1407cc6e1:	44 0f 11 70 30       	movups %xmm14,0x30(%rax)
   1407cc6e6:	44 0f 10 72 40       	movups 0x40(%rdx),%xmm14
   1407cc6eb:	44 0f 11 70 40       	movups %xmm14,0x40(%rax)
   1407cc6f0:	44 0f 10 72 50       	movups 0x50(%rdx),%xmm14
   1407cc6f5:	44 0f 11 70 50       	movups %xmm14,0x50(%rax)
   1407cc6fa:	44 0f 10 72 60       	movups 0x60(%rdx),%xmm14
   1407cc6ff:	44 0f 11 70 60       	movups %xmm14,0x60(%rax)
   1407cc704:	44 0f 10 72 70       	movups 0x70(%rdx),%xmm14
   1407cc709:	44 0f 11 70 70       	movups %xmm14,0x70(%rax)
   1407cc70e:	44 0f 10 b2 80 00 00 	movups 0x80(%rdx),%xmm14
   1407cc715:	00 
   1407cc716:	44 0f 11 b0 80 00 00 	movups %xmm14,0x80(%rax)
   1407cc71d:	00 
   1407cc71e:	44 0f 10 b2 90 00 00 	movups 0x90(%rdx),%xmm14
   1407cc725:	00 
   1407cc726:	44 0f 11 b0 90 00 00 	movups %xmm14,0x90(%rax)
   1407cc72d:	00 
   1407cc72e:	44 0f 10 b2 a0 00 00 	movups 0xa0(%rdx),%xmm14
   1407cc735:	00 
   1407cc736:	44 0f 11 b0 a0 00 00 	movups %xmm14,0xa0(%rax)
   1407cc73d:	00 
   1407cc73e:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
   1407cc745:	00 
   1407cc746:	48 89 88 b0 00 00 00 	mov    %rcx,0xb0(%rax)
   1407cc74d:	f2 0f 11 88 b8 00 00 	movsd  %xmm1,0xb8(%rax)
   1407cc754:	00 
   1407cc755:	8b 94 24 b0 00 00 00 	mov    0xb0(%rsp),%edx
   1407cc75c:	89 90 c0 00 00 00    	mov    %edx,0xc0(%rax)
   1407cc762:	8b b4 24 a8 00 00 00 	mov    0xa8(%rsp),%esi
   1407cc769:	89 b0 c4 00 00 00    	mov    %esi,0xc4(%rax)
   1407cc76f:	8b bc 24 ac 00 00 00 	mov    0xac(%rsp),%edi
   1407cc776:	0f 57 d2             	xorps  %xmm2,%xmm2
   1407cc779:	f2 0f 2a d7          	cvtsi2sd %edi,%xmm2
   1407cc77d:	f2 0f 11 90 c8 00 00 	movsd  %xmm2,0xc8(%rax)
   1407cc784:	00 
   1407cc785:	8b bc 24 b4 00 00 00 	mov    0xb4(%rsp),%edi
   1407cc78c:	0f 57 d2             	xorps  %xmm2,%xmm2
   1407cc78f:	f2 0f 2a d7          	cvtsi2sd %edi,%xmm2
   1407cc793:	f2 0f 11 90 d0 00 00 	movsd  %xmm2,0xd0(%rax)
   1407cc79a:	00 
   1407cc79b:	4c 8b 84 24 18 01 00 	mov    0x118(%rsp),%r8
   1407cc7a2:	00 
   1407cc7a3:	4c 89 80 e8 00 00 00 	mov    %r8,0xe8(%rax)
   1407cc7aa:	4c 8b 8c 24 38 01 00 	mov    0x138(%rsp),%r9
   1407cc7b1:	00 
   1407cc7b2:	4c 89 88 f0 00 00 00 	mov    %r9,0xf0(%rax)
   1407cc7b9:	83 3d a0 91 2c 04 00 	cmpl   $0x0,0x42c91a0(%rip)        # 0x144a95960
   1407cc7c0:	74 29                	je     0x1407cc7eb
   1407cc7c2:	4c 8b 90 f8 00 00 00 	mov    0xf8(%rax),%r10
   1407cc7c9:	4c 8b 98 10 01 00 00 	mov    0x110(%rax),%r11
   1407cc7d0:	4c 89 db             	mov    %r11,%rbx
   1407cc7d3:	e8 28 16 8c ff       	call   0x14008de00
   1407cc7d8:	4c 8b a4 24 d0 02 00 	mov    0x2d0(%rsp),%r12
   1407cc7df:	00 
   1407cc7e0:	4d 89 23             	mov    %r12,(%r11)
   1407cc7e3:	4d 89 53 08          	mov    %r10,0x8(%r11)
   1407cc7e7:	49 89 5b 10          	mov    %rbx,0x10(%r11)
   1407cc7eb:	48 8b 94 24 d0 02 00 	mov    0x2d0(%rsp),%rdx
   1407cc7f2:	00 
   1407cc7f3:	48 89 90 f8 00 00 00 	mov    %rdx,0xf8(%rax)
   1407cc7fa:	4c 89 80 00 01 00 00 	mov    %r8,0x100(%rax)
   1407cc801:	4c 89 88 08 01 00 00 	mov    %r9,0x108(%rax)
   1407cc808:	48 89 90 10 01 00 00 	mov    %rdx,0x110(%rax)
   1407cc80f:	48 ba 00 78 41 cb 02 	movabs $0x2cb417800,%rdx
   1407cc816:	00 00 00 
   1407cc819:	48 89 90 18 01 00 00 	mov    %rdx,0x118(%rax)
   1407cc820:	48 8b 1d a1 dc 27 04 	mov    0x427dca1(%rip),%rbx        # 0x144a4a4c8
   1407cc827:	48 8d 05 42 3a b2 00 	lea    0xb23a42(%rip),%rax        # 0x1412f0270
   1407cc82e:	e8 2d f8 83 ff       	call   0x14000c060
   1407cc833:	83 3d 26 91 2c 04 00 	cmpl   $0x0,0x42c9126(%rip)        # 0x144a95960
   1407cc83a:	75 0a                	jne    0x1407cc846
   1407cc83c:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   1407cc843:	00 
   1407cc844:	eb 17                	jmp    0x1407cc85d
   1407cc846:	48 8b 10             	mov    (%rax),%rdx
   1407cc849:	e8 92 15 8c ff       	call   0x14008dde0
   1407cc84e:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   1407cc855:	00 
   1407cc856:	49 89 33             	mov    %rsi,(%r11)
   1407cc859:	49 89 53 08          	mov    %rdx,0x8(%r11)
   1407cc85d:	48 89 30             	mov    %rsi,(%rax)
   1407cc860:	f2 0f 10 84 24 c0 00 	movsd  0xc0(%rsp),%xmm0
   1407cc867:	00 00 
   1407cc869:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cc86e:	48 89 ca             	mov    %rcx,%rdx
   1407cc871:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cc875:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cc87b:	90                   	nop
   1407cc87c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cc880:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cc887:	73 37                	jae    0x1407cc8c0
   1407cc889:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407cc890:	00 00 80 
   1407cc893:	48 21 ce             	and    %rcx,%rsi
   1407cc896:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407cc89d:	00 f0 3f 
   1407cc8a0:	48 09 f7             	or     %rsi,%rdi
   1407cc8a3:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cc8aa:	48 0f 44 f7          	cmove  %rdi,%rsi
   1407cc8ae:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cc8b5:	48 89 c8             	mov    %rcx,%rax
   1407cc8b8:	48 89 f7             	mov    %rsi,%rdi
   1407cc8bb:	eb 52                	jmp    0x1407cc90f
   1407cc8bd:	0f 1f 00             	nopl   (%rax)
   1407cc8c0:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cc8c7:	73 39                	jae    0x1407cc902
   1407cc8c9:	48 8d b2 01 fc ff ff 	lea    -0x3ff(%rdx),%rsi
   1407cc8d0:	48 89 c8             	mov    %rcx,%rax
   1407cc8d3:	48 89 f1             	mov    %rsi,%rcx
   1407cc8d6:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407cc8dd:	00 08 00 
   1407cc8e0:	48 d3 ef             	shr    %cl,%rdi
   1407cc8e3:	48 01 c7             	add    %rax,%rdi
   1407cc8e6:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407cc8ed:	ff 0f 00 
   1407cc8f0:	49 d3 e8             	shr    %cl,%r8
   1407cc8f3:	49 f7 d0             	not    %r8
   1407cc8f6:	4c 21 c7             	and    %r8,%rdi
   1407cc8f9:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cc900:	eb 0d                	jmp    0x1407cc90f
   1407cc902:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cc909:	48 89 c8             	mov    %rcx,%rax
   1407cc90c:	48 89 c7             	mov    %rax,%rdi
   1407cc90f:	90                   	nop
   1407cc910:	73 2e                	jae    0x1407cc940
   1407cc912:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407cc919:	00 00 80 
   1407cc91c:	48 21 f0             	and    %rsi,%rax
   1407cc91f:	49 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%r8
   1407cc926:	00 f0 3f 
   1407cc929:	49 09 c0             	or     %rax,%r8
   1407cc92c:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cc933:	49 0f 44 c0          	cmove  %r8,%rax
   1407cc937:	48 89 c2             	mov    %rax,%rdx
   1407cc93a:	eb 3c                	jmp    0x1407cc978
   1407cc93c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cc940:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cc947:	73 2c                	jae    0x1407cc975
   1407cc949:	48 8d 8a 01 fc ff ff 	lea    -0x3ff(%rdx),%rcx
   1407cc950:	48 ba 00 00 00 00 00 	movabs $0x8000000000000,%rdx
   1407cc957:	00 08 00 
   1407cc95a:	48 d3 ea             	shr    %cl,%rdx
   1407cc95d:	48 01 c2             	add    %rax,%rdx
   1407cc960:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   1407cc967:	ff 0f 00 
   1407cc96a:	48 d3 ee             	shr    %cl,%rsi
   1407cc96d:	48 f7 d6             	not    %rsi
   1407cc970:	48 21 f2             	and    %rsi,%rdx
   1407cc973:	eb 03                	jmp    0x1407cc978
   1407cc975:	48 89 c2             	mov    %rax,%rdx
   1407cc978:	8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%esi
   1407cc97f:	ff c6                	inc    %esi
   1407cc981:	48 63 f6             	movslq %esi,%rsi
   1407cc984:	48 89 b4 24 30 01 00 	mov    %rsi,0x130(%rsp)
   1407cc98b:	00 
   1407cc98c:	8b b4 24 a8 00 00 00 	mov    0xa8(%rsp),%esi
   1407cc993:	ff c6                	inc    %esi
   1407cc995:	48 63 f6             	movslq %esi,%rsi
   1407cc998:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
   1407cc99f:	00 
   1407cc9a0:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   1407cc9a5:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407cc9a9:	48 63 f6             	movslq %esi,%rsi
   1407cc9ac:	48 89 b4 24 10 01 00 	mov    %rsi,0x110(%rsp)
   1407cc9b3:	00 
   1407cc9b4:	66 48 0f 6e c2       	movq   %rdx,%xmm0
   1407cc9b9:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407cc9bd:	48 63 d2             	movslq %edx,%rdx
   1407cc9c0:	48 89 94 24 08 01 00 	mov    %rdx,0x108(%rsp)
   1407cc9c7:	00 
   1407cc9c8:	90                   	nop
   1407cc9c9:	b8 30 00 00 00       	mov    $0x30,%eax
   1407cc9ce:	48 8d 1d 4b 3a af 00 	lea    0xaf3a4b(%rip),%rbx        # 0x1412c0420
   1407cc9d5:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cc9da:	e8 a1 7d 85 ff       	call   0x140024780
   1407cc9df:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
   1407cc9e6:	00 
   1407cc9e7:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407cc9eb:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
   1407cc9f2:	00 
   1407cc9f3:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407cc9f7:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407cc9fe:	00 
   1407cc9ff:	48 89 50 20          	mov    %rdx,0x20(%rax)
   1407cca03:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
   1407cca0a:	00 
   1407cca0b:	48 89 50 28          	mov    %rdx,0x28(%rax)
   1407cca0f:	48 8b 15 42 e5 21 04 	mov    0x421e542(%rip),%rdx        # 0x1449eaf58
   1407cca16:	48 8d 1d d0 c4 0c 00 	lea    0xcc4d0(%rip),%rbx        # 0x140898eed
   1407cca1d:	b9 12 00 00 00       	mov    $0x12,%ecx
   1407cca22:	48 89 c7             	mov    %rax,%rdi
   1407cca25:	be 06 00 00 00       	mov    $0x6,%esi
   1407cca2a:	41 89 f0             	mov    %esi,%r8d
   1407cca2d:	48 89 d0             	mov    %rdx,%rax
   1407cca30:	e8 6b cf fc ff       	call   0x1407999a0
   1407cca35:	48 85 c0             	test   %rax,%rax
   1407cca38:	0f 84 b8 00 00 00    	je     0x1407ccaf6
   1407cca3e:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   1407cca45:	00 
   1407cca46:	b8 18 00 00 00       	mov    $0x18,%eax
   1407cca4b:	48 8d 1d d6 25 af 00 	lea    0xaf25d6(%rip),%rbx        # 0x1412bf028
   1407cca52:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cca57:	e8 64 78 85 ff       	call   0x1400242c0
   1407cca5c:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
   1407cca63:	00 
   1407cca64:	48 89 10             	mov    %rdx,(%rax)
   1407cca67:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
   1407cca6e:	00 
   1407cca6f:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407cca73:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
   1407cca7a:	00 
   1407cca7b:	48 8b 15 c6 e4 21 04 	mov    0x421e4c6(%rip),%rdx        # 0x1449eaf48
   1407cca82:	48 8d 1d fe 2d 0c 00 	lea    0xc2dfe(%rip),%rbx        # 0x14088f887
   1407cca89:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407cca8e:	48 89 c7             	mov    %rax,%rdi
   1407cca91:	be 03 00 00 00       	mov    $0x3,%esi
   1407cca96:	41 89 f0             	mov    %esi,%r8d
   1407cca99:	48 89 d0             	mov    %rdx,%rax
   1407cca9c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407ccaa0:	e8 fb ce fc ff       	call   0x1407999a0
   1407ccaa5:	48 85 c0             	test   %rax,%rax
   1407ccaa8:	75 4c                	jne    0x1407ccaf6
   1407ccaaa:	b8 08 00 00 00       	mov    $0x8,%eax
   1407ccaaf:	48 8d 1d ba 0a af 00 	lea    0xaf0aba(%rip),%rbx        # 0x1412bd570
   1407ccab6:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ccabb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407ccac0:	e8 bb 72 85 ff       	call   0x140023d80
   1407ccac5:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
   1407ccacc:	00 
   1407ccacd:	48 89 10             	mov    %rdx,(%rax)
   1407ccad0:	48 8b 15 81 e4 21 04 	mov    0x421e481(%rip),%rdx        # 0x1449eaf58
   1407ccad7:	48 8d 1d ad 2c 0c 00 	lea    0xc2cad(%rip),%rbx        # 0x14088f78b
   1407ccade:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407ccae3:	48 89 c7             	mov    %rax,%rdi
   1407ccae6:	be 01 00 00 00       	mov    $0x1,%esi
   1407ccaeb:	41 89 f0             	mov    %esi,%r8d
   1407ccaee:	48 89 d0             	mov    %rdx,%rax
   1407ccaf1:	e8 aa ce fc ff       	call   0x1407999a0
   1407ccaf6:	b8 20 00 00 00       	mov    $0x20,%eax
   1407ccafb:	48 8d 1d de 2d af 00 	lea    0xaf2dde(%rip),%rbx        # 0x1412bf8e0
   1407ccb02:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ccb07:	e8 14 7a 85 ff       	call   0x140024520
   1407ccb0c:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
   1407ccb13:	00 
   1407ccb14:	48 89 10             	mov    %rdx,(%rax)
   1407ccb17:	44 0f 11 78 08       	movups %xmm15,0x8(%rax)
   1407ccb1c:	48 c7 40 18 02 00 00 	movq   $0x2,0x18(%rax)
   1407ccb23:	00 
   1407ccb24:	48 8b 15 1d e4 21 04 	mov    0x421e41d(%rip),%rdx        # 0x1449eaf48
   1407ccb2b:	48 8d 1d e9 8a 0d 00 	lea    0xd8ae9(%rip),%rbx        # 0x1408a561b
   1407ccb32:	b9 1a 00 00 00       	mov    $0x1a,%ecx
   1407ccb37:	48 89 c7             	mov    %rax,%rdi
   1407ccb3a:	be 04 00 00 00       	mov    $0x4,%esi
   1407ccb3f:	41 89 f0             	mov    %esi,%r8d
   1407ccb42:	48 89 d0             	mov    %rdx,%rax
   1407ccb45:	e8 56 ce fc ff       	call   0x1407999a0
   1407ccb4a:	b8 20 00 00 00       	mov    $0x20,%eax
   1407ccb4f:	48 8d 1d 8a 2d af 00 	lea    0xaf2d8a(%rip),%rbx        # 0x1412bf8e0
   1407ccb56:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ccb5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407ccb60:	e8 bb 79 85 ff       	call   0x140024520
   1407ccb65:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
   1407ccb6c:	00 
   1407ccb6d:	48 89 10             	mov    %rdx,(%rax)
   1407ccb70:	48 c7 40 08 01 00 00 	movq   $0x1,0x8(%rax)
   1407ccb77:	00 
   1407ccb78:	48 c7 40 10 1e 00 00 	movq   $0x1e,0x10(%rax)
   1407ccb7f:	00 
   1407ccb80:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
   1407ccb87:	00 
   1407ccb88:	48 8b 15 b9 e3 21 04 	mov    0x421e3b9(%rip),%rdx        # 0x1449eaf48
   1407ccb8f:	48 8d 1d 02 c2 0b 00 	lea    0xbc202(%rip),%rbx        # 0x140888d98
   1407ccb96:	b9 08 00 00 00       	mov    $0x8,%ecx
   1407ccb9b:	48 89 c7             	mov    %rax,%rdi
   1407ccb9e:	be 04 00 00 00       	mov    $0x4,%esi
   1407ccba3:	41 89 f0             	mov    %esi,%r8d
   1407ccba6:	48 89 d0             	mov    %rdx,%rax
   1407ccba9:	e8 f2 cd fc ff       	call   0x1407999a0
   1407ccbae:	e9 bc f4 ff ff       	jmp    0x1407cc06f
   1407ccbb3:	b8 01 00 00 00       	mov    $0x1,%eax
   1407ccbb8:	e8 83 01 00 00       	call   0x1407ccd40
   1407ccbbd:	48 81 c4 f0 02 00 00 	add    $0x2f0,%rsp
   1407ccbc4:	5d                   	pop    %rbp
   1407ccbc5:	c3                   	ret
   1407ccbc6:	48 81 c2 b0 00 00 00 	add    $0xb0,%rdx
   1407ccbcd:	48 ff c6             	inc    %rsi
   1407ccbd0:	48 39 de             	cmp    %rbx,%rsi
   1407ccbd3:	0f 8d 96 f4 ff ff    	jge    0x1407cc06f
   1407ccbd9:	48 39 0a             	cmp    %rcx,(%rdx)
   1407ccbdc:	75 e8                	jne    0x1407ccbc6
   1407ccbde:	48 8b 0d b3 16 28 04 	mov    0x42816b3(%rip),%rcx        # 0x144a4e298
   1407ccbe5:	48 39 ce             	cmp    %rcx,%rsi
   1407ccbe8:	0f 87 3c 01 00 00    	ja     0x1407ccd2a
   1407ccbee:	48 8d 56 01          	lea    0x1(%rsi),%rdx
   1407ccbf2:	48 39 d3             	cmp    %rdx,%rbx
   1407ccbf5:	0f 82 2a 01 00 00    	jb     0x1407ccd25
   1407ccbfb:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
   1407ccbff:	49 89 c8             	mov    %rcx,%r8
   1407ccc02:	49 29 f0             	sub    %rsi,%r8
   1407ccc05:	48 29 f3             	sub    %rsi,%rbx
   1407ccc08:	4c 69 ce b0 00 00 00 	imul   $0xb0,%rsi,%r9
   1407ccc0f:	49 ff c8             	dec    %r8
   1407ccc12:	49 f7 d8             	neg    %r8
   1407ccc15:	49 c1 f8 3f          	sar    $0x3f,%r8
   1407ccc19:	4d 8d 91 b0 00 00 00 	lea    0xb0(%r9),%r10
   1407ccc20:	4d 21 d0             	and    %r10,%r8
   1407ccc23:	49 8d 3c 00          	lea    (%r8,%rax,1),%rdi
   1407ccc27:	4c 8d 43 ff          	lea    -0x1(%rbx),%r8
   1407ccc2b:	48 39 d1             	cmp    %rdx,%rcx
   1407ccc2e:	73 58                	jae    0x1407ccc88
   1407ccc30:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   1407ccc37:	00 
   1407ccc38:	4c 89 84 24 40 01 00 	mov    %r8,0x140(%rsp)
   1407ccc3f:	00 
   1407ccc40:	48 89 bc 24 e8 02 00 	mov    %rdi,0x2e8(%rsp)
   1407ccc47:	00 
   1407ccc48:	4c 89 8c 24 00 01 00 	mov    %r9,0x100(%rsp)
   1407ccc4f:	00 
   1407ccc50:	48 89 d3             	mov    %rdx,%rbx
   1407ccc53:	4c 89 c7             	mov    %r8,%rdi
   1407ccc56:	48 8d 35 e3 07 bc 00 	lea    0xbc07e3(%rip),%rsi        # 0x14138d440
   1407ccc5d:	0f 1f 00             	nopl   (%rax)
   1407ccc60:	e8 9b c0 8b ff       	call   0x140088d00
   1407ccc65:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
   1407ccc6c:	00 
   1407ccc6d:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
   1407ccc74:	00 
   1407ccc75:	4c 8b 84 24 40 01 00 	mov    0x140(%rsp),%r8
   1407ccc7c:	00 
   1407ccc7d:	4c 8b 8c 24 00 01 00 	mov    0x100(%rsp),%r9
   1407ccc84:	00 
   1407ccc85:	48 89 da             	mov    %rbx,%rdx
   1407ccc88:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
   1407ccc8f:	00 
   1407ccc90:	48 89 94 24 40 01 00 	mov    %rdx,0x140(%rsp)
   1407ccc97:	00 
   1407ccc98:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
   1407ccc9f:	00 
   1407ccca0:	48 29 f2             	sub    %rsi,%rdx
   1407ccca3:	48 29 ce             	sub    %rcx,%rsi
   1407ccca6:	48 c1 fe 3f          	sar    $0x3f,%rsi
   1407cccaa:	4c 21 ce             	and    %r9,%rsi
   1407cccad:	48 8d 1c 30          	lea    (%rax,%rsi,1),%rbx
   1407cccb1:	48 8d 05 88 07 bc 00 	lea    0xbc0788(%rip),%rax        # 0x14138d440
   1407cccb8:	48 89 d1             	mov    %rdx,%rcx
   1407cccbb:	4c 89 c6             	mov    %r8,%rsi
   1407cccbe:	66 90                	xchg   %ax,%ax
   1407cccc0:	e8 1b 89 8b ff       	call   0x1400855e0
   1407cccc5:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
   1407ccccc:	00 
   1407ccccd:	48 89 15 bc 15 28 04 	mov    %rdx,0x42815bc(%rip)        # 0x144a4e290
   1407cccd4:	48 8b 94 24 00 01 00 	mov    0x100(%rsp),%rdx
   1407cccdb:	00 
   1407cccdc:	48 89 15 b5 15 28 04 	mov    %rdx,0x42815b5(%rip)        # 0x144a4e298
   1407ccce3:	83 3d 76 8c 2c 04 00 	cmpl   $0x0,0x42c8c76(%rip)        # 0x144a95960
   1407cccea:	75 0a                	jne    0x1407cccf6
   1407cccec:	48 8b b4 24 e8 02 00 	mov    0x2e8(%rsp),%rsi
   1407cccf3:	00 
   1407cccf4:	eb 1e                	jmp    0x1407ccd14
   1407cccf6:	48 8b 15 8b 15 28 04 	mov    0x428158b(%rip),%rdx        # 0x144a4e288
   1407cccfd:	0f 1f 00             	nopl   (%rax)
   1407ccd00:	e8 db 10 8c ff       	call   0x14008dde0
   1407ccd05:	48 8b b4 24 e8 02 00 	mov    0x2e8(%rsp),%rsi
   1407ccd0c:	00 
   1407ccd0d:	49 89 33             	mov    %rsi,(%r11)
   1407ccd10:	49 89 53 08          	mov    %rdx,0x8(%r11)
   1407ccd14:	48 89 35 6d 15 28 04 	mov    %rsi,0x428156d(%rip)        # 0x144a4e288
   1407ccd1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407ccd20:	e9 4a f3 ff ff       	jmp    0x1407cc06f
   1407ccd25:	e8 56 14 8c ff       	call   0x14008e180
   1407ccd2a:	e8 51 14 8c ff       	call   0x14008e180
   1407ccd2f:	e8 4c 14 8c ff       	call   0x14008e180
   1407ccd34:	90                   	nop
   1407ccd35:	e8 06 f6 8b ff       	call   0x14008c340
   1407ccd3a:	e9 81 ee ff ff       	jmp    0x1407cbbc0
   1407ccd3f:	cc                   	int3

# main.repositionToasts @ 0x1407ccd40
   1407ccd40:	4c 8d a4 24 10 ff ff 	lea    -0xf0(%rsp),%r12
   1407ccd47:	ff 
   1407ccd48:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407ccd4c:	0f 86 81 05 00 00    	jbe    0x1407cd2d3
   1407ccd52:	55                   	push   %rbp
   1407ccd53:	48 89 e5             	mov    %rsp,%rbp
   1407ccd56:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   1407ccd5d:	88 84 24 78 01 00 00 	mov    %al,0x178(%rsp)
   1407ccd64:	e8 f7 79 00 00       	call   0x1407d4760
   1407ccd69:	89 4c 24 34          	mov    %ecx,0x34(%rsp)
   1407ccd6d:	89 7c 24 30          	mov    %edi,0x30(%rsp)
   1407ccd71:	48 8b 05 10 15 28 04 	mov    0x4281510(%rip),%rax        # 0x144a4e288
   1407ccd78:	48 8b 15 11 15 28 04 	mov    0x4281511(%rip),%rdx        # 0x144a4e290
   1407ccd7f:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   1407ccd84:	31 db                	xor    %ebx,%ebx
   1407ccd86:	eb 23                	jmp    0x1407ccdab
   1407ccd88:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
   1407ccd8f:	00 
   1407ccd90:	48 05 b0 00 00 00    	add    $0xb0,%rax
   1407ccd96:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   1407ccd9b:	48 ff c3             	inc    %rbx
   1407ccd9e:	8b 4c 24 34          	mov    0x34(%rsp),%ecx
   1407ccda2:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407ccda7:	8b 7c 24 30          	mov    0x30(%rsp),%edi
   1407ccdab:	48 39 d3             	cmp    %rdx,%rbx
   1407ccdae:	0f 8d 16 05 00 00    	jge    0x1407cd2ca
   1407ccdb4:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   1407ccdb9:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   1407ccdc0:	00 
   1407ccdc1:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
   1407ccdc6:	44 0f 10 30          	movups (%rax),%xmm14
   1407ccdca:	44 0f 11 32          	movups %xmm14,(%rdx)
   1407ccdce:	44 0f 10 70 10       	movups 0x10(%rax),%xmm14
   1407ccdd3:	44 0f 11 72 10       	movups %xmm14,0x10(%rdx)
   1407ccdd8:	44 0f 10 70 20       	movups 0x20(%rax),%xmm14
   1407ccddd:	44 0f 11 72 20       	movups %xmm14,0x20(%rdx)
   1407ccde2:	44 0f 10 70 30       	movups 0x30(%rax),%xmm14
   1407ccde7:	44 0f 11 72 30       	movups %xmm14,0x30(%rdx)
   1407ccdec:	44 0f 10 70 40       	movups 0x40(%rax),%xmm14
   1407ccdf1:	44 0f 11 72 40       	movups %xmm14,0x40(%rdx)
   1407ccdf6:	44 0f 10 70 50       	movups 0x50(%rax),%xmm14
   1407ccdfb:	44 0f 11 72 50       	movups %xmm14,0x50(%rdx)
   1407cce00:	44 0f 10 70 60       	movups 0x60(%rax),%xmm14
   1407cce05:	44 0f 11 72 60       	movups %xmm14,0x60(%rdx)
   1407cce0a:	44 0f 10 70 70       	movups 0x70(%rax),%xmm14
   1407cce0f:	44 0f 11 72 70       	movups %xmm14,0x70(%rdx)
   1407cce14:	44 0f 10 b0 80 00 00 	movups 0x80(%rax),%xmm14
   1407cce1b:	00 
   1407cce1c:	44 0f 11 b2 80 00 00 	movups %xmm14,0x80(%rdx)
   1407cce23:	00 
   1407cce24:	44 0f 10 b0 90 00 00 	movups 0x90(%rax),%xmm14
   1407cce2b:	00 
   1407cce2c:	44 0f 11 b2 90 00 00 	movups %xmm14,0x90(%rdx)
   1407cce33:	00 
   1407cce34:	44 0f 10 b0 a0 00 00 	movups 0xa0(%rax),%xmm14
   1407cce3b:	00 
   1407cce3c:	44 0f 11 b2 a0 00 00 	movups %xmm14,0xa0(%rdx)
   1407cce43:	00 
   1407cce44:	48 8b 1d 7d d6 27 04 	mov    0x427d67d(%rip),%rbx        # 0x144a4a4c8
   1407cce4b:	48 8d 8c 24 08 01 00 	lea    0x108(%rsp),%rcx
   1407cce52:	00 
   1407cce53:	44 0f 11 39          	movups %xmm15,(%rcx)
   1407cce57:	44 0f 11 79 10       	movups %xmm15,0x10(%rcx)
   1407cce5c:	44 0f 11 79 20       	movups %xmm15,0x20(%rcx)
   1407cce61:	44 0f 11 79 30       	movups %xmm15,0x30(%rcx)
   1407cce66:	44 0f 11 79 40       	movups %xmm15,0x40(%rcx)
   1407cce6b:	44 0f 11 79 50       	movups %xmm15,0x50(%rcx)
   1407cce70:	48 8d 05 f9 33 b2 00 	lea    0xb233f9(%rip),%rax        # 0x1412f0270
   1407cce77:	e8 e4 8d 85 ff       	call   0x140025c60
   1407cce7c:	eb 0d                	jmp    0x1407cce8b
   1407cce7e:	48 8d 84 24 08 01 00 	lea    0x108(%rsp),%rax
   1407cce85:	00 
   1407cce86:	e8 35 8e 85 ff       	call   0x140025cc0
   1407cce8b:	48 83 bc 24 08 01 00 	cmpq   $0x0,0x108(%rsp)
   1407cce92:	00 00 
   1407cce94:	0f 84 ee fe ff ff    	je     0x1407ccd88
   1407cce9a:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407ccea1:	00 
   1407ccea2:	48 8b 12             	mov    (%rdx),%rdx
   1407ccea5:	48 8b 32             	mov    (%rdx),%rsi
   1407ccea8:	48 39 74 24 50       	cmp    %rsi,0x50(%rsp)
   1407ccead:	75 cf                	jne    0x1407cce7e
   1407cceaf:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cceb6:	00 
   1407cceb7:	f2 0f 10 0d 39 8f 40 	movsd  0x408f39(%rip),%xmm1        # 0x140bd5df8
   1407ccebe:	00 
   1407ccebf:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407ccec3:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407ccec8:	48 89 ce             	mov    %rcx,%rsi
   1407ccecb:	48 c1 ee 34          	shr    $0x34,%rsi
   1407ccecf:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407cced5:	90                   	nop
   1407cced6:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407ccedd:	73 2a                	jae    0x1407ccf09
   1407ccedf:	48 bf 00 00 00 00 00 	movabs $0x8000000000000000,%rdi
   1407ccee6:	00 00 80 
   1407ccee9:	48 21 f9             	and    %rdi,%rcx
   1407cceec:	49 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%r8
   1407ccef3:	00 f0 3f 
   1407ccef6:	49 09 c8             	or     %rcx,%r8
   1407ccef9:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407ccf00:	49 0f 44 c8          	cmove  %r8,%rcx
   1407ccf04:	48 89 cf             	mov    %rcx,%rdi
   1407ccf07:	eb 3e                	jmp    0x1407ccf47
   1407ccf09:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407ccf10:	73 32                	jae    0x1407ccf44
   1407ccf12:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407ccf19:	48 89 c8             	mov    %rcx,%rax
   1407ccf1c:	48 89 f1             	mov    %rsi,%rcx
   1407ccf1f:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407ccf26:	00 08 00 
   1407ccf29:	48 d3 ef             	shr    %cl,%rdi
   1407ccf2c:	48 01 c7             	add    %rax,%rdi
   1407ccf2f:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407ccf36:	ff 0f 00 
   1407ccf39:	49 d3 e8             	shr    %cl,%r8
   1407ccf3c:	49 f7 d0             	not    %r8
   1407ccf3f:	4c 21 c7             	and    %r8,%rdi
   1407ccf42:	eb 03                	jmp    0x1407ccf47
   1407ccf44:	48 89 cf             	mov    %rcx,%rdi
   1407ccf47:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   1407ccf4c:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407ccf50:	8b 7c 24 34          	mov    0x34(%rsp),%edi
   1407ccf54:	41 89 f8             	mov    %edi,%r8d
   1407ccf57:	29 f7                	sub    %esi,%edi
   1407ccf59:	2b ba c0 00 00 00    	sub    0xc0(%rdx),%edi
   1407ccf5f:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407ccf62:	f2 0f 2a c7          	cvtsi2sd %edi,%xmm0
   1407ccf66:	90                   	nop
   1407ccf67:	f2 0f 11 82 d8 00 00 	movsd  %xmm0,0xd8(%rdx)
   1407ccf6e:	00 
   1407ccf6f:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407ccf76:	00 
   1407ccf77:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407ccf7b:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407ccf80:	48 89 ce             	mov    %rcx,%rsi
   1407ccf83:	48 c1 ee 34          	shr    $0x34,%rsi
   1407ccf87:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407ccf8d:	90                   	nop
   1407ccf8e:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407ccf95:	73 2b                	jae    0x1407ccfc2
   1407ccf97:	48 bf 00 00 00 00 00 	movabs $0x8000000000000000,%rdi
   1407ccf9e:	00 00 80 
   1407ccfa1:	48 21 f9             	and    %rdi,%rcx
   1407ccfa4:	49 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%r9
   1407ccfab:	00 f0 3f 
   1407ccfae:	49 09 c9             	or     %rcx,%r9
   1407ccfb1:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407ccfb8:	49 0f 44 c9          	cmove  %r9,%rcx
   1407ccfbc:	48 89 cf             	mov    %rcx,%rdi
   1407ccfbf:	90                   	nop
   1407ccfc0:	eb 3e                	jmp    0x1407cd000
   1407ccfc2:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407ccfc9:	73 32                	jae    0x1407ccffd
   1407ccfcb:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407ccfd2:	48 89 c8             	mov    %rcx,%rax
   1407ccfd5:	48 89 f1             	mov    %rsi,%rcx
   1407ccfd8:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407ccfdf:	00 08 00 
   1407ccfe2:	48 d3 ef             	shr    %cl,%rdi
   1407ccfe5:	48 01 c7             	add    %rax,%rdi
   1407ccfe8:	49 b9 ff ff ff ff ff 	movabs $0xfffffffffffff,%r9
   1407ccfef:	ff 0f 00 
   1407ccff2:	49 d3 e9             	shr    %cl,%r9
   1407ccff5:	49 f7 d1             	not    %r9
   1407ccff8:	4c 21 cf             	and    %r9,%rdi
   1407ccffb:	eb 03                	jmp    0x1407cd000
   1407ccffd:	48 89 cf             	mov    %rcx,%rdi
   1407cd000:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cd007:	00 
   1407cd008:	f2 0f 10 15 d8 8d 40 	movsd  0x408dd8(%rip),%xmm2        # 0x140bd5de8
   1407cd00f:	00 
   1407cd010:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   1407cd014:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cd019:	48 89 ce             	mov    %rcx,%rsi
   1407cd01c:	48 c1 ee 34          	shr    $0x34,%rsi
   1407cd020:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407cd026:	90                   	nop
   1407cd027:	90                   	nop
   1407cd028:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407cd02f:	73 2f                	jae    0x1407cd060
   1407cd031:	49 b9 00 00 00 00 00 	movabs $0x8000000000000000,%r9
   1407cd038:	00 00 80 
   1407cd03b:	4c 21 c9             	and    %r9,%rcx
   1407cd03e:	49 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%r10
   1407cd045:	00 f0 3f 
   1407cd048:	49 09 ca             	or     %rcx,%r10
   1407cd04b:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407cd052:	49 0f 44 ca          	cmove  %r10,%rcx
   1407cd056:	49 89 c9             	mov    %rcx,%r9
   1407cd059:	eb 43                	jmp    0x1407cd09e
   1407cd05b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cd060:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407cd067:	73 32                	jae    0x1407cd09b
   1407cd069:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407cd070:	48 89 c8             	mov    %rcx,%rax
   1407cd073:	48 89 f1             	mov    %rsi,%rcx
   1407cd076:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407cd07d:	00 08 00 
   1407cd080:	49 d3 e9             	shr    %cl,%r9
   1407cd083:	49 01 c1             	add    %rax,%r9
   1407cd086:	49 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%r10
   1407cd08d:	ff 0f 00 
   1407cd090:	49 d3 ea             	shr    %cl,%r10
   1407cd093:	49 f7 d2             	not    %r10
   1407cd096:	4d 21 d1             	and    %r10,%r9
   1407cd099:	eb 03                	jmp    0x1407cd09e
   1407cd09b:	49 89 c9             	mov    %rcx,%r9
   1407cd09e:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   1407cd0a3:	8b b2 c4 00 00 00    	mov    0xc4(%rdx),%esi
   1407cd0a9:	4c 8b 15 e0 11 28 04 	mov    0x42811e0(%rip),%r10        # 0x144a4e290
   1407cd0b0:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
   1407cd0b5:	4d 29 da             	sub    %r11,%r10
   1407cd0b8:	49 ff ca             	dec    %r10
   1407cd0bb:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   1407cd0c0:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407cd0c4:	44 8b 64 24 30       	mov    0x30(%rsp),%r12d
   1407cd0c9:	45 89 e5             	mov    %r12d,%r13d
   1407cd0cc:	41 29 fc             	sub    %edi,%r12d
   1407cd0cf:	41 29 f4             	sub    %esi,%r12d
   1407cd0d2:	66 49 0f 6e c1       	movq   %r9,%xmm0
   1407cd0d7:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407cd0db:	01 fe                	add    %edi,%esi
   1407cd0dd:	44 0f af d6          	imul   %esi,%r10d
   1407cd0e1:	45 29 d4             	sub    %r10d,%r12d
   1407cd0e4:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd0e7:	f2 41 0f 2a c4       	cvtsi2sd %r12d,%xmm0
   1407cd0ec:	90                   	nop
   1407cd0ed:	f2 0f 11 82 e0 00 00 	movsd  %xmm0,0xe0(%rdx)
   1407cd0f4:	00 
   1407cd0f5:	0f b6 b4 24 78 01 00 	movzbl 0x178(%rsp),%esi
   1407cd0fc:	00 
   1407cd0fd:	0f 1f 00             	nopl   (%rax)
   1407cd100:	40 84 f6             	test   %sil,%sil
   1407cd103:	75 04                	jne    0x1407cd109
   1407cd105:	31 c0                	xor    %eax,%eax
   1407cd107:	eb 57                	jmp    0x1407cd160
   1407cd109:	48 8b 82 e8 00 00 00 	mov    0xe8(%rdx),%rax
   1407cd110:	48 8b 9a f0 00 00 00 	mov    0xf0(%rdx),%rbx
   1407cd117:	48 8b 8a f8 00 00 00 	mov    0xf8(%rdx),%rcx
   1407cd11e:	66 90                	xchg   %ax,%ax
   1407cd120:	e8 bb ea 8e ff       	call   0x1400bbbe0
   1407cd125:	48 3d 80 f0 fa 02    	cmp    $0x2faf080,%rax
   1407cd12b:	0f 9c c2             	setl   %dl
   1407cd12e:	0f b6 b4 24 78 01 00 	movzbl 0x178(%rsp),%esi
   1407cd135:	00 
   1407cd136:	44 8b 44 24 34       	mov    0x34(%rsp),%r8d
   1407cd13b:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
   1407cd140:	44 8b 6c 24 30       	mov    0x30(%rsp),%r13d
   1407cd145:	f2 0f 10 0d ab 8c 40 	movsd  0x408cab(%rip),%xmm1        # 0x140bd5df8
   1407cd14c:	00 
   1407cd14d:	f2 0f 10 15 93 8c 40 	movsd  0x408c93(%rip),%xmm2        # 0x140bd5de8
   1407cd154:	00 
   1407cd155:	89 d0                	mov    %edx,%eax
   1407cd157:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407cd15c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cd160:	84 c0                	test   %al,%al
   1407cd162:	0f 84 ca 00 00 00    	je     0x1407cd232
   1407cd168:	f2 0f 10 82 d8 00 00 	movsd  0xd8(%rdx),%xmm0
   1407cd16f:	00 
   1407cd170:	f2 0f 11 82 c8 00 00 	movsd  %xmm0,0xc8(%rdx)
   1407cd177:	00 
   1407cd178:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cd17f:	00 
   1407cd180:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cd184:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cd189:	48 89 cf             	mov    %rcx,%rdi
   1407cd18c:	48 c1 ef 34          	shr    $0x34,%rdi
   1407cd190:	81 e7 ff 07 00 00    	and    $0x7ff,%edi
   1407cd196:	90                   	nop
   1407cd197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1407cd19e:	00 00 
   1407cd1a0:	48 81 ff ff 03 00 00 	cmp    $0x3ff,%rdi
   1407cd1a7:	73 2a                	jae    0x1407cd1d3
   1407cd1a9:	49 b9 00 00 00 00 00 	movabs $0x8000000000000000,%r9
   1407cd1b0:	00 00 80 
   1407cd1b3:	4c 21 c9             	and    %r9,%rcx
   1407cd1b6:	49 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%r10
   1407cd1bd:	00 f0 3f 
   1407cd1c0:	49 09 ca             	or     %rcx,%r10
   1407cd1c3:	48 81 ff fe 03 00 00 	cmp    $0x3fe,%rdi
   1407cd1ca:	49 0f 44 ca          	cmove  %r10,%rcx
   1407cd1ce:	49 89 c9             	mov    %rcx,%r9
   1407cd1d1:	eb 3e                	jmp    0x1407cd211
   1407cd1d3:	48 81 ff 33 04 00 00 	cmp    $0x433,%rdi
   1407cd1da:	73 32                	jae    0x1407cd20e
   1407cd1dc:	48 81 c7 01 fc ff ff 	add    $0xfffffffffffffc01,%rdi
   1407cd1e3:	48 89 c8             	mov    %rcx,%rax
   1407cd1e6:	48 89 f9             	mov    %rdi,%rcx
   1407cd1e9:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407cd1f0:	00 08 00 
   1407cd1f3:	49 d3 e9             	shr    %cl,%r9
   1407cd1f6:	49 01 c1             	add    %rax,%r9
   1407cd1f9:	49 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%r10
   1407cd200:	ff 0f 00 
   1407cd203:	49 d3 ea             	shr    %cl,%r10
   1407cd206:	49 f7 d2             	not    %r10
   1407cd209:	4d 21 d1             	and    %r10,%r9
   1407cd20c:	eb 03                	jmp    0x1407cd211
   1407cd20e:	49 89 c9             	mov    %rcx,%r9
   1407cd211:	66 49 0f 6e c1       	movq   %r9,%xmm0
   1407cd216:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407cd21a:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd21d:	f2 0f 2a c7          	cvtsi2sd %edi,%xmm0
   1407cd221:	f2 0f 58 82 e0 00 00 	addsd  0xe0(%rdx),%xmm0
   1407cd228:	00 
   1407cd229:	90                   	nop
   1407cd22a:	f2 0f 11 82 d0 00 00 	movsd  %xmm0,0xd0(%rdx)
   1407cd231:	00 
   1407cd232:	b8 38 00 00 00       	mov    $0x38,%eax
   1407cd237:	48 8d 1d 22 34 af 00 	lea    0xaf3422(%rip),%rbx        # 0x1412c0660
   1407cd23e:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cd243:	e8 98 77 85 ff       	call   0x1400249e0
   1407cd248:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407cd24d:	48 8b b2 b0 00 00 00 	mov    0xb0(%rdx),%rsi
   1407cd254:	48 89 30             	mov    %rsi,(%rax)
   1407cd257:	48 c7 40 08 ff ff ff 	movq   $0xffffffffffffffff,0x8(%rax)
   1407cd25e:	ff 
   1407cd25f:	f2 0f 10 82 c8 00 00 	movsd  0xc8(%rdx),%xmm0
   1407cd266:	00 
   1407cd267:	f2 48 0f 2c f0       	cvttsd2si %xmm0,%rsi
   1407cd26c:	48 89 70 10          	mov    %rsi,0x10(%rax)
   1407cd270:	f2 0f 10 82 d0 00 00 	movsd  0xd0(%rdx),%xmm0
   1407cd277:	00 
   1407cd278:	f2 48 0f 2c f0       	cvttsd2si %xmm0,%rsi
   1407cd27d:	48 89 70 18          	mov    %rsi,0x18(%rax)
   1407cd281:	48 63 b2 c0 00 00 00 	movslq 0xc0(%rdx),%rsi
   1407cd288:	48 89 70 20          	mov    %rsi,0x20(%rax)
   1407cd28c:	48 63 92 c4 00 00 00 	movslq 0xc4(%rdx),%rdx
   1407cd293:	48 89 50 28          	mov    %rdx,0x28(%rax)
   1407cd297:	48 c7 40 30 50 00 00 	movq   $0x50,0x30(%rax)
   1407cd29e:	00 
   1407cd29f:	48 8b 15 a2 dc 21 04 	mov    0x421dca2(%rip),%rdx        # 0x1449eaf48
   1407cd2a6:	48 8d 1d e6 25 0c 00 	lea    0xc25e6(%rip),%rbx        # 0x14088f893
   1407cd2ad:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407cd2b2:	48 89 c7             	mov    %rax,%rdi
   1407cd2b5:	be 07 00 00 00       	mov    $0x7,%esi
   1407cd2ba:	41 89 f0             	mov    %esi,%r8d
   1407cd2bd:	48 89 d0             	mov    %rdx,%rax
   1407cd2c0:	e8 db c6 fc ff       	call   0x1407999a0
   1407cd2c5:	e9 b4 fb ff ff       	jmp    0x1407cce7e
   1407cd2ca:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   1407cd2d1:	5d                   	pop    %rbp
   1407cd2d2:	c3                   	ret
   1407cd2d3:	88 44 24 08          	mov    %al,0x8(%rsp)
   1407cd2d7:	e8 64 f0 8b ff       	call   0x14008c340
   1407cd2dc:	0f b6 44 24 08       	movzbl 0x8(%rsp),%eax
   1407cd2e1:	e9 5a fa ff ff       	jmp    0x1407ccd40
   1407cd2e6:	cc                   	int3
   1407cd2e7:	cc                   	int3
   1407cd2e8:	cc                   	int3
   1407cd2e9:	cc                   	int3
   1407cd2ea:	cc                   	int3
   1407cd2eb:	cc                   	int3
   1407cd2ec:	cc                   	int3
   1407cd2ed:	cc                   	int3
   1407cd2ee:	cc                   	int3
   1407cd2ef:	cc                   	int3
   1407cd2f0:	cc                   	int3
   1407cd2f1:	cc                   	int3
   1407cd2f2:	cc                   	int3
   1407cd2f3:	cc                   	int3
   1407cd2f4:	cc                   	int3
   1407cd2f5:	cc                   	int3
   1407cd2f6:	cc                   	int3
   1407cd2f7:	cc                   	int3
   1407cd2f8:	cc                   	int3
   1407cd2f9:	cc                   	int3
   1407cd2fa:	cc                   	int3
   1407cd2fb:	cc                   	int3
   1407cd2fc:	cc                   	int3
   1407cd2fd:	cc                   	int3
   1407cd2fe:	cc                   	int3
   1407cd2ff:	cc                   	int3

# main.toastTick @ 0x1407cd300
   1407cd300:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407cd304:	0f 86 b7 06 00 00    	jbe    0x1407cd9c1
   1407cd30a:	55                   	push   %rbp
   1407cd30b:	48 89 e5             	mov    %rsp,%rbp
   1407cd30e:	48 83 ec 68          	sub    $0x68,%rsp
   1407cd312:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   1407cd317:	e8 84 49 8f ff       	call   0x1400c1ca0
   1407cd31c:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   1407cd321:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   1407cd326:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
   1407cd32b:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd330:	48 8b ba 00 01 00 00 	mov    0x100(%rdx),%rdi
   1407cd337:	48 8b b2 08 01 00 00 	mov    0x108(%rdx),%rsi
   1407cd33e:	4c 8b 82 10 01 00 00 	mov    0x110(%rdx),%r8
   1407cd345:	e8 d6 e6 8e ff       	call   0x1400bba20
   1407cd34a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   1407cd34f:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   1407cd354:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd359:	48 89 8a 00 01 00 00 	mov    %rcx,0x100(%rdx)
   1407cd360:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
   1407cd365:	48 89 9a 08 01 00 00 	mov    %rbx,0x108(%rdx)
   1407cd36c:	83 3d ed 85 2c 04 00 	cmpl   $0x0,0x42c85ed(%rip)        # 0x144a95960
   1407cd373:	75 07                	jne    0x1407cd37c
   1407cd375:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
   1407cd37a:	eb 18                	jmp    0x1407cd394
   1407cd37c:	48 8b b2 10 01 00 00 	mov    0x110(%rdx),%rsi
   1407cd383:	e8 58 0a 8c ff       	call   0x14008dde0
   1407cd388:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
   1407cd38d:	49 89 3b             	mov    %rdi,(%r11)
   1407cd390:	49 89 73 08          	mov    %rsi,0x8(%r11)
   1407cd394:	48 89 ba 10 01 00 00 	mov    %rdi,0x110(%rdx)
   1407cd39b:	48 8d 05 2e 01 bc 00 	lea    0xbc012e(%rip),%rax        # 0x14138d4d0
   1407cd3a2:	e8 59 4a 85 ff       	call   0x140021e00
   1407cd3a7:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   1407cd3ac:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   1407cd3b1:	b8 08 00 00 00       	mov    $0x8,%eax
   1407cd3b6:	48 8d 1d b3 01 af 00 	lea    0xaf01b3(%rip),%rbx        # 0x1412bd570
   1407cd3bd:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cd3c2:	e8 b9 69 85 ff       	call   0x140023d80
   1407cd3c7:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   1407cd3cc:	48 89 08             	mov    %rcx,(%rax)
   1407cd3cf:	48 8b 0d 72 db 21 04 	mov    0x421db72(%rip),%rcx        # 0x1449eaf48
   1407cd3d6:	48 8d 1d c2 24 0c 00 	lea    0xc24c2(%rip),%rbx        # 0x14088f89f
   1407cd3dd:	48 89 c7             	mov    %rax,%rdi
   1407cd3e0:	be 01 00 00 00       	mov    $0x1,%esi
   1407cd3e5:	41 89 f0             	mov    %esi,%r8d
   1407cd3e8:	48 89 c8             	mov    %rcx,%rax
   1407cd3eb:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407cd3f0:	e8 ab c5 fc ff       	call   0x1407999a0
   1407cd3f5:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   1407cd3fa:	8b 11                	mov    (%rcx),%edx
   1407cd3fc:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd3ff:	f2 0f 2a c2          	cvtsi2sd %edx,%xmm0
   1407cd403:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd408:	f2 0f 10 8a c8 00 00 	movsd  0xc8(%rdx),%xmm1
   1407cd40f:	00 
   1407cd410:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   1407cd414:	72 50                	jb     0x1407cd466
   1407cd416:	44 8b 8a c0 00 00 00 	mov    0xc0(%rdx),%r9d
   1407cd41d:	0f 57 d2             	xorps  %xmm2,%xmm2
   1407cd420:	f2 41 0f 2a d1       	cvtsi2sd %r9d,%xmm2
   1407cd425:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   1407cd429:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   1407cd42d:	76 37                	jbe    0x1407cd466
   1407cd42f:	44 8b 49 04          	mov    0x4(%rcx),%r9d
   1407cd433:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd436:	f2 41 0f 2a c1       	cvtsi2sd %r9d,%xmm0
   1407cd43b:	f2 0f 10 92 d0 00 00 	movsd  0xd0(%rdx),%xmm2
   1407cd442:	00 
   1407cd443:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
   1407cd447:	72 1d                	jb     0x1407cd466
   1407cd449:	44 8b 8a c4 00 00 00 	mov    0xc4(%rdx),%r9d
   1407cd450:	0f 57 db             	xorps  %xmm3,%xmm3
   1407cd453:	f2 41 0f 2a d9       	cvtsi2sd %r9d,%xmm3
   1407cd458:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
   1407cd45c:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   1407cd460:	41 0f 97 c1          	seta   %r9b
   1407cd464:	eb 03                	jmp    0x1407cd469
   1407cd466:	45 31 c9             	xor    %r9d,%r9d
   1407cd469:	44 88 8a 38 01 00 00 	mov    %r9b,0x138(%rdx)
   1407cd470:	45 84 c9             	test   %r9b,%r9b
   1407cd473:	0f 84 c2 00 00 00    	je     0x1407cd53b
   1407cd479:	f2 0f 10 05 e7 89 40 	movsd  0x4089e7(%rip),%xmm0        # 0x140bd5e68
   1407cd480:	00 
   1407cd481:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407cd488:	00 
   1407cd489:	66 49 0f 7e c1       	movq   %xmm0,%r9
   1407cd48e:	4d 89 ca             	mov    %r9,%r10
   1407cd491:	49 c1 e9 34          	shr    $0x34,%r9
   1407cd495:	41 81 e1 ff 07 00 00 	and    $0x7ff,%r9d
   1407cd49c:	90                   	nop
   1407cd49d:	0f 1f 00             	nopl   (%rax)
   1407cd4a0:	49 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9
   1407cd4a7:	73 2d                	jae    0x1407cd4d6
   1407cd4a9:	49 bb 00 00 00 00 00 	movabs $0x8000000000000000,%r11
   1407cd4b0:	00 00 80 
   1407cd4b3:	4d 21 da             	and    %r11,%r10
   1407cd4b6:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cd4bd:	00 f0 3f 
   1407cd4c0:	4d 09 d4             	or     %r10,%r12
   1407cd4c3:	49 81 f9 fe 03 00 00 	cmp    $0x3fe,%r9
   1407cd4ca:	4d 0f 44 d4          	cmove  %r12,%r10
   1407cd4ce:	48 89 c8             	mov    %rcx,%rax
   1407cd4d1:	4d 89 d1             	mov    %r10,%r9
   1407cd4d4:	eb 42                	jmp    0x1407cd518
   1407cd4d6:	49 81 f9 33 04 00 00 	cmp    $0x433,%r9
   1407cd4dd:	73 33                	jae    0x1407cd512
   1407cd4df:	4d 8d 99 01 fc ff ff 	lea    -0x3ff(%r9),%r11
   1407cd4e6:	48 89 c8             	mov    %rcx,%rax
   1407cd4e9:	4c 89 d9             	mov    %r11,%rcx
   1407cd4ec:	49 bc 00 00 00 00 00 	movabs $0x8000000000000,%r12
   1407cd4f3:	00 08 00 
   1407cd4f6:	49 d3 ec             	shr    %cl,%r12
   1407cd4f9:	4f 8d 0c 22          	lea    (%r10,%r12,1),%r9
   1407cd4fd:	49 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%r10
   1407cd504:	ff 0f 00 
   1407cd507:	49 d3 ea             	shr    %cl,%r10
   1407cd50a:	49 f7 d2             	not    %r10
   1407cd50d:	4d 21 d1             	and    %r10,%r9
   1407cd510:	eb 06                	jmp    0x1407cd518
   1407cd512:	48 89 c8             	mov    %rcx,%rax
   1407cd515:	4d 89 d1             	mov    %r10,%r9
   1407cd518:	f2 44 0f 2c d1       	cvttsd2si %xmm1,%r10d
   1407cd51d:	44 03 92 c0 00 00 00 	add    0xc0(%rdx),%r10d
   1407cd524:	66 49 0f 6e c1       	movq   %r9,%xmm0
   1407cd529:	f2 44 0f 2c c8       	cvttsd2si %xmm0,%r9d
   1407cd52e:	45 29 ca             	sub    %r9d,%r10d
   1407cd531:	90                   	nop
   1407cd532:	44 39 10             	cmp    %r10d,(%rax)
   1407cd535:	41 0f 9d c1          	setge  %r9b
   1407cd539:	eb 06                	jmp    0x1407cd541
   1407cd53b:	48 89 c8             	mov    %rcx,%rax
   1407cd53e:	45 31 c9             	xor    %r9d,%r9d
   1407cd541:	45 84 c9             	test   %r9b,%r9b
   1407cd544:	0f 84 bb 00 00 00    	je     0x1407cd605
   1407cd54a:	f2 0f 10 05 1e 89 40 	movsd  0x40891e(%rip),%xmm0        # 0x140bd5e70
   1407cd551:	00 
   1407cd552:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407cd559:	00 
   1407cd55a:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cd55f:	49 89 c9             	mov    %rcx,%r9
   1407cd562:	49 c1 e9 34          	shr    $0x34,%r9
   1407cd566:	41 81 e1 ff 07 00 00 	and    $0x7ff,%r9d
   1407cd56d:	90                   	nop
   1407cd56e:	49 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9
   1407cd575:	73 2b                	jae    0x1407cd5a2
   1407cd577:	49 ba 00 00 00 00 00 	movabs $0x8000000000000000,%r10
   1407cd57e:	00 00 80 
   1407cd581:	4c 21 d1             	and    %r10,%rcx
   1407cd584:	49 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%r10
   1407cd58b:	00 f0 3f 
   1407cd58e:	49 09 ca             	or     %rcx,%r10
   1407cd591:	49 81 f9 fe 03 00 00 	cmp    $0x3fe,%r9
   1407cd598:	49 0f 44 ca          	cmove  %r10,%rcx
   1407cd59c:	49 89 ca             	mov    %rcx,%r10
   1407cd59f:	90                   	nop
   1407cd5a0:	eb 3e                	jmp    0x1407cd5e0
   1407cd5a2:	49 81 f9 33 04 00 00 	cmp    $0x433,%r9
   1407cd5a9:	73 32                	jae    0x1407cd5dd
   1407cd5ab:	49 81 c1 01 fc ff ff 	add    $0xfffffffffffffc01,%r9
   1407cd5b2:	48 89 cb             	mov    %rcx,%rbx
   1407cd5b5:	4c 89 c9             	mov    %r9,%rcx
   1407cd5b8:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407cd5bf:	00 08 00 
   1407cd5c2:	49 d3 ea             	shr    %cl,%r10
   1407cd5c5:	49 01 da             	add    %rbx,%r10
   1407cd5c8:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407cd5cf:	ff 0f 00 
   1407cd5d2:	49 d3 eb             	shr    %cl,%r11
   1407cd5d5:	49 f7 d3             	not    %r11
   1407cd5d8:	4d 21 da             	and    %r11,%r10
   1407cd5db:	eb 03                	jmp    0x1407cd5e0
   1407cd5dd:	49 89 ca             	mov    %rcx,%r10
   1407cd5e0:	f2 0f 10 82 d0 00 00 	movsd  0xd0(%rdx),%xmm0
   1407cd5e7:	00 
   1407cd5e8:	f2 44 0f 2c c8       	cvttsd2si %xmm0,%r9d
   1407cd5ed:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407cd5f2:	f2 44 0f 2c d0       	cvttsd2si %xmm0,%r10d
   1407cd5f7:	45 01 d1             	add    %r10d,%r9d
   1407cd5fa:	90                   	nop
   1407cd5fb:	44 39 48 04          	cmp    %r9d,0x4(%rax)
   1407cd5ff:	41 0f 9c c1          	setl   %r9b
   1407cd603:	eb 03                	jmp    0x1407cd608
   1407cd605:	45 31 c9             	xor    %r9d,%r9d
   1407cd608:	44 88 8a 39 01 00 00 	mov    %r9b,0x139(%rdx)
   1407cd60f:	48 83 ba 20 01 00 00 	cmpq   $0x0,0x120(%rdx)
   1407cd616:	00 
   1407cd617:	0f 85 85 00 00 00    	jne    0x1407cd6a2
   1407cd61d:	48 83 ba 28 01 00 00 	cmpq   $0x0,0x128(%rdx)
   1407cd624:	00 
   1407cd625:	75 7b                	jne    0x1407cd6a2
   1407cd627:	80 ba 38 01 00 00 00 	cmpb   $0x0,0x138(%rdx)
   1407cd62e:	75 0c                	jne    0x1407cd63c
   1407cd630:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   1407cd635:	4c 29 8a 18 01 00 00 	sub    %r9,0x118(%rdx)
   1407cd63c:	48 83 ba 18 01 00 00 	cmpq   $0x0,0x118(%rdx)
   1407cd643:	00 
   1407cd644:	7f 49                	jg     0x1407cd68f
   1407cd646:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   1407cd64b:	48 89 82 20 01 00 00 	mov    %rax,0x120(%rdx)
   1407cd652:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
   1407cd657:	48 89 9a 28 01 00 00 	mov    %rbx,0x128(%rdx)
   1407cd65e:	83 3d fb 82 2c 04 00 	cmpl   $0x0,0x42c82fb(%rip)        # 0x144a95960
   1407cd665:	75 07                	jne    0x1407cd66e
   1407cd667:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1407cd66c:	eb 18                	jmp    0x1407cd686
   1407cd66e:	4c 8b 8a 30 01 00 00 	mov    0x130(%rdx),%r9
   1407cd675:	e8 66 07 8c ff       	call   0x14008dde0
   1407cd67a:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1407cd67f:	49 89 0b             	mov    %rcx,(%r11)
   1407cd682:	4d 89 4b 08          	mov    %r9,0x8(%r11)
   1407cd686:	48 89 8a 30 01 00 00 	mov    %rcx,0x130(%rdx)
   1407cd68d:	eb 22                	jmp    0x1407cd6b1
   1407cd68f:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   1407cd694:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1407cd699:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
   1407cd69e:	66 90                	xchg   %ax,%ax
   1407cd6a0:	eb 0f                	jmp    0x1407cd6b1
   1407cd6a2:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   1407cd6a7:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1407cd6ac:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
   1407cd6b1:	48 8b b2 f0 00 00 00 	mov    0xf0(%rdx),%rsi
   1407cd6b8:	48 8b ba e8 00 00 00 	mov    0xe8(%rdx),%rdi
   1407cd6bf:	4c 8b 82 f8 00 00 00 	mov    0xf8(%rdx),%r8
   1407cd6c6:	e8 55 e3 8e ff       	call   0x1400bba20
   1407cd6cb:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd6ce:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   1407cd6d3:	f2 0f 10 0d 15 88 40 	movsd  0x408815(%rip),%xmm1        # 0x140bd5ef0
   1407cd6da:	00 
   1407cd6db:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   1407cd6df:	f2 0f 10 0d f1 86 40 	movsd  0x4086f1(%rip),%xmm1        # 0x140bd5dd8
   1407cd6e6:	00 
   1407cd6e7:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   1407cd6eb:	f2 0f 10 05 e5 86 40 	movsd  0x4086e5(%rip),%xmm0        # 0x140bd5dd8
   1407cd6f2:	00 
   1407cd6f3:	0f 10 d1             	movups %xmm1,%xmm2
   1407cd6f6:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   1407cd6fa:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd6ff:	48 8b ba 20 01 00 00 	mov    0x120(%rdx),%rdi
   1407cd706:	66 0f eb ca          	por    %xmm2,%xmm1
   1407cd70a:	48 8b b2 28 01 00 00 	mov    0x128(%rdx),%rsi
   1407cd711:	48 85 ff             	test   %rdi,%rdi
   1407cd714:	75 05                	jne    0x1407cd71b
   1407cd716:	48 85 f6             	test   %rsi,%rsi
   1407cd719:	74 50                	je     0x1407cd76b
   1407cd71b:	4c 8b 82 30 01 00 00 	mov    0x130(%rdx),%r8
   1407cd722:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   1407cd727:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
   1407cd72c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1407cd731:	e8 ea e2 8e ff       	call   0x1400bba20
   1407cd736:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd739:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   1407cd73e:	f2 0f 10 0d aa 87 40 	movsd  0x4087aa(%rip),%xmm1        # 0x140bd5ef0
   1407cd745:	00 
   1407cd746:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   1407cd74a:	f2 0f 10 0d 86 86 40 	movsd  0x408686(%rip),%xmm1        # 0x140bd5dd8
   1407cd751:	00 
   1407cd752:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
   1407cd756:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407cd759:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   1407cd75d:	0f 1f 00             	nopl   (%rax)
   1407cd760:	0f 83 08 02 00 00    	jae    0x1407cd96e
   1407cd766:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd76b:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
   1407cd771:	f2 0f 10 82 c8 00 00 	movsd  0xc8(%rdx),%xmm0
   1407cd778:	00 
   1407cd779:	f2 0f 10 92 d8 00 00 	movsd  0xd8(%rdx),%xmm2
   1407cd780:	00 
   1407cd781:	f2 0f 5c d0          	subsd  %xmm0,%xmm2
   1407cd785:	f2 0f 10 1d 3b 86 40 	movsd  0x40863b(%rip),%xmm3        # 0x140bd5dc8
   1407cd78c:	00 
   1407cd78d:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   1407cd791:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   1407cd795:	f2 0f 11 92 c8 00 00 	movsd  %xmm2,0xc8(%rdx)
   1407cd79c:	00 
   1407cd79d:	f2 0f 10 82 d0 00 00 	movsd  0xd0(%rdx),%xmm0
   1407cd7a4:	00 
   1407cd7a5:	f2 0f 10 92 e0 00 00 	movsd  0xe0(%rdx),%xmm2
   1407cd7ac:	00 
   1407cd7ad:	0f 10 e2             	movups %xmm2,%xmm4
   1407cd7b0:	f2 0f 5c d0          	subsd  %xmm0,%xmm2
   1407cd7b4:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   1407cd7b8:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   1407cd7bc:	f2 0f 11 92 d0 00 00 	movsd  %xmm2,0xd0(%rdx)
   1407cd7c3:	00 
   1407cd7c4:	f2 0f 5c d4          	subsd  %xmm4,%xmm2
   1407cd7c8:	66 48 0f 7e d6       	movq   %xmm2,%rsi
   1407cd7cd:	48 0f ba f6 3f       	btr    $0x3f,%rsi
   1407cd7d2:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407cd7d7:	f2 0f 10 15 f1 85 40 	movsd  0x4085f1(%rip),%xmm2        # 0x140bd5dd0
   1407cd7de:	00 
   1407cd7df:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   1407cd7e3:	76 08                	jbe    0x1407cd7ed
   1407cd7e5:	f2 0f 11 a2 d0 00 00 	movsd  %xmm4,0xd0(%rdx)
   1407cd7ec:	00 
   1407cd7ed:	b8 20 00 00 00       	mov    $0x20,%eax
   1407cd7f2:	48 8d 1d e7 20 af 00 	lea    0xaf20e7(%rip),%rbx        # 0x1412bf8e0
   1407cd7f9:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cd7fe:	66 90                	xchg   %ax,%ax
   1407cd800:	e8 1b 6d 85 ff       	call   0x140024520
   1407cd805:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd80a:	48 8b 92 b0 00 00 00 	mov    0xb0(%rdx),%rdx
   1407cd811:	48 89 10             	mov    %rdx,(%rax)
   1407cd814:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
   1407cd81b:	00 
   1407cd81c:	f2 0f 10 44 24 38    	movsd  0x38(%rsp),%xmm0
   1407cd822:	f2 0f 10 0d 7e 86 40 	movsd  0x40867e(%rip),%xmm1        # 0x140bd5ea8
   1407cd829:	00 
   1407cd82a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cd82e:	f2 48 0f 2c d0       	cvttsd2si %xmm0,%rdx
   1407cd833:	48 81 fa ff 00 00 00 	cmp    $0xff,%rdx
   1407cd83a:	be ff 00 00 00       	mov    $0xff,%esi
   1407cd83f:	48 0f 4c f2          	cmovl  %rdx,%rsi
   1407cd843:	48 85 f6             	test   %rsi,%rsi
   1407cd846:	ba 00 00 00 00       	mov    $0x0,%edx
   1407cd84b:	48 0f 4f d6          	cmovg  %rsi,%rdx
   1407cd84f:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407cd853:	48 c7 40 18 02 00 00 	movq   $0x2,0x18(%rax)
   1407cd85a:	00 
   1407cd85b:	48 8b 15 e6 d6 21 04 	mov    0x421d6e6(%rip),%rdx        # 0x1449eaf48
   1407cd862:	48 8d 1d b2 7d 0d 00 	lea    0xd7db2(%rip),%rbx        # 0x1408a561b
   1407cd869:	b9 1a 00 00 00       	mov    $0x1a,%ecx
   1407cd86e:	48 89 c7             	mov    %rax,%rdi
   1407cd871:	be 04 00 00 00       	mov    $0x4,%esi
   1407cd876:	41 89 f0             	mov    %esi,%r8d
   1407cd879:	48 89 d0             	mov    %rdx,%rax
   1407cd87c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cd880:	e8 1b c1 fc ff       	call   0x1407999a0
   1407cd885:	b8 38 00 00 00       	mov    $0x38,%eax
   1407cd88a:	48 8d 1d cf 2d af 00 	lea    0xaf2dcf(%rip),%rbx        # 0x1412c0660
   1407cd891:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cd896:	e8 45 71 85 ff       	call   0x1400249e0
   1407cd89b:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd8a0:	48 8b b2 b0 00 00 00 	mov    0xb0(%rdx),%rsi
   1407cd8a7:	48 89 30             	mov    %rsi,(%rax)
   1407cd8aa:	48 c7 40 08 ff ff ff 	movq   $0xffffffffffffffff,0x8(%rax)
   1407cd8b1:	ff 
   1407cd8b2:	f2 0f 10 82 c8 00 00 	movsd  0xc8(%rdx),%xmm0
   1407cd8b9:	00 
   1407cd8ba:	f2 48 0f 2c f0       	cvttsd2si %xmm0,%rsi
   1407cd8bf:	48 89 70 10          	mov    %rsi,0x10(%rax)
   1407cd8c3:	f2 0f 10 82 d0 00 00 	movsd  0xd0(%rdx),%xmm0
   1407cd8ca:	00 
   1407cd8cb:	f2 48 0f 2c f0       	cvttsd2si %xmm0,%rsi
   1407cd8d0:	48 89 70 18          	mov    %rsi,0x18(%rax)
   1407cd8d4:	48 63 b2 c0 00 00 00 	movslq 0xc0(%rdx),%rsi
   1407cd8db:	48 89 70 20          	mov    %rsi,0x20(%rax)
   1407cd8df:	48 63 92 c4 00 00 00 	movslq 0xc4(%rdx),%rdx
   1407cd8e6:	48 89 50 28          	mov    %rdx,0x28(%rax)
   1407cd8ea:	48 c7 40 30 10 00 00 	movq   $0x10,0x30(%rax)
   1407cd8f1:	00 
   1407cd8f2:	48 8b 15 4f d6 21 04 	mov    0x421d64f(%rip),%rdx        # 0x1449eaf48
   1407cd8f9:	48 8d 1d 93 1f 0c 00 	lea    0xc1f93(%rip),%rbx        # 0x14088f893
   1407cd900:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407cd905:	48 89 c7             	mov    %rax,%rdi
   1407cd908:	be 07 00 00 00       	mov    $0x7,%esi
   1407cd90d:	41 89 f0             	mov    %esi,%r8d
   1407cd910:	48 89 d0             	mov    %rdx,%rax
   1407cd913:	e8 88 c0 fc ff       	call   0x1407999a0
   1407cd918:	b8 18 00 00 00       	mov    $0x18,%eax
   1407cd91d:	48 8d 1d 04 17 af 00 	lea    0xaf1704(%rip),%rbx        # 0x1412bf028
   1407cd924:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cd929:	e8 92 69 85 ff       	call   0x1400242c0
   1407cd92e:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd933:	48 8b 92 b0 00 00 00 	mov    0xb0(%rdx),%rdx
   1407cd93a:	48 89 10             	mov    %rdx,(%rax)
   1407cd93d:	44 0f 11 78 08       	movups %xmm15,0x8(%rax)
   1407cd942:	48 8b 15 ff d5 21 04 	mov    0x421d5ff(%rip),%rdx        # 0x1449eaf48
   1407cd949:	48 8d 1d e4 4c 0c 00 	lea    0xc4ce4(%rip),%rbx        # 0x140892634
   1407cd950:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407cd955:	48 89 c7             	mov    %rax,%rdi
   1407cd958:	be 03 00 00 00       	mov    $0x3,%esi
   1407cd95d:	41 89 f0             	mov    %esi,%r8d
   1407cd960:	48 89 d0             	mov    %rdx,%rax
   1407cd963:	e8 38 c0 fc ff       	call   0x1407999a0
   1407cd968:	48 83 c4 68          	add    $0x68,%rsp
   1407cd96c:	5d                   	pop    %rbp
   1407cd96d:	c3                   	ret
   1407cd96e:	b8 08 00 00 00       	mov    $0x8,%eax
   1407cd973:	48 8d 1d f6 fb ae 00 	lea    0xaefbf6(%rip),%rbx        # 0x1412bd570
   1407cd97a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cd97f:	90                   	nop
   1407cd980:	e8 fb 63 85 ff       	call   0x140023d80
   1407cd985:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407cd98a:	48 8b 92 b0 00 00 00 	mov    0xb0(%rdx),%rdx
   1407cd991:	48 89 10             	mov    %rdx,(%rax)
   1407cd994:	48 8b 15 ad d5 21 04 	mov    0x421d5ad(%rip),%rdx        # 0x1449eaf48
   1407cd99b:	48 8d 1d e3 39 0c 00 	lea    0xc39e3(%rip),%rbx        # 0x140891385
   1407cd9a2:	b9 0d 00 00 00       	mov    $0xd,%ecx
   1407cd9a7:	48 89 c7             	mov    %rax,%rdi
   1407cd9aa:	be 01 00 00 00       	mov    $0x1,%esi
   1407cd9af:	41 89 f0             	mov    %esi,%r8d
   1407cd9b2:	48 89 d0             	mov    %rdx,%rax
   1407cd9b5:	e8 e6 bf fc ff       	call   0x1407999a0
   1407cd9ba:	48 83 c4 68          	add    $0x68,%rsp
   1407cd9be:	5d                   	pop    %rbp
   1407cd9bf:	90                   	nop
   1407cd9c0:	c3                   	ret
   1407cd9c1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1407cd9c6:	e8 75 e9 8b ff       	call   0x14008c340
   1407cd9cb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1407cd9d0:	e9 2b f9 ff ff       	jmp    0x1407cd300
   1407cd9d5:	cc                   	int3
   1407cd9d6:	cc                   	int3
   1407cd9d7:	cc                   	int3
   1407cd9d8:	cc                   	int3
   1407cd9d9:	cc                   	int3
   1407cd9da:	cc                   	int3
   1407cd9db:	cc                   	int3
   1407cd9dc:	cc                   	int3
   1407cd9dd:	cc                   	int3
   1407cd9de:	cc                   	int3
   1407cd9df:	cc                   	int3

# main.toastText @ 0x1407cdf00
   1407cdf00:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407cdf04:	0f 86 aa 02 00 00    	jbe    0x1407ce1b4
   1407cdf0a:	55                   	push   %rbp
   1407cdf0b:	48 89 e5             	mov    %rsp,%rbp
   1407cdf0e:	48 83 ec 60          	sub    $0x60,%rsp
   1407cdf12:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   1407cdf19:	00 
   1407cdf1a:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
   1407cdf21:	00 
   1407cdf22:	44 89 8c 24 b0 00 00 	mov    %r9d,0xb0(%rsp)
   1407cdf29:	00 
   1407cdf2a:	4c 89 94 24 b8 00 00 	mov    %r10,0xb8(%rsp)
   1407cdf31:	00 
   1407cdf32:	4c 89 84 24 a8 00 00 	mov    %r8,0xa8(%rsp)
   1407cdf39:	00 
   1407cdf3a:	48 89 b4 24 a0 00 00 	mov    %rsi,0xa0(%rsp)
   1407cdf41:	00 
   1407cdf42:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
   1407cdf49:	00 
   1407cdf4a:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   1407cdf51:	00 
   1407cdf52:	b8 10 00 00 00       	mov    $0x10,%eax
   1407cdf57:	48 8d 1d 7a cb be 00 	lea    0xbecb7a(%rip),%rbx        # 0x1413baad8
   1407cdf5e:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cdf63:	e8 f8 60 85 ff       	call   0x140024060
   1407cdf68:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   1407cdf6d:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   1407cdf72:	0f 11 00             	movups %xmm0,(%rax)
   1407cdf75:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   1407cdf7c:	00 
   1407cdf7d:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cdf84:	00 
   1407cdf85:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   1407cdf8c:	00 
   1407cdf8d:	48 8b 9c 24 a8 00 00 	mov    0xa8(%rsp),%rbx
   1407cdf94:	00 
   1407cdf95:	e8 46 d1 ff ff       	call   0x1407cb0e0
   1407cdf9a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   1407cdf9f:	b8 10 00 00 00       	mov    $0x10,%eax
   1407cdfa4:	48 8d 1d 9d 08 af 00 	lea    0xaf089d(%rip),%rbx        # 0x1412be848
   1407cdfab:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407cdfb0:	e8 ab 60 85 ff       	call   0x140024060
   1407cdfb5:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407cdfbc:	00 
   1407cdfbd:	48 89 10             	mov    %rdx,(%rax)
   1407cdfc0:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407cdfc5:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407cdfc9:	48 8b 15 88 cf 21 04 	mov    0x421cf88(%rip),%rdx        # 0x1449eaf58
   1407cdfd0:	48 8d 1d c0 17 0c 00 	lea    0xc17c0(%rip),%rbx        # 0x14088f797
   1407cdfd7:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407cdfdc:	48 89 c7             	mov    %rax,%rdi
   1407cdfdf:	be 02 00 00 00       	mov    $0x2,%esi
   1407cdfe4:	41 89 f0             	mov    %esi,%r8d
   1407cdfe7:	48 89 d0             	mov    %rdx,%rax
   1407cdfea:	e8 b1 b9 fc ff       	call   0x1407999a0
   1407cdfef:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   1407cdff4:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   1407cdffb:	00 
   1407cdffc:	48 81 ca 00 88 00 00 	or     $0x8800,%rdx
   1407ce003:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   1407ce008:	8b 94 24 b0 00 00 00 	mov    0xb0(%rsp),%edx
   1407ce00f:	89 d6                	mov    %edx,%esi
   1407ce011:	c1 ea 10             	shr    $0x10,%edx
   1407ce014:	0f b6 d2             	movzbl %dl,%edx
   1407ce017:	89 f7                	mov    %esi,%edi
   1407ce019:	81 e6 00 ff 00 00    	and    $0xff00,%esi
   1407ce01f:	09 d6                	or     %edx,%esi
   1407ce021:	40 0f b6 d7          	movzbl %dil,%edx
   1407ce025:	c1 e2 10             	shl    $0x10,%edx
   1407ce028:	09 f2                	or     %esi,%edx
   1407ce02a:	89 54 24 34          	mov    %edx,0x34(%rsp)
   1407ce02e:	b8 10 00 00 00       	mov    $0x10,%eax
   1407ce033:	48 8d 1d 0e 08 af 00 	lea    0xaf080e(%rip),%rbx        # 0x1412be848
   1407ce03a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce03f:	90                   	nop
   1407ce040:	e8 1b 60 85 ff       	call   0x140024060
   1407ce045:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407ce04c:	00 
   1407ce04d:	48 89 10             	mov    %rdx,(%rax)
   1407ce050:	8b 54 24 34          	mov    0x34(%rsp),%edx
   1407ce054:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407ce058:	48 8b 15 f9 ce 21 04 	mov    0x421cef9(%rip),%rdx        # 0x1449eaf58
   1407ce05f:	48 8d 1d 3d 17 0c 00 	lea    0xc173d(%rip),%rbx        # 0x14088f7a3
   1407ce066:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407ce06b:	48 89 c7             	mov    %rax,%rdi
   1407ce06e:	be 02 00 00 00       	mov    $0x2,%esi
   1407ce073:	41 89 f0             	mov    %esi,%r8d
   1407ce076:	48 89 d0             	mov    %rdx,%rax
   1407ce079:	e8 22 b9 fc ff       	call   0x1407999a0
   1407ce07e:	b8 10 00 00 00       	mov    $0x10,%eax
   1407ce083:	48 8d 1d be 07 af 00 	lea    0xaf07be(%rip),%rbx        # 0x1412be848
   1407ce08a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce08f:	e8 cc 5f 85 ff       	call   0x140024060
   1407ce094:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407ce09b:	00 
   1407ce09c:	48 89 10             	mov    %rdx,(%rax)
   1407ce09f:	48 c7 40 08 01 00 00 	movq   $0x1,0x8(%rax)
   1407ce0a6:	00 
   1407ce0a7:	48 8b 15 aa ce 21 04 	mov    0x421ceaa(%rip),%rdx        # 0x1449eaf58
   1407ce0ae:	48 8d 1d e0 ca 0b 00 	lea    0xbcae0(%rip),%rbx        # 0x14088ab95
   1407ce0b5:	b9 09 00 00 00       	mov    $0x9,%ecx
   1407ce0ba:	48 89 c7             	mov    %rax,%rdi
   1407ce0bd:	be 02 00 00 00       	mov    $0x2,%esi
   1407ce0c2:	41 89 f0             	mov    %esi,%r8d
   1407ce0c5:	48 89 d0             	mov    %rdx,%rax
   1407ce0c8:	e8 d3 b8 fc ff       	call   0x1407999a0
   1407ce0cd:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   1407ce0d4:	00 
   1407ce0d5:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
   1407ce0dc:	00 
   1407ce0dd:	0f 1f 00             	nopl   (%rax)
   1407ce0e0:	e8 3b b8 fc ff       	call   0x140799920
   1407ce0e5:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   1407ce0ea:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   1407ce0ef:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   1407ce0f4:	b8 28 00 00 00       	mov    $0x28,%eax
   1407ce0f9:	48 8d 1d c8 1d af 00 	lea    0xaf1dc8(%rip),%rbx        # 0x1412bfec8
   1407ce100:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce105:	e8 76 66 85 ff       	call   0x140024780
   1407ce10a:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407ce111:	00 
   1407ce112:	48 89 10             	mov    %rdx,(%rax)
   1407ce115:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   1407ce11a:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407ce11e:	48 c7 40 10 ff ff ff 	movq   $0xffffffffffffffff,0x10(%rax)
   1407ce125:	ff 
   1407ce126:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407ce12b:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407ce12f:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407ce134:	48 89 50 20          	mov    %rdx,0x20(%rax)
   1407ce138:	48 8b 15 09 ce 21 04 	mov    0x421ce09(%rip),%rdx        # 0x1449eaf48
   1407ce13f:	48 8d 1d 58 ca 0b 00 	lea    0xbca58(%rip),%rbx        # 0x14088ab9e
   1407ce146:	b9 09 00 00 00       	mov    $0x9,%ecx
   1407ce14b:	48 89 c7             	mov    %rax,%rdi
   1407ce14e:	be 05 00 00 00       	mov    $0x5,%esi
   1407ce153:	41 89 f0             	mov    %esi,%r8d
   1407ce156:	48 89 d0             	mov    %rdx,%rax
   1407ce159:	e8 42 b8 fc ff       	call   0x1407999a0
   1407ce15e:	b8 10 00 00 00       	mov    $0x10,%eax
   1407ce163:	48 8d 1d de 06 af 00 	lea    0xaf06de(%rip),%rbx        # 0x1412be848
   1407ce16a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce16f:	e8 ec 5e 85 ff       	call   0x140024060
   1407ce174:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407ce17b:	00 
   1407ce17c:	48 89 10             	mov    %rdx,(%rax)
   1407ce17f:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   1407ce184:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407ce188:	48 8b 15 c9 cd 21 04 	mov    0x421cdc9(%rip),%rdx        # 0x1449eaf58
   1407ce18f:	48 8d 1d 01 16 0c 00 	lea    0xc1601(%rip),%rbx        # 0x14088f797
   1407ce196:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407ce19b:	48 89 c7             	mov    %rax,%rdi
   1407ce19e:	be 02 00 00 00       	mov    $0x2,%esi
   1407ce1a3:	41 89 f0             	mov    %esi,%r8d
   1407ce1a6:	48 89 d0             	mov    %rdx,%rax
   1407ce1a9:	e8 f2 b7 fc ff       	call   0x1407999a0
   1407ce1ae:	48 83 c4 60          	add    $0x60,%rsp
   1407ce1b2:	5d                   	pop    %rbp
   1407ce1b3:	c3                   	ret
   1407ce1b4:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   1407ce1b9:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   1407ce1be:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   1407ce1c3:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   1407ce1c8:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
   1407ce1cd:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
   1407ce1d2:	44 89 4c 24 48       	mov    %r9d,0x48(%rsp)
   1407ce1d7:	4c 89 54 24 50       	mov    %r10,0x50(%rsp)
   1407ce1dc:	0f 1f 40 00          	nopl   0x0(%rax)
   1407ce1e0:	e8 5b e1 8b ff       	call   0x14008c340
   1407ce1e5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1407ce1ea:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   1407ce1ef:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   1407ce1f4:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   1407ce1f9:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
   1407ce1fe:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
   1407ce203:	44 8b 4c 24 48       	mov    0x48(%rsp),%r9d
   1407ce208:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
   1407ce20d:	e9 ee fc ff ff       	jmp    0x1407cdf00
   1407ce212:	cc                   	int3
   1407ce213:	cc                   	int3
   1407ce214:	cc                   	int3
   1407ce215:	cc                   	int3
   1407ce216:	cc                   	int3
   1407ce217:	cc                   	int3
   1407ce218:	cc                   	int3
   1407ce219:	cc                   	int3
   1407ce21a:	cc                   	int3
   1407ce21b:	cc                   	int3
   1407ce21c:	cc                   	int3
   1407ce21d:	cc                   	int3
   1407ce21e:	cc                   	int3
   1407ce21f:	cc                   	int3

# main.paintToast @ 0x1407ce4e0
   1407ce4e0:	4c 8d a4 24 30 fe ff 	lea    -0x1d0(%rsp),%r12
   1407ce4e7:	ff 
   1407ce4e8:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407ce4ec:	0f 86 dc 23 00 00    	jbe    0x1407d08ce
   1407ce4f2:	55                   	push   %rbp
   1407ce4f3:	48 89 e5             	mov    %rsp,%rbp
   1407ce4f6:	48 81 ec 48 02 00 00 	sub    $0x248,%rsp
   1407ce4fd:	66 44 0f d6 bc 24 40 	movq   %xmm15,0x240(%rsp)
   1407ce504:	02 00 00 
   1407ce507:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
   1407ce50e:	00 
   1407ce50f:	c6 84 24 af 00 00 00 	movb   $0x0,0xaf(%rsp)
   1407ce516:	00 
   1407ce517:	b8 48 00 00 00       	mov    $0x48,%eax
   1407ce51c:	48 8d 1d 95 71 c0 00 	lea    0xc07195(%rip),%rbx        # 0x1413d56b8
   1407ce523:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce528:	e8 13 67 85 ff       	call   0x140024c40
   1407ce52d:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
   1407ce534:	00 
   1407ce535:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
   1407ce53c:	00 
   1407ce53d:	b8 10 00 00 00       	mov    $0x10,%eax
   1407ce542:	48 8d 1d ff 02 af 00 	lea    0xaf02ff(%rip),%rbx        # 0x1412be848
   1407ce549:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce54e:	e8 0d 5b 85 ff       	call   0x140024060
   1407ce553:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407ce55a:	00 
   1407ce55b:	48 8b 92 b0 00 00 00 	mov    0xb0(%rdx),%rdx
   1407ce562:	48 89 10             	mov    %rdx,(%rax)
   1407ce565:	48 8b 94 24 30 02 00 	mov    0x230(%rsp),%rdx
   1407ce56c:	00 
   1407ce56d:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407ce571:	48 8b 15 d0 c9 21 04 	mov    0x421c9d0(%rip),%rdx        # 0x1449eaf48
   1407ce578:	48 8d 1d 25 e2 0b 00 	lea    0xbe225(%rip),%rbx        # 0x14088c7a4
   1407ce57f:	b9 0a 00 00 00       	mov    $0xa,%ecx
   1407ce584:	48 89 c7             	mov    %rax,%rdi
   1407ce587:	be 02 00 00 00       	mov    $0x2,%esi
   1407ce58c:	41 89 f0             	mov    %esi,%r8d
   1407ce58f:	48 89 d0             	mov    %rdx,%rax
   1407ce592:	e8 09 b4 fc ff       	call   0x1407999a0
   1407ce597:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1407ce59e:	00 00 
   1407ce5a0:	48 85 c0             	test   %rax,%rax
   1407ce5a3:	0f 84 0c 23 00 00    	je     0x1407d08b5
   1407ce5a9:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   1407ce5b0:	00 
   1407ce5b1:	48 8b 15 90 c9 21 04 	mov    0x421c990(%rip),%rdx        # 0x1449eaf48
   1407ce5b8:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407ce5bf:	00 
   1407ce5c0:	48 8b b6 b0 00 00 00 	mov    0xb0(%rsi),%rsi
   1407ce5c7:	48 8d 3d 52 f1 02 00 	lea    0x2f152(%rip),%rdi        # 0x1407fd720
   1407ce5ce:	48 89 bc 24 10 02 00 	mov    %rdi,0x210(%rsp)
   1407ce5d5:	00 
   1407ce5d6:	48 89 94 24 18 02 00 	mov    %rdx,0x218(%rsp)
   1407ce5dd:	00 
   1407ce5de:	48 89 b4 24 20 02 00 	mov    %rsi,0x220(%rsp)
   1407ce5e5:	00 
   1407ce5e6:	48 8b 94 24 38 02 00 	mov    0x238(%rsp),%rdx
   1407ce5ed:	00 
   1407ce5ee:	48 89 94 24 28 02 00 	mov    %rdx,0x228(%rsp)
   1407ce5f5:	00 
   1407ce5f6:	48 8d 94 24 10 02 00 	lea    0x210(%rsp),%rdx
   1407ce5fd:	00 
   1407ce5fe:	48 89 94 24 40 02 00 	mov    %rdx,0x240(%rsp)
   1407ce605:	00 
   1407ce606:	c6 84 24 af 00 00 00 	movb   $0x1,0xaf(%rsp)
   1407ce60d:	01 
   1407ce60e:	b8 08 00 00 00       	mov    $0x8,%eax
   1407ce613:	48 8d 1d 56 ef ae 00 	lea    0xaeef56(%rip),%rbx        # 0x1412bd570
   1407ce61a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce61f:	90                   	nop
   1407ce620:	e8 5b 57 85 ff       	call   0x140023d80
   1407ce625:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
   1407ce62c:	00 
   1407ce62d:	48 89 10             	mov    %rdx,(%rax)
   1407ce630:	48 8b 15 21 c9 21 04 	mov    0x421c921(%rip),%rdx        # 0x1449eaf58
   1407ce637:	48 8d 1d 59 a7 0c 00 	lea    0xca759(%rip),%rbx        # 0x140898d97
   1407ce63e:	b9 12 00 00 00       	mov    $0x12,%ecx
   1407ce643:	48 89 c7             	mov    %rax,%rdi
   1407ce646:	be 01 00 00 00       	mov    $0x1,%esi
   1407ce64b:	41 89 f0             	mov    %esi,%r8d
   1407ce64e:	48 89 d0             	mov    %rdx,%rax
   1407ce651:	e8 4a b3 fc ff       	call   0x1407999a0
   1407ce656:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   1407ce65d:	00 
   1407ce65e:	b8 18 00 00 00       	mov    $0x18,%eax
   1407ce663:	48 8d 1d be 09 af 00 	lea    0xaf09be(%rip),%rbx        # 0x1412bf028
   1407ce66a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce66f:	e8 4c 5c 85 ff       	call   0x1400242c0
   1407ce674:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
   1407ce67b:	00 
   1407ce67c:	48 89 10             	mov    %rdx,(%rax)
   1407ce67f:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407ce686:	00 
   1407ce687:	48 63 b2 c0 00 00 00 	movslq 0xc0(%rdx),%rsi
   1407ce68e:	48 89 70 08          	mov    %rsi,0x8(%rax)
   1407ce692:	48 63 92 c4 00 00 00 	movslq 0xc4(%rdx),%rdx
   1407ce699:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407ce69d:	48 8b 15 b4 c8 21 04 	mov    0x421c8b4(%rip),%rdx        # 0x1449eaf58
   1407ce6a4:	48 8d 1d 9a 14 0d 00 	lea    0xd149a(%rip),%rbx        # 0x14089fb45
   1407ce6ab:	b9 16 00 00 00       	mov    $0x16,%ecx
   1407ce6b0:	48 89 c7             	mov    %rax,%rdi
   1407ce6b3:	be 03 00 00 00       	mov    $0x3,%esi
   1407ce6b8:	41 89 f0             	mov    %esi,%r8d
   1407ce6bb:	48 89 d0             	mov    %rdx,%rax
   1407ce6be:	66 90                	xchg   %ax,%ax
   1407ce6c0:	e8 db b2 fc ff       	call   0x1407999a0
   1407ce6c5:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   1407ce6cc:	00 
   1407ce6cd:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407ce6d4:	00 
   1407ce6d5:	48 85 d2             	test   %rdx,%rdx
   1407ce6d8:	74 66                	je     0x1407ce740
   1407ce6da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407ce6e0:	48 85 c0             	test   %rax,%rax
   1407ce6e3:	0f 85 c2 00 00 00    	jne    0x1407ce7ab
   1407ce6e9:	48 85 d2             	test   %rdx,%rdx
   1407ce6ec:	74 52                	je     0x1407ce740
   1407ce6ee:	b8 08 00 00 00       	mov    $0x8,%eax
   1407ce6f3:	48 8d 1d 76 ee ae 00 	lea    0xaeee76(%rip),%rbx        # 0x1412bd570
   1407ce6fa:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce6ff:	90                   	nop
   1407ce700:	e8 7b 56 85 ff       	call   0x140023d80
   1407ce705:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407ce70c:	00 
   1407ce70d:	48 89 10             	mov    %rdx,(%rax)
   1407ce710:	48 8b 15 41 c8 21 04 	mov    0x421c841(%rip),%rdx        # 0x1449eaf58
   1407ce717:	48 8d 1d 6a a6 0b 00 	lea    0xba66a(%rip),%rbx        # 0x140888d88
   1407ce71e:	b9 08 00 00 00       	mov    $0x8,%ecx
   1407ce723:	48 89 c7             	mov    %rax,%rdi
   1407ce726:	be 01 00 00 00       	mov    $0x1,%esi
   1407ce72b:	41 89 f0             	mov    %esi,%r8d
   1407ce72e:	48 89 d0             	mov    %rdx,%rax
   1407ce731:	e8 6a b2 fc ff       	call   0x1407999a0
   1407ce736:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   1407ce73d:	00 
   1407ce73e:	66 90                	xchg   %ax,%ax
   1407ce740:	48 85 c0             	test   %rax,%rax
   1407ce743:	74 47                	je     0x1407ce78c
   1407ce745:	b8 08 00 00 00       	mov    $0x8,%eax
   1407ce74a:	48 8d 1d 1f ee ae 00 	lea    0xaeee1f(%rip),%rbx        # 0x1412bd570
   1407ce751:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce756:	e8 25 56 85 ff       	call   0x140023d80
   1407ce75b:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
   1407ce762:	00 
   1407ce763:	48 89 10             	mov    %rdx,(%rax)
   1407ce766:	48 8b 15 eb c7 21 04 	mov    0x421c7eb(%rip),%rdx        # 0x1449eaf58
   1407ce76d:	48 8d 1d 17 10 0c 00 	lea    0xc1017(%rip),%rbx        # 0x14088f78b
   1407ce774:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407ce779:	48 89 c7             	mov    %rax,%rdi
   1407ce77c:	be 01 00 00 00       	mov    $0x1,%esi
   1407ce781:	41 89 f0             	mov    %esi,%r8d
   1407ce784:	48 89 d0             	mov    %rdx,%rax
   1407ce787:	e8 14 b2 fc ff       	call   0x1407999a0
   1407ce78c:	c6 84 24 af 00 00 00 	movb   $0x0,0xaf(%rsp)
   1407ce793:	00 
   1407ce794:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   1407ce79b:	00 
   1407ce79c:	48 8b 02             	mov    (%rdx),%rax
   1407ce79f:	90                   	nop
   1407ce7a0:	ff d0                	call   *%rax
   1407ce7a2:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
   1407ce7a9:	5d                   	pop    %rbp
   1407ce7aa:	c3                   	ret
   1407ce7ab:	b8 10 00 00 00       	mov    $0x10,%eax
   1407ce7b0:	48 8d 1d 91 00 af 00 	lea    0xaf0091(%rip),%rbx        # 0x1412be848
   1407ce7b7:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407ce7bc:	0f 1f 40 00          	nopl   0x0(%rax)
   1407ce7c0:	e8 9b 58 85 ff       	call   0x140024060
   1407ce7c5:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407ce7cc:	00 
   1407ce7cd:	48 89 10             	mov    %rdx,(%rax)
   1407ce7d0:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
   1407ce7d7:	00 
   1407ce7d8:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407ce7dc:	48 8b 15 75 c7 21 04 	mov    0x421c775(%rip),%rdx        # 0x1449eaf58
   1407ce7e3:	48 8d 1d ad 0f 0c 00 	lea    0xc0fad(%rip),%rbx        # 0x14088f797
   1407ce7ea:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407ce7ef:	48 89 c7             	mov    %rax,%rdi
   1407ce7f2:	be 02 00 00 00       	mov    $0x2,%esi
   1407ce7f7:	41 89 f0             	mov    %esi,%r8d
   1407ce7fa:	48 89 d0             	mov    %rdx,%rax
   1407ce7fd:	0f 1f 00             	nopl   (%rax)
   1407ce800:	e8 9b b1 fc ff       	call   0x1407999a0
   1407ce805:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   1407ce80c:	00 
   1407ce80d:	48 8d 15 6c ec 02 00 	lea    0x2ec6c(%rip),%rdx        # 0x1407fd480
   1407ce814:	48 89 94 24 00 02 00 	mov    %rdx,0x200(%rsp)
   1407ce81b:	00 
   1407ce81c:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407ce823:	00 
   1407ce824:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
   1407ce82b:	00 
   1407ce82c:	8b ba c0 00 00 00    	mov    0xc0(%rdx),%edi
   1407ce832:	8b b2 c4 00 00 00    	mov    0xc4(%rdx),%esi
   1407ce838:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407ce83f:	00 
   1407ce840:	31 db                	xor    %ebx,%ebx
   1407ce842:	89 d9                	mov    %ebx,%ecx
   1407ce844:	41 b8 ed d2 bf 00    	mov    $0xbfd2ed,%r8d
   1407ce84a:	e8 91 f1 ff ff       	call   0x1407cd9e0
   1407ce84f:	f2 0f 10 05 a9 75 40 	movsd  0x4075a9(%rip),%xmm0        # 0x140bd5e00
   1407ce856:	00 
   1407ce857:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407ce85e:	00 
   1407ce85f:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407ce866:	00 
   1407ce867:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407ce86c:	48 89 ce             	mov    %rcx,%rsi
   1407ce86f:	48 c1 ee 34          	shr    $0x34,%rsi
   1407ce873:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407ce879:	90                   	nop
   1407ce87a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407ce880:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407ce887:	73 2a                	jae    0x1407ce8b3
   1407ce889:	49 ba 00 00 00 00 00 	movabs $0x8000000000000000,%r10
   1407ce890:	00 00 80 
   1407ce893:	49 21 ca             	and    %rcx,%r10
   1407ce896:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407ce89d:	00 f0 3f 
   1407ce8a0:	4d 09 d3             	or     %r10,%r11
   1407ce8a3:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407ce8aa:	4d 0f 44 d3          	cmove  %r11,%r10
   1407ce8ae:	4d 89 d3             	mov    %r10,%r11
   1407ce8b1:	eb 3e                	jmp    0x1407ce8f1
   1407ce8b3:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407ce8ba:	73 32                	jae    0x1407ce8ee
   1407ce8bc:	4c 8d 96 01 fc ff ff 	lea    -0x3ff(%rsi),%r10
   1407ce8c3:	48 89 c8             	mov    %rcx,%rax
   1407ce8c6:	4c 89 d1             	mov    %r10,%rcx
   1407ce8c9:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407ce8d0:	00 08 00 
   1407ce8d3:	49 d3 eb             	shr    %cl,%r11
   1407ce8d6:	49 01 c3             	add    %rax,%r11
   1407ce8d9:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407ce8e0:	ff 0f 00 
   1407ce8e3:	49 d3 ec             	shr    %cl,%r12
   1407ce8e6:	49 f7 d4             	not    %r12
   1407ce8e9:	4d 21 e3             	and    %r12,%r11
   1407ce8ec:	eb 03                	jmp    0x1407ce8f1
   1407ce8ee:	49 89 cb             	mov    %rcx,%r11
   1407ce8f1:	8b ba c0 00 00 00    	mov    0xc0(%rdx),%edi
   1407ce8f7:	ff cf                	dec    %edi
   1407ce8f9:	8b b2 c4 00 00 00    	mov    0xc4(%rdx),%esi
   1407ce8ff:	ff ce                	dec    %esi
   1407ce901:	66 49 0f 6e c3       	movq   %r11,%xmm0
   1407ce906:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407ce90b:	90                   	nop
   1407ce90c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407ce913:	00 
   1407ce914:	bb 01 00 00 00       	mov    $0x1,%ebx
   1407ce919:	89 d9                	mov    %ebx,%ecx
   1407ce91b:	41 b9 ff ff ff 00    	mov    $0xffffff,%r9d
   1407ce921:	e8 7a f2 ff ff       	call   0x1407cdba0
   1407ce926:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
   1407ce92d:	00 
   1407ce92e:	b8 14 00 00 00       	mov    $0x14,%eax
   1407ce933:	bb 12 00 00 00       	mov    $0x12,%ebx
   1407ce938:	b9 24 00 00 00       	mov    $0x24,%ecx
   1407ce93d:	89 cf                	mov    %ecx,%edi
   1407ce93f:	48 89 d6             	mov    %rdx,%rsi
   1407ce942:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407ce949:	00 
   1407ce94a:	ff d6                	call   *%rsi
   1407ce94c:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407ce953:	00 
   1407ce954:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407ce95b:	00 
   1407ce95c:	f2 0f 10 0d 84 74 40 	movsd  0x407484(%rip),%xmm1        # 0x140bd5de8
   1407ce963:	00 
   1407ce964:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407ce968:	66 49 0f 7e ca       	movq   %xmm1,%r10
   1407ce96d:	4d 89 d3             	mov    %r10,%r11
   1407ce970:	49 c1 ea 34          	shr    $0x34,%r10
   1407ce974:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407ce97b:	90                   	nop
   1407ce97c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407ce980:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ce987:	73 2c                	jae    0x1407ce9b5
   1407ce989:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407ce990:	00 00 80 
   1407ce993:	4d 21 e3             	and    %r12,%r11
   1407ce996:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407ce99d:	00 f0 3f 
   1407ce9a0:	4d 09 dc             	or     %r11,%r12
   1407ce9a3:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407ce9aa:	4d 0f 44 dc          	cmove  %r12,%r11
   1407ce9ae:	89 ce                	mov    %ecx,%esi
   1407ce9b0:	4d 89 da             	mov    %r11,%r10
   1407ce9b3:	eb 40                	jmp    0x1407ce9f5
   1407ce9b5:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407ce9bc:	73 32                	jae    0x1407ce9f0
   1407ce9be:	4d 8d a2 01 fc ff ff 	lea    -0x3ff(%r10),%r12
   1407ce9c5:	89 ce                	mov    %ecx,%esi
   1407ce9c7:	4c 89 e1             	mov    %r12,%rcx
   1407ce9ca:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407ce9d1:	00 08 00 
   1407ce9d4:	49 d3 ed             	shr    %cl,%r13
   1407ce9d7:	4f 8d 14 2b          	lea    (%r11,%r13,1),%r10
   1407ce9db:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407ce9e2:	ff 0f 00 
   1407ce9e5:	49 d3 eb             	shr    %cl,%r11
   1407ce9e8:	49 f7 d3             	not    %r11
   1407ce9eb:	4d 21 da             	and    %r11,%r10
   1407ce9ee:	eb 05                	jmp    0x1407ce9f5
   1407ce9f0:	89 ce                	mov    %ecx,%esi
   1407ce9f2:	4d 89 da             	mov    %r11,%r10
   1407ce9f5:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407ce9fa:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407ce9ff:	90                   	nop
   1407cea00:	89 d9                	mov    %ebx,%ecx
   1407cea02:	41 b9 eb 63 25 00    	mov    $0x2563eb,%r9d
   1407cea08:	89 c3                	mov    %eax,%ebx
   1407cea0a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cea11:	00 
   1407cea12:	89 fa                	mov    %edi,%edx
   1407cea14:	89 f7                	mov    %esi,%edi
   1407cea16:	89 d6                	mov    %edx,%esi
   1407cea18:	e8 83 f1 ff ff       	call   0x1407cdba0
   1407cea1d:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407cea24:	00 
   1407cea25:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cea2c:	00 
   1407cea2d:	f2 0f 10 0d f3 73 40 	movsd  0x4073f3(%rip),%xmm1        # 0x140bd5e28
   1407cea34:	00 
   1407cea35:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cea39:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cea3e:	49 89 ca             	mov    %rcx,%r10
   1407cea41:	49 c1 ea 34          	shr    $0x34,%r10
   1407cea45:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cea4c:	90                   	nop
   1407cea4d:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cea54:	73 2c                	jae    0x1407cea82
   1407cea56:	49 bb 00 00 00 00 00 	movabs $0x8000000000000000,%r11
   1407cea5d:	00 00 80 
   1407cea60:	4c 21 d9             	and    %r11,%rcx
   1407cea63:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cea6a:	00 f0 3f 
   1407cea6d:	49 09 cc             	or     %rcx,%r12
   1407cea70:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cea77:	49 0f 44 cc          	cmove  %r12,%rcx
   1407cea7b:	49 89 cb             	mov    %rcx,%r11
   1407cea7e:	66 90                	xchg   %ax,%ax
   1407cea80:	eb 3e                	jmp    0x1407ceac0
   1407cea82:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cea89:	73 32                	jae    0x1407ceabd
   1407cea8b:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cea92:	48 89 c8             	mov    %rcx,%rax
   1407cea95:	4c 89 d1             	mov    %r10,%rcx
   1407cea98:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407cea9f:	00 08 00 
   1407ceaa2:	49 d3 eb             	shr    %cl,%r11
   1407ceaa5:	49 01 c3             	add    %rax,%r11
   1407ceaa8:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407ceaaf:	ff 0f 00 
   1407ceab2:	49 d3 ec             	shr    %cl,%r12
   1407ceab5:	49 f7 d4             	not    %r12
   1407ceab8:	4d 21 e3             	and    %r12,%r11
   1407ceabb:	eb 03                	jmp    0x1407ceac0
   1407ceabd:	49 89 cb             	mov    %rcx,%r11
   1407ceac0:	f2 0f 10 0d 70 73 40 	movsd  0x407370(%rip),%xmm1        # 0x140bd5e38
   1407ceac7:	00 
   1407ceac8:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407ceacc:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cead1:	49 89 ca             	mov    %rcx,%r10
   1407cead4:	49 c1 ea 34          	shr    $0x34,%r10
   1407cead8:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407ceadf:	90                   	nop
   1407ceae0:	90                   	nop
   1407ceae1:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ceae8:	73 36                	jae    0x1407ceb20
   1407ceaea:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407ceaf1:	00 00 80 
   1407ceaf4:	49 21 cc             	and    %rcx,%r12
   1407ceaf7:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407ceafe:	00 f0 3f 
   1407ceb01:	4d 09 e5             	or     %r12,%r13
   1407ceb04:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407ceb0b:	4d 0f 44 e5          	cmove  %r13,%r12
   1407ceb0f:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ceb16:	48 89 c8             	mov    %rcx,%rax
   1407ceb19:	4d 89 e5             	mov    %r12,%r13
   1407ceb1c:	eb 51                	jmp    0x1407ceb6f
   1407ceb1e:	66 90                	xchg   %ax,%ax
   1407ceb20:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407ceb27:	73 39                	jae    0x1407ceb62
   1407ceb29:	4d 8d a2 01 fc ff ff 	lea    -0x3ff(%r10),%r12
   1407ceb30:	48 89 c8             	mov    %rcx,%rax
   1407ceb33:	4c 89 e1             	mov    %r12,%rcx
   1407ceb36:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407ceb3d:	00 08 00 
   1407ceb40:	49 d3 ed             	shr    %cl,%r13
   1407ceb43:	49 01 c5             	add    %rax,%r13
   1407ceb46:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407ceb4d:	ff 0f 00 
   1407ceb50:	49 d3 ef             	shr    %cl,%r15
   1407ceb53:	49 f7 d7             	not    %r15
   1407ceb56:	4d 21 fd             	and    %r15,%r13
   1407ceb59:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ceb60:	eb 0d                	jmp    0x1407ceb6f
   1407ceb62:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ceb69:	48 89 c8             	mov    %rcx,%rax
   1407ceb6c:	49 89 c5             	mov    %rax,%r13
   1407ceb6f:	90                   	nop
   1407ceb70:	73 2e                	jae    0x1407ceba0
   1407ceb72:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407ceb79:	00 00 80 
   1407ceb7c:	4c 21 e0             	and    %r12,%rax
   1407ceb7f:	49 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%r15
   1407ceb86:	00 f0 3f 
   1407ceb89:	49 09 c7             	or     %rax,%r15
   1407ceb8c:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407ceb93:	49 0f 44 c7          	cmove  %r15,%rax
   1407ceb97:	49 89 c2             	mov    %rax,%r10
   1407ceb9a:	eb 3c                	jmp    0x1407cebd8
   1407ceb9c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407ceba0:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407ceba7:	73 2c                	jae    0x1407cebd5
   1407ceba9:	49 8d 8a 01 fc ff ff 	lea    -0x3ff(%r10),%rcx
   1407cebb0:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407cebb7:	00 08 00 
   1407cebba:	49 d3 ea             	shr    %cl,%r10
   1407cebbd:	49 01 c2             	add    %rax,%r10
   1407cebc0:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407cebc7:	ff 0f 00 
   1407cebca:	49 d3 ec             	shr    %cl,%r12
   1407cebcd:	49 f7 d4             	not    %r12
   1407cebd0:	4d 21 e2             	and    %r12,%r10
   1407cebd3:	eb 03                	jmp    0x1407cebd8
   1407cebd5:	49 89 c2             	mov    %rax,%r10
   1407cebd8:	f2 0f 10 0d 70 72 40 	movsd  0x407270(%rip),%xmm1        # 0x140bd5e50
   1407cebdf:	00 
   1407cebe0:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cebe4:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cebe9:	49 89 cc             	mov    %rcx,%r12
   1407cebec:	49 c1 ec 34          	shr    $0x34,%r12
   1407cebf0:	41 81 e4 ff 07 00 00 	and    $0x7ff,%r12d
   1407cebf7:	90                   	nop
   1407cebf8:	90                   	nop
   1407cebf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407cec00:	49 81 fc ff 03 00 00 	cmp    $0x3ff,%r12
   1407cec07:	73 2d                	jae    0x1407cec36
   1407cec09:	49 bf 00 00 00 00 00 	movabs $0x8000000000000000,%r15
   1407cec10:	00 00 80 
   1407cec13:	4c 21 f9             	and    %r15,%rcx
   1407cec16:	48 89 d0             	mov    %rdx,%rax
   1407cec19:	48 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdx
   1407cec20:	00 f0 3f 
   1407cec23:	48 09 ca             	or     %rcx,%rdx
   1407cec26:	49 81 fc fe 03 00 00 	cmp    $0x3fe,%r12
   1407cec2d:	48 0f 44 ca          	cmove  %rdx,%rcx
   1407cec31:	49 89 cf             	mov    %rcx,%r15
   1407cec34:	eb 44                	jmp    0x1407cec7a
   1407cec36:	49 81 fc 33 04 00 00 	cmp    $0x433,%r12
   1407cec3d:	73 35                	jae    0x1407cec74
   1407cec3f:	49 81 c4 01 fc ff ff 	add    $0xfffffffffffffc01,%r12
   1407cec46:	48 89 c8             	mov    %rcx,%rax
   1407cec49:	4c 89 e1             	mov    %r12,%rcx
   1407cec4c:	49 bf 00 00 00 00 00 	movabs $0x8000000000000,%r15
   1407cec53:	00 08 00 
   1407cec56:	49 d3 ef             	shr    %cl,%r15
   1407cec59:	49 01 c7             	add    %rax,%r15
   1407cec5c:	48 89 d0             	mov    %rdx,%rax
   1407cec5f:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
   1407cec66:	ff 0f 00 
   1407cec69:	48 d3 ea             	shr    %cl,%rdx
   1407cec6c:	48 f7 d2             	not    %rdx
   1407cec6f:	49 21 d7             	and    %rdx,%r15
   1407cec72:	eb 06                	jmp    0x1407cec7a
   1407cec74:	48 89 d0             	mov    %rdx,%rax
   1407cec77:	49 89 cf             	mov    %rcx,%r15
   1407cec7a:	f2 0f 10 0d 5e 71 40 	movsd  0x40715e(%rip),%xmm1        # 0x140bd5de0
   1407cec81:	00 
   1407cec82:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cec86:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cec8b:	48 89 ca             	mov    %rcx,%rdx
   1407cec8e:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cec92:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cec98:	90                   	nop
   1407cec99:	90                   	nop
   1407cec9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407ceca0:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407ceca7:	73 2d                	jae    0x1407cecd6
   1407ceca9:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407cecb0:	00 00 80 
   1407cecb3:	4c 21 e1             	and    %r12,%rcx
   1407cecb6:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cecbd:	00 f0 3f 
   1407cecc0:	49 09 cc             	or     %rcx,%r12
   1407cecc3:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cecca:	49 0f 44 cc          	cmove  %r12,%rcx
   1407cecce:	4c 89 fb             	mov    %r15,%rbx
   1407cecd1:	49 89 cc             	mov    %rcx,%r12
   1407cecd4:	eb 44                	jmp    0x1407ced1a
   1407cecd6:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cecdd:	73 35                	jae    0x1407ced14
   1407cecdf:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cece6:	48 89 cb             	mov    %rcx,%rbx
   1407cece9:	48 89 d1             	mov    %rdx,%rcx
   1407cecec:	49 bc 00 00 00 00 00 	movabs $0x8000000000000,%r12
   1407cecf3:	00 08 00 
   1407cecf6:	49 d3 ec             	shr    %cl,%r12
   1407cecf9:	49 01 dc             	add    %rbx,%r12
   1407cecfc:	4c 89 fb             	mov    %r15,%rbx
   1407cecff:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407ced06:	ff 0f 00 
   1407ced09:	49 d3 ef             	shr    %cl,%r15
   1407ced0c:	49 f7 d7             	not    %r15
   1407ced0f:	4d 21 fc             	and    %r15,%r12
   1407ced12:	eb 06                	jmp    0x1407ced1a
   1407ced14:	4c 89 fb             	mov    %r15,%rbx
   1407ced17:	49 89 cc             	mov    %rcx,%r12
   1407ced1a:	66 49 0f 6e c3       	movq   %r11,%xmm0
   1407ced1f:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407ced23:	66 49 0f 6e c5       	movq   %r13,%xmm0
   1407ced28:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407ced2c:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407ced31:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407ced35:	66 48 0f 6e c3       	movq   %rbx,%xmm0
   1407ced3a:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407ced3e:	66 49 0f 6e c4       	movq   %r12,%xmm0
   1407ced43:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407ced48:	90                   	nop
   1407ced49:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407ced50:	00 
   1407ced51:	89 d3                	mov    %edx,%ebx
   1407ced53:	41 b9 ff ff ff 00    	mov    $0xffffff,%r9d
   1407ced59:	e8 c2 f4 ff ff       	call   0x1407ce220
   1407ced5e:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407ced65:	00 
   1407ced66:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407ced6d:	00 
   1407ced6e:	f2 0f 10 0d c2 70 40 	movsd  0x4070c2(%rip),%xmm1        # 0x140bd5e38
   1407ced75:	00 
   1407ced76:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407ced7a:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407ced7f:	49 89 ca             	mov    %rcx,%r10
   1407ced82:	49 c1 ea 34          	shr    $0x34,%r10
   1407ced86:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407ced8d:	90                   	nop
   1407ced8e:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ced95:	73 2b                	jae    0x1407cedc2
   1407ced97:	49 bb 00 00 00 00 00 	movabs $0x8000000000000000,%r11
   1407ced9e:	00 00 80 
   1407ceda1:	4c 21 d9             	and    %r11,%rcx
   1407ceda4:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cedab:	00 f0 3f 
   1407cedae:	49 09 cc             	or     %rcx,%r12
   1407cedb1:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cedb8:	49 0f 44 cc          	cmove  %r12,%rcx
   1407cedbc:	49 89 cb             	mov    %rcx,%r11
   1407cedbf:	90                   	nop
   1407cedc0:	eb 3e                	jmp    0x1407cee00
   1407cedc2:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cedc9:	73 32                	jae    0x1407cedfd
   1407cedcb:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cedd2:	48 89 c8             	mov    %rcx,%rax
   1407cedd5:	4c 89 d1             	mov    %r10,%rcx
   1407cedd8:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407ceddf:	00 08 00 
   1407cede2:	49 d3 eb             	shr    %cl,%r11
   1407cede5:	49 01 c3             	add    %rax,%r11
   1407cede8:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407cedef:	ff 0f 00 
   1407cedf2:	49 d3 ec             	shr    %cl,%r12
   1407cedf5:	49 f7 d4             	not    %r12
   1407cedf8:	4d 21 e3             	and    %r12,%r11
   1407cedfb:	eb 03                	jmp    0x1407cee00
   1407cedfd:	49 89 cb             	mov    %rcx,%r11
   1407cee00:	f2 0f 10 0d 48 70 40 	movsd  0x407048(%rip),%xmm1        # 0x140bd5e50
   1407cee07:	00 
   1407cee08:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cee0c:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cee11:	49 89 ca             	mov    %rcx,%r10
   1407cee14:	49 c1 ea 34          	shr    $0x34,%r10
   1407cee18:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cee1f:	90                   	nop
   1407cee20:	90                   	nop
   1407cee21:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cee28:	73 2a                	jae    0x1407cee54
   1407cee2a:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407cee31:	00 00 80 
   1407cee34:	4c 21 e1             	and    %r12,%rcx
   1407cee37:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407cee3e:	00 f0 3f 
   1407cee41:	49 09 cd             	or     %rcx,%r13
   1407cee44:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cee4b:	49 0f 44 cd          	cmove  %r13,%rcx
   1407cee4f:	49 89 cc             	mov    %rcx,%r12
   1407cee52:	eb 3e                	jmp    0x1407cee92
   1407cee54:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cee5b:	73 32                	jae    0x1407cee8f
   1407cee5d:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cee64:	48 89 c8             	mov    %rcx,%rax
   1407cee67:	4c 89 d1             	mov    %r10,%rcx
   1407cee6a:	49 bc 00 00 00 00 00 	movabs $0x8000000000000,%r12
   1407cee71:	00 08 00 
   1407cee74:	49 d3 ec             	shr    %cl,%r12
   1407cee77:	49 01 c4             	add    %rax,%r12
   1407cee7a:	49 bd ff ff ff ff ff 	movabs $0xfffffffffffff,%r13
   1407cee81:	ff 0f 00 
   1407cee84:	49 d3 ed             	shr    %cl,%r13
   1407cee87:	49 f7 d5             	not    %r13
   1407cee8a:	4d 21 ec             	and    %r13,%r12
   1407cee8d:	eb 03                	jmp    0x1407cee92
   1407cee8f:	49 89 cc             	mov    %rcx,%r12
   1407cee92:	f2 0f 10 0d c6 6f 40 	movsd  0x406fc6(%rip),%xmm1        # 0x140bd5e60
   1407cee99:	00 
   1407cee9a:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cee9e:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407ceea3:	49 89 ca             	mov    %rcx,%r10
   1407ceea6:	49 c1 ea 34          	shr    $0x34,%r10
   1407ceeaa:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407ceeb1:	90                   	nop
   1407ceeb2:	90                   	nop
   1407ceeb3:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407ceeba:	73 2a                	jae    0x1407ceee6
   1407ceebc:	49 bd 00 00 00 00 00 	movabs $0x8000000000000000,%r13
   1407ceec3:	00 00 80 
   1407ceec6:	4c 21 e9             	and    %r13,%rcx
   1407ceec9:	49 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%r15
   1407ceed0:	00 f0 3f 
   1407ceed3:	49 09 cf             	or     %rcx,%r15
   1407ceed6:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407ceedd:	49 0f 44 cf          	cmove  %r15,%rcx
   1407ceee1:	49 89 cd             	mov    %rcx,%r13
   1407ceee4:	eb 3f                	jmp    0x1407cef25
   1407ceee6:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407ceeed:	73 33                	jae    0x1407cef22
   1407ceeef:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407ceef6:	48 89 c8             	mov    %rcx,%rax
   1407ceef9:	4c 89 d1             	mov    %r10,%rcx
   1407ceefc:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407cef03:	00 08 00 
   1407cef06:	49 d3 ed             	shr    %cl,%r13
   1407cef09:	49 01 c5             	add    %rax,%r13
   1407cef0c:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407cef13:	ff 0f 00 
   1407cef16:	49 d3 ef             	shr    %cl,%r15
   1407cef19:	49 f7 d7             	not    %r15
   1407cef1c:	4d 21 fd             	and    %r15,%r13
   1407cef1f:	90                   	nop
   1407cef20:	eb 03                	jmp    0x1407cef25
   1407cef22:	49 89 cd             	mov    %rcx,%r13
   1407cef25:	f2 0f 10 0d fb 6e 40 	movsd  0x406efb(%rip),%xmm1        # 0x140bd5e28
   1407cef2c:	00 
   1407cef2d:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cef31:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cef36:	49 89 ca             	mov    %rcx,%r10
   1407cef39:	49 c1 ea 34          	shr    $0x34,%r10
   1407cef3d:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cef44:	90                   	nop
   1407cef45:	90                   	nop
   1407cef46:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cef4d:	73 31                	jae    0x1407cef80
   1407cef4f:	49 bf 00 00 00 00 00 	movabs $0x8000000000000000,%r15
   1407cef56:	00 00 80 
   1407cef59:	4c 21 f9             	and    %r15,%rcx
   1407cef5c:	48 89 d0             	mov    %rdx,%rax
   1407cef5f:	48 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdx
   1407cef66:	00 f0 3f 
   1407cef69:	48 09 ca             	or     %rcx,%rdx
   1407cef6c:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cef73:	48 0f 44 ca          	cmove  %rdx,%rcx
   1407cef77:	49 89 cf             	mov    %rcx,%r15
   1407cef7a:	eb 48                	jmp    0x1407cefc4
   1407cef7c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cef80:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cef87:	73 35                	jae    0x1407cefbe
   1407cef89:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cef90:	48 89 c8             	mov    %rcx,%rax
   1407cef93:	4c 89 d1             	mov    %r10,%rcx
   1407cef96:	49 bf 00 00 00 00 00 	movabs $0x8000000000000,%r15
   1407cef9d:	00 08 00 
   1407cefa0:	49 d3 ef             	shr    %cl,%r15
   1407cefa3:	49 01 c7             	add    %rax,%r15
   1407cefa6:	48 89 d0             	mov    %rdx,%rax
   1407cefa9:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
   1407cefb0:	ff 0f 00 
   1407cefb3:	48 d3 ea             	shr    %cl,%rdx
   1407cefb6:	48 f7 d2             	not    %rdx
   1407cefb9:	49 21 d7             	and    %rdx,%r15
   1407cefbc:	eb 06                	jmp    0x1407cefc4
   1407cefbe:	48 89 d0             	mov    %rdx,%rax
   1407cefc1:	49 89 cf             	mov    %rcx,%r15
   1407cefc4:	f2 0f 10 0d 14 6e 40 	movsd  0x406e14(%rip),%xmm1        # 0x140bd5de0
   1407cefcb:	00 
   1407cefcc:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cefd0:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cefd5:	48 89 ca             	mov    %rcx,%rdx
   1407cefd8:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cefdc:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cefe2:	90                   	nop
   1407cefe3:	90                   	nop
   1407cefe4:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cefeb:	73 33                	jae    0x1407cf020
   1407cefed:	49 ba 00 00 00 00 00 	movabs $0x8000000000000000,%r10
   1407ceff4:	00 00 80 
   1407ceff7:	4c 21 d1             	and    %r10,%rcx
   1407ceffa:	49 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%r10
   1407cf001:	00 f0 3f 
   1407cf004:	49 09 ca             	or     %rcx,%r10
   1407cf007:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cf00e:	49 0f 44 ca          	cmove  %r10,%rcx
   1407cf012:	4c 89 fb             	mov    %r15,%rbx
   1407cf015:	49 89 ca             	mov    %rcx,%r10
   1407cf018:	eb 4a                	jmp    0x1407cf064
   1407cf01a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407cf020:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cf027:	73 35                	jae    0x1407cf05e
   1407cf029:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cf030:	48 89 cb             	mov    %rcx,%rbx
   1407cf033:	48 89 d1             	mov    %rdx,%rcx
   1407cf036:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407cf03d:	00 08 00 
   1407cf040:	49 d3 ea             	shr    %cl,%r10
   1407cf043:	49 01 da             	add    %rbx,%r10
   1407cf046:	4c 89 fb             	mov    %r15,%rbx
   1407cf049:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407cf050:	ff 0f 00 
   1407cf053:	49 d3 ef             	shr    %cl,%r15
   1407cf056:	49 f7 d7             	not    %r15
   1407cf059:	4d 21 fa             	and    %r15,%r10
   1407cf05c:	eb 06                	jmp    0x1407cf064
   1407cf05e:	4c 89 fb             	mov    %r15,%rbx
   1407cf061:	49 89 ca             	mov    %rcx,%r10
   1407cf064:	66 49 0f 6e c3       	movq   %r11,%xmm0
   1407cf069:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407cf06d:	66 49 0f 6e c4       	movq   %r12,%xmm0
   1407cf072:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cf076:	66 49 0f 6e c5       	movq   %r13,%xmm0
   1407cf07b:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407cf07f:	66 48 0f 6e c3       	movq   %rbx,%xmm0
   1407cf084:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407cf088:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407cf08d:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407cf092:	90                   	nop
   1407cf093:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf09a:	00 
   1407cf09b:	89 d3                	mov    %edx,%ebx
   1407cf09d:	41 b9 ff ff ff 00    	mov    $0xffffff,%r9d
   1407cf0a3:	e8 78 f1 ff ff       	call   0x1407ce220
   1407cf0a8:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
   1407cf0af:	00 
   1407cf0b0:	b8 43 00 00 00       	mov    $0x43,%eax
   1407cf0b5:	bb 10 00 00 00       	mov    $0x10,%ebx
   1407cf0ba:	b9 d2 00 00 00       	mov    $0xd2,%ecx
   1407cf0bf:	bf 17 00 00 00       	mov    $0x17,%edi
   1407cf0c4:	48 89 d6             	mov    %rdx,%rsi
   1407cf0c7:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cf0ce:	00 
   1407cf0cf:	ff d6                	call   *%rsi
   1407cf0d1:	89 04 24             	mov    %eax,(%rsp)
   1407cf0d4:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407cf0d8:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407cf0dc:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407cf0e0:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf0e7:	00 
   1407cf0e8:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407cf0ef:	00 
   1407cf0f0:	48 8d 0d 69 48 0e 00 	lea    0xe4869(%rip),%rcx        # 0x1408b3960
   1407cf0f7:	bf 25 00 00 00       	mov    $0x25,%edi
   1407cf0fc:	48 8d 35 99 37 0b 00 	lea    0xb3799(%rip),%rsi        # 0x14088289c
   1407cf103:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   1407cf109:	41 b9 62 38 16 00    	mov    $0x163862,%r9d
   1407cf10f:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407cf115:	e8 e6 ed ff ff       	call   0x1407cdf00
   1407cf11a:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407cf121:	00 
   1407cf122:	48 8b 82 a0 00 00 00 	mov    0xa0(%rdx),%rax
   1407cf129:	48 8b 9a a8 00 00 00 	mov    0xa8(%rdx),%rbx
   1407cf130:	e8 cb b6 ff ff       	call   0x1407ca800
   1407cf135:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   1407cf13c:	00 
   1407cf13d:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   1407cf144:	00 
   1407cf145:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
   1407cf14c:	00 
   1407cf14d:	b8 43 00 00 00       	mov    $0x43,%eax
   1407cf152:	bb 28 00 00 00       	mov    $0x28,%ebx
   1407cf157:	b9 96 00 00 00       	mov    $0x96,%ecx
   1407cf15c:	bf 12 00 00 00       	mov    $0x12,%edi
   1407cf161:	48 89 d6             	mov    %rdx,%rsi
   1407cf164:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cf16b:	00 
   1407cf16c:	ff d6                	call   *%rsi
   1407cf16e:	89 04 24             	mov    %eax,(%rsp)
   1407cf171:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407cf175:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407cf179:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407cf17d:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf184:	00 
   1407cf185:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407cf18c:	00 
   1407cf18d:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   1407cf194:	00 
   1407cf195:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   1407cf19c:	00 
   1407cf19d:	48 8d 35 9c 23 0b 00 	lea    0xb239c(%rip),%rsi        # 0x140881540
   1407cf1a4:	41 b8 04 00 00 00    	mov    $0x4,%r8d
   1407cf1aa:	41 b9 a3 86 71 00    	mov    $0x7186a3,%r9d
   1407cf1b0:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407cf1b6:	e8 45 ed ff ff       	call   0x1407cdf00
   1407cf1bb:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
   1407cf1c2:	00 
   1407cf1c3:	b8 1d 01 00 00       	mov    $0x11d,%eax
   1407cf1c8:	bb 17 00 00 00       	mov    $0x17,%ebx
   1407cf1cd:	b9 3d 00 00 00       	mov    $0x3d,%ecx
   1407cf1d2:	bf 1a 00 00 00       	mov    $0x1a,%edi
   1407cf1d7:	48 89 d6             	mov    %rdx,%rsi
   1407cf1da:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cf1e1:	00 
   1407cf1e2:	ff d6                	call   *%rsi
   1407cf1e4:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407cf1eb:	00 
   1407cf1ec:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cf1f3:	00 
   1407cf1f4:	f2 0f 10 0d ec 6b 40 	movsd  0x406bec(%rip),%xmm1        # 0x140bd5de8
   1407cf1fb:	00 
   1407cf1fc:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cf200:	66 49 0f 7e c2       	movq   %xmm0,%r10
   1407cf205:	4d 89 d3             	mov    %r10,%r11
   1407cf208:	49 c1 ea 34          	shr    $0x34,%r10
   1407cf20c:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cf213:	90                   	nop
   1407cf214:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cf21b:	73 2c                	jae    0x1407cf249
   1407cf21d:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407cf224:	00 00 80 
   1407cf227:	4d 21 e3             	and    %r12,%r11
   1407cf22a:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cf231:	00 f0 3f 
   1407cf234:	4d 09 dc             	or     %r11,%r12
   1407cf237:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cf23e:	4d 0f 44 dc          	cmove  %r12,%r11
   1407cf242:	89 ce                	mov    %ecx,%esi
   1407cf244:	4d 89 da             	mov    %r11,%r10
   1407cf247:	eb 40                	jmp    0x1407cf289
   1407cf249:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cf250:	73 32                	jae    0x1407cf284
   1407cf252:	4d 8d a2 01 fc ff ff 	lea    -0x3ff(%r10),%r12
   1407cf259:	89 ce                	mov    %ecx,%esi
   1407cf25b:	4c 89 e1             	mov    %r12,%rcx
   1407cf25e:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407cf265:	00 08 00 
   1407cf268:	49 d3 ed             	shr    %cl,%r13
   1407cf26b:	4f 8d 14 2b          	lea    (%r11,%r13,1),%r10
   1407cf26f:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407cf276:	ff 0f 00 
   1407cf279:	49 d3 eb             	shr    %cl,%r11
   1407cf27c:	49 f7 d3             	not    %r11
   1407cf27f:	4d 21 da             	and    %r11,%r10
   1407cf282:	eb 05                	jmp    0x1407cf289
   1407cf284:	89 ce                	mov    %ecx,%esi
   1407cf286:	4d 89 da             	mov    %r11,%r10
   1407cf289:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407cf28e:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407cf293:	90                   	nop
   1407cf294:	89 d9                	mov    %ebx,%ecx
   1407cf296:	41 b9 ff f0 e7 00    	mov    $0xe7f0ff,%r9d
   1407cf29c:	89 c3                	mov    %eax,%ebx
   1407cf29e:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf2a5:	00 
   1407cf2a6:	89 fa                	mov    %edi,%edx
   1407cf2a8:	89 f7                	mov    %esi,%edi
   1407cf2aa:	89 d6                	mov    %edx,%esi
   1407cf2ac:	e8 ef e8 ff ff       	call   0x1407cdba0
   1407cf2b1:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407cf2b8:	00 
   1407cf2b9:	80 7a 10 00          	cmpb   $0x0,0x10(%rdx)
   1407cf2bd:	74 26                	je     0x1407cf2e5
   1407cf2bf:	48 8b 72 08          	mov    0x8(%rdx),%rsi
   1407cf2c3:	48 85 f6             	test   %rsi,%rsi
   1407cf2c6:	7e 1d                	jle    0x1407cf2e5
   1407cf2c8:	4c 8b 42 68          	mov    0x68(%rdx),%r8
   1407cf2cc:	4c 39 c6             	cmp    %r8,%rsi
   1407cf2cf:	75 14                	jne    0x1407cf2e5
   1407cf2d1:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407cf2d6:	48 8d 0d 96 04 0c 00 	lea    0xc0496(%rip),%rcx        # 0x14088f773
   1407cf2dd:	0f 1f 00             	nopl   (%rax)
   1407cf2e0:	e9 81 00 00 00       	jmp    0x1407cf366
   1407cf2e5:	48 8b 72 58          	mov    0x58(%rdx),%rsi
   1407cf2e9:	4c 8b 42 50          	mov    0x50(%rdx),%r8
   1407cf2ed:	48 83 fe 04          	cmp    $0x4,%rsi
   1407cf2f1:	75 17                	jne    0x1407cf30a
   1407cf2f3:	41 81 38 6e 6f 74 65 	cmpl   $0x65746f6e,(%r8)
   1407cf2fa:	75 5e                	jne    0x1407cf35a
   1407cf2fc:	b8 0d 00 00 00       	mov    $0xd,%eax
   1407cf301:	48 8d 0d ad 1f 0c 00 	lea    0xc1fad(%rip),%rcx        # 0x1408912b5
   1407cf308:	eb 5c                	jmp    0x1407cf366
   1407cf30a:	48 83 fe 07          	cmp    $0x7,%rsi
   1407cf30e:	75 27                	jne    0x1407cf337
   1407cf310:	41 81 38 73 65 74 74 	cmpl   $0x74746573,(%r8)
   1407cf317:	75 41                	jne    0x1407cf35a
   1407cf319:	66 41 81 78 04 69 6e 	cmpw   $0x6e69,0x4(%r8)
   1407cf320:	75 38                	jne    0x1407cf35a
   1407cf322:	41 80 78 06 67       	cmpb   $0x67,0x6(%r8)
   1407cf327:	75 31                	jne    0x1407cf35a
   1407cf329:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407cf32e:	48 8d 0d ea 03 0c 00 	lea    0xc03ea(%rip),%rcx        # 0x14088f71f
   1407cf335:	eb 2f                	jmp    0x1407cf366
   1407cf337:	48 83 fe 08          	cmp    $0x8,%rsi
   1407cf33b:	75 1d                	jne    0x1407cf35a
   1407cf33d:	48 be 73 68 69 70 70 	movabs $0x676e697070696873,%rsi
   1407cf344:	69 6e 67 
   1407cf347:	49 39 30             	cmp    %rsi,(%r8)
   1407cf34a:	75 0e                	jne    0x1407cf35a
   1407cf34c:	b8 0c 00 00 00       	mov    $0xc,%eax
   1407cf351:	48 8d 0d bb 03 0c 00 	lea    0xc03bb(%rip),%rcx        # 0x14088f713
   1407cf358:	eb 0c                	jmp    0x1407cf366
   1407cf35a:	b8 06 00 00 00       	mov    $0x6,%eax
   1407cf35f:	48 8d 0d 35 55 0b 00 	lea    0xb5535(%rip),%rcx        # 0x14088489b
   1407cf366:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   1407cf36d:	00 
   1407cf36e:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
   1407cf375:	00 
   1407cf376:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407cf37d:	00 
   1407cf37e:	b8 1d 01 00 00       	mov    $0x11d,%eax
   1407cf383:	bb 17 00 00 00       	mov    $0x17,%ebx
   1407cf388:	b9 3d 00 00 00       	mov    $0x3d,%ecx
   1407cf38d:	bf 1a 00 00 00       	mov    $0x1a,%edi
   1407cf392:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cf399:	00 
   1407cf39a:	ff d6                	call   *%rsi
   1407cf39c:	89 04 24             	mov    %eax,(%rsp)
   1407cf39f:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407cf3a3:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407cf3a7:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407cf3ab:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf3b2:	00 
   1407cf3b3:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407cf3ba:	00 
   1407cf3bb:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   1407cf3c2:	00 
   1407cf3c3:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
   1407cf3ca:	00 
   1407cf3cb:	48 8d 35 01 35 0b 00 	lea    0xb3501(%rip),%rsi        # 0x1408828d3
   1407cf3d2:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   1407cf3d8:	41 b9 a0 58 24 00    	mov    $0x2458a0,%r9d
   1407cf3de:	41 ba 25 00 00 00    	mov    $0x25,%r10d
   1407cf3e4:	e8 17 eb ff ff       	call   0x1407cdf00
   1407cf3e9:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407cf3f0:	00 
   1407cf3f1:	80 be 39 01 00 00 00 	cmpb   $0x0,0x139(%rsi)
   1407cf3f8:	0f 84 fc 00 00 00    	je     0x1407cf4fa
   1407cf3fe:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407cf405:	00 
   1407cf406:	b8 6b 01 00 00       	mov    $0x16b,%eax
   1407cf40b:	bb 11 00 00 00       	mov    $0x11,%ebx
   1407cf410:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   1407cf415:	89 cf                	mov    %ecx,%edi
   1407cf417:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cf41e:	00 
   1407cf41f:	90                   	nop
   1407cf420:	ff d6                	call   *%rsi
   1407cf422:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407cf429:	00 
   1407cf42a:	f2 0f 10 86 b8 00 00 	movsd  0xb8(%rsi),%xmm0
   1407cf431:	00 
   1407cf432:	f2 0f 10 0d ae 69 40 	movsd  0x4069ae(%rip),%xmm1        # 0x140bd5de8
   1407cf439:	00 
   1407cf43a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407cf43e:	66 49 0f 7e c0       	movq   %xmm0,%r8
   1407cf443:	4d 89 c1             	mov    %r8,%r9
   1407cf446:	49 c1 e8 34          	shr    $0x34,%r8
   1407cf44a:	41 81 e0 ff 07 00 00 	and    $0x7ff,%r8d
   1407cf451:	90                   	nop
   1407cf452:	49 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8
   1407cf459:	73 2d                	jae    0x1407cf488
   1407cf45b:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
   1407cf462:	00 00 80 
   1407cf465:	49 21 d1             	and    %rdx,%r9
   1407cf468:	48 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdx
   1407cf46f:	00 f0 3f 
   1407cf472:	4c 09 ca             	or     %r9,%rdx
   1407cf475:	49 81 f8 fe 03 00 00 	cmp    $0x3fe,%r8
   1407cf47c:	4c 0f 44 ca          	cmove  %rdx,%r9
   1407cf480:	41 89 c8             	mov    %ecx,%r8d
   1407cf483:	4d 89 ca             	mov    %r9,%r10
   1407cf486:	eb 41                	jmp    0x1407cf4c9
   1407cf488:	49 81 f8 33 04 00 00 	cmp    $0x433,%r8
   1407cf48f:	73 32                	jae    0x1407cf4c3
   1407cf491:	49 8d 90 01 fc ff ff 	lea    -0x3ff(%r8),%rdx
   1407cf498:	41 89 c8             	mov    %ecx,%r8d
   1407cf49b:	48 89 d1             	mov    %rdx,%rcx
   1407cf49e:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407cf4a5:	00 08 00 
   1407cf4a8:	49 d3 ea             	shr    %cl,%r10
   1407cf4ab:	4d 01 ca             	add    %r9,%r10
   1407cf4ae:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407cf4b5:	ff 0f 00 
   1407cf4b8:	49 d3 eb             	shr    %cl,%r11
   1407cf4bb:	49 f7 d3             	not    %r11
   1407cf4be:	4d 21 da             	and    %r11,%r10
   1407cf4c1:	eb 06                	jmp    0x1407cf4c9
   1407cf4c3:	41 89 c8             	mov    %ecx,%r8d
   1407cf4c6:	4d 89 ca             	mov    %r9,%r10
   1407cf4c9:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407cf4ce:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407cf4d2:	90                   	nop
   1407cf4d3:	89 d9                	mov    %ebx,%ecx
   1407cf4d5:	89 fe                	mov    %edi,%esi
   1407cf4d7:	41 b9 fc f0 e8 00    	mov    $0xe8f0fc,%r9d
   1407cf4dd:	89 c3                	mov    %eax,%ebx
   1407cf4df:	44 89 c7             	mov    %r8d,%edi
   1407cf4e2:	41 89 d0             	mov    %edx,%r8d
   1407cf4e5:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf4ec:	00 
   1407cf4ed:	e8 ae e6 ff ff       	call   0x1407cdba0
   1407cf4f2:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407cf4f9:	00 
   1407cf4fa:	f2 0f 10 86 b8 00 00 	movsd  0xb8(%rsi),%xmm0
   1407cf501:	00 
   1407cf502:	f2 0f 10 0d a6 69 40 	movsd  0x4069a6(%rip),%xmm1        # 0x140bd5eb0
   1407cf509:	00 
   1407cf50a:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf50e:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf513:	48 89 ca             	mov    %rcx,%rdx
   1407cf516:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cf51a:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cf520:	90                   	nop
   1407cf521:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cf528:	73 2a                	jae    0x1407cf554
   1407cf52a:	49 ba 00 00 00 00 00 	movabs $0x8000000000000000,%r10
   1407cf531:	00 00 80 
   1407cf534:	4c 21 d1             	and    %r10,%rcx
   1407cf537:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407cf53e:	00 f0 3f 
   1407cf541:	49 09 cb             	or     %rcx,%r11
   1407cf544:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cf54b:	49 0f 44 cb          	cmove  %r11,%rcx
   1407cf54f:	49 89 ca             	mov    %rcx,%r10
   1407cf552:	eb 3e                	jmp    0x1407cf592
   1407cf554:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cf55b:	73 32                	jae    0x1407cf58f
   1407cf55d:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cf564:	48 89 c8             	mov    %rcx,%rax
   1407cf567:	48 89 d1             	mov    %rdx,%rcx
   1407cf56a:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407cf571:	00 08 00 
   1407cf574:	49 d3 ea             	shr    %cl,%r10
   1407cf577:	49 01 c2             	add    %rax,%r10
   1407cf57a:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407cf581:	ff 0f 00 
   1407cf584:	49 d3 eb             	shr    %cl,%r11
   1407cf587:	49 f7 d3             	not    %r11
   1407cf58a:	4d 21 da             	and    %r11,%r10
   1407cf58d:	eb 03                	jmp    0x1407cf592
   1407cf58f:	49 89 ca             	mov    %rcx,%r10
   1407cf592:	f2 0f 10 0d 86 68 40 	movsd  0x406886(%rip),%xmm1        # 0x140bd5e20
   1407cf599:	00 
   1407cf59a:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf59e:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf5a3:	48 89 ca             	mov    %rcx,%rdx
   1407cf5a6:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cf5aa:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cf5b0:	90                   	nop
   1407cf5b1:	90                   	nop
   1407cf5b2:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cf5b9:	73 2a                	jae    0x1407cf5e5
   1407cf5bb:	49 bb 00 00 00 00 00 	movabs $0x8000000000000000,%r11
   1407cf5c2:	00 00 80 
   1407cf5c5:	4c 21 d9             	and    %r11,%rcx
   1407cf5c8:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cf5cf:	00 f0 3f 
   1407cf5d2:	49 09 cc             	or     %rcx,%r12
   1407cf5d5:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cf5dc:	49 0f 44 cc          	cmove  %r12,%rcx
   1407cf5e0:	49 89 cb             	mov    %rcx,%r11
   1407cf5e3:	eb 40                	jmp    0x1407cf625
   1407cf5e5:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cf5ec:	73 34                	jae    0x1407cf622
   1407cf5ee:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cf5f5:	48 89 c8             	mov    %rcx,%rax
   1407cf5f8:	48 89 d1             	mov    %rdx,%rcx
   1407cf5fb:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407cf602:	00 08 00 
   1407cf605:	49 d3 eb             	shr    %cl,%r11
   1407cf608:	49 01 c3             	add    %rax,%r11
   1407cf60b:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407cf612:	ff 0f 00 
   1407cf615:	49 d3 ec             	shr    %cl,%r12
   1407cf618:	49 f7 d4             	not    %r12
   1407cf61b:	4d 21 e3             	and    %r12,%r11
   1407cf61e:	66 90                	xchg   %ax,%ax
   1407cf620:	eb 03                	jmp    0x1407cf625
   1407cf622:	49 89 cb             	mov    %rcx,%r11
   1407cf625:	f2 0f 10 0d 8b 68 40 	movsd  0x40688b(%rip),%xmm1        # 0x140bd5eb8
   1407cf62c:	00 
   1407cf62d:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf631:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf636:	48 89 ca             	mov    %rcx,%rdx
   1407cf639:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cf63d:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cf643:	90                   	nop
   1407cf644:	90                   	nop
   1407cf645:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cf64c:	73 32                	jae    0x1407cf680
   1407cf64e:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407cf655:	00 00 80 
   1407cf658:	4c 21 e1             	and    %r12,%rcx
   1407cf65b:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407cf662:	00 f0 3f 
   1407cf665:	49 09 cd             	or     %rcx,%r13
   1407cf668:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cf66f:	49 0f 44 cd          	cmove  %r13,%rcx
   1407cf673:	49 89 cc             	mov    %rcx,%r12
   1407cf676:	eb 46                	jmp    0x1407cf6be
   1407cf678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   1407cf67f:	00 
   1407cf680:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cf687:	73 32                	jae    0x1407cf6bb
   1407cf689:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cf690:	48 89 c8             	mov    %rcx,%rax
   1407cf693:	48 89 d1             	mov    %rdx,%rcx
   1407cf696:	49 bc 00 00 00 00 00 	movabs $0x8000000000000,%r12
   1407cf69d:	00 08 00 
   1407cf6a0:	49 d3 ec             	shr    %cl,%r12
   1407cf6a3:	49 01 c4             	add    %rax,%r12
   1407cf6a6:	49 bd ff ff ff ff ff 	movabs $0xfffffffffffff,%r13
   1407cf6ad:	ff 0f 00 
   1407cf6b0:	49 d3 ed             	shr    %cl,%r13
   1407cf6b3:	49 f7 d5             	not    %r13
   1407cf6b6:	4d 21 ec             	and    %r13,%r12
   1407cf6b9:	eb 03                	jmp    0x1407cf6be
   1407cf6bb:	49 89 cc             	mov    %rcx,%r12
   1407cf6be:	f2 0f 10 0d 7a 67 40 	movsd  0x40677a(%rip),%xmm1        # 0x140bd5e40
   1407cf6c5:	00 
   1407cf6c6:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf6ca:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf6cf:	48 89 ca             	mov    %rcx,%rdx
   1407cf6d2:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cf6d6:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cf6dc:	90                   	nop
   1407cf6dd:	90                   	nop
   1407cf6de:	66 90                	xchg   %ax,%ax
   1407cf6e0:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cf6e7:	73 2a                	jae    0x1407cf713
   1407cf6e9:	49 bd 00 00 00 00 00 	movabs $0x8000000000000000,%r13
   1407cf6f0:	00 00 80 
   1407cf6f3:	4c 21 e9             	and    %r13,%rcx
   1407cf6f6:	49 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%r15
   1407cf6fd:	00 f0 3f 
   1407cf700:	49 09 cf             	or     %rcx,%r15
   1407cf703:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cf70a:	49 0f 44 cf          	cmove  %r15,%rcx
   1407cf70e:	49 89 cd             	mov    %rcx,%r13
   1407cf711:	eb 3e                	jmp    0x1407cf751
   1407cf713:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cf71a:	73 32                	jae    0x1407cf74e
   1407cf71c:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cf723:	48 89 c8             	mov    %rcx,%rax
   1407cf726:	48 89 d1             	mov    %rdx,%rcx
   1407cf729:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407cf730:	00 08 00 
   1407cf733:	49 d3 ed             	shr    %cl,%r13
   1407cf736:	49 01 c5             	add    %rax,%r13
   1407cf739:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407cf740:	ff 0f 00 
   1407cf743:	49 d3 ef             	shr    %cl,%r15
   1407cf746:	49 f7 d7             	not    %r15
   1407cf749:	4d 21 fd             	and    %r15,%r13
   1407cf74c:	eb 03                	jmp    0x1407cf751
   1407cf74e:	49 89 cd             	mov    %rcx,%r13
   1407cf751:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cf756:	48 89 ca             	mov    %rcx,%rdx
   1407cf759:	48 c1 ea 34          	shr    $0x34,%rdx
   1407cf75d:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407cf763:	90                   	nop
   1407cf764:	90                   	nop
   1407cf765:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407cf76c:	73 32                	jae    0x1407cf7a0
   1407cf76e:	49 bf 00 00 00 00 00 	movabs $0x8000000000000000,%r15
   1407cf775:	00 00 80 
   1407cf778:	4c 21 f9             	and    %r15,%rcx
   1407cf77b:	49 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%r15
   1407cf782:	00 f0 3f 
   1407cf785:	49 09 cf             	or     %rcx,%r15
   1407cf788:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407cf78f:	49 0f 44 cf          	cmove  %r15,%rcx
   1407cf793:	4c 89 e8             	mov    %r13,%rax
   1407cf796:	49 89 cf             	mov    %rcx,%r15
   1407cf799:	eb 49                	jmp    0x1407cf7e4
   1407cf79b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cf7a0:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407cf7a7:	73 35                	jae    0x1407cf7de
   1407cf7a9:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407cf7b0:	48 89 c8             	mov    %rcx,%rax
   1407cf7b3:	48 89 d1             	mov    %rdx,%rcx
   1407cf7b6:	49 bf 00 00 00 00 00 	movabs $0x8000000000000,%r15
   1407cf7bd:	00 08 00 
   1407cf7c0:	49 d3 ef             	shr    %cl,%r15
   1407cf7c3:	49 01 c7             	add    %rax,%r15
   1407cf7c6:	4c 89 e8             	mov    %r13,%rax
   1407cf7c9:	49 bd ff ff ff ff ff 	movabs $0xfffffffffffff,%r13
   1407cf7d0:	ff 0f 00 
   1407cf7d3:	49 d3 ed             	shr    %cl,%r13
   1407cf7d6:	49 f7 d5             	not    %r13
   1407cf7d9:	4d 21 ef             	and    %r13,%r15
   1407cf7dc:	eb 06                	jmp    0x1407cf7e4
   1407cf7de:	4c 89 e8             	mov    %r13,%rax
   1407cf7e1:	49 89 cf             	mov    %rcx,%r15
   1407cf7e4:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407cf7e9:	f2 0f 2c d8          	cvttsd2si %xmm0,%ebx
   1407cf7ed:	66 49 0f 6e c3       	movq   %r11,%xmm0
   1407cf7f2:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cf7f6:	66 49 0f 6e c4       	movq   %r12,%xmm0
   1407cf7fb:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407cf7ff:	66 48 0f 6e c0       	movq   %rax,%xmm0
   1407cf804:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407cf808:	66 49 0f 6e c7       	movq   %r15,%xmm0
   1407cf80d:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407cf812:	90                   	nop
   1407cf813:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cf81a:	00 
   1407cf81b:	41 b9 b1 91 79 00    	mov    $0x7991b1,%r9d
   1407cf821:	e8 fa e9 ff ff       	call   0x1407ce220
   1407cf826:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407cf82d:	00 
   1407cf82e:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
   1407cf835:	00 
   1407cf836:	f2 0f 10 0d 7a 66 40 	movsd  0x40667a(%rip),%xmm1        # 0x140bd5eb8
   1407cf83d:	00 
   1407cf83e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf842:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf847:	49 89 ca             	mov    %rcx,%r10
   1407cf84a:	49 c1 ea 34          	shr    $0x34,%r10
   1407cf84e:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cf855:	90                   	nop
   1407cf856:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cf85d:	73 2a                	jae    0x1407cf889
   1407cf85f:	49 bb 00 00 00 00 00 	movabs $0x8000000000000000,%r11
   1407cf866:	00 00 80 
   1407cf869:	4c 21 d9             	and    %r11,%rcx
   1407cf86c:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
   1407cf873:	00 f0 3f 
   1407cf876:	49 09 cc             	or     %rcx,%r12
   1407cf879:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cf880:	49 0f 44 cc          	cmove  %r12,%rcx
   1407cf884:	49 89 cb             	mov    %rcx,%r11
   1407cf887:	eb 3e                	jmp    0x1407cf8c7
   1407cf889:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cf890:	73 32                	jae    0x1407cf8c4
   1407cf892:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cf899:	48 89 c8             	mov    %rcx,%rax
   1407cf89c:	4c 89 d1             	mov    %r10,%rcx
   1407cf89f:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407cf8a6:	00 08 00 
   1407cf8a9:	49 d3 eb             	shr    %cl,%r11
   1407cf8ac:	49 01 c3             	add    %rax,%r11
   1407cf8af:	49 bc ff ff ff ff ff 	movabs $0xfffffffffffff,%r12
   1407cf8b6:	ff 0f 00 
   1407cf8b9:	49 d3 ec             	shr    %cl,%r12
   1407cf8bc:	49 f7 d4             	not    %r12
   1407cf8bf:	4d 21 e3             	and    %r12,%r11
   1407cf8c2:	eb 03                	jmp    0x1407cf8c7
   1407cf8c4:	49 89 cb             	mov    %rcx,%r11
   1407cf8c7:	f2 0f 10 0d 51 65 40 	movsd  0x406551(%rip),%xmm1        # 0x140bd5e20
   1407cf8ce:	00 
   1407cf8cf:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf8d3:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf8d8:	49 89 ca             	mov    %rcx,%r10
   1407cf8db:	49 c1 ea 34          	shr    $0x34,%r10
   1407cf8df:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cf8e6:	90                   	nop
   1407cf8e7:	90                   	nop
   1407cf8e8:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cf8ef:	73 2f                	jae    0x1407cf920
   1407cf8f1:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407cf8f8:	00 00 80 
   1407cf8fb:	4c 21 e1             	and    %r12,%rcx
   1407cf8fe:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407cf905:	00 f0 3f 
   1407cf908:	49 09 cd             	or     %rcx,%r13
   1407cf90b:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cf912:	49 0f 44 cd          	cmove  %r13,%rcx
   1407cf916:	49 89 cc             	mov    %rcx,%r12
   1407cf919:	eb 43                	jmp    0x1407cf95e
   1407cf91b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407cf920:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cf927:	73 32                	jae    0x1407cf95b
   1407cf929:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cf930:	48 89 c8             	mov    %rcx,%rax
   1407cf933:	4c 89 d1             	mov    %r10,%rcx
   1407cf936:	49 bc 00 00 00 00 00 	movabs $0x8000000000000,%r12
   1407cf93d:	00 08 00 
   1407cf940:	49 d3 ec             	shr    %cl,%r12
   1407cf943:	49 01 c4             	add    %rax,%r12
   1407cf946:	49 bd ff ff ff ff ff 	movabs $0xfffffffffffff,%r13
   1407cf94d:	ff 0f 00 
   1407cf950:	49 d3 ed             	shr    %cl,%r13
   1407cf953:	49 f7 d5             	not    %r13
   1407cf956:	4d 21 ec             	and    %r13,%r12
   1407cf959:	eb 03                	jmp    0x1407cf95e
   1407cf95b:	49 89 cc             	mov    %rcx,%r12
   1407cf95e:	f2 0f 10 0d 4a 65 40 	movsd  0x40654a(%rip),%xmm1        # 0x140bd5eb0
   1407cf965:	00 
   1407cf966:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf96a:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cf96f:	49 89 ca             	mov    %rcx,%r10
   1407cf972:	49 c1 ea 34          	shr    $0x34,%r10
   1407cf976:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cf97d:	90                   	nop
   1407cf97e:	90                   	nop
   1407cf97f:	90                   	nop
   1407cf980:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cf987:	73 2a                	jae    0x1407cf9b3
   1407cf989:	49 bd 00 00 00 00 00 	movabs $0x8000000000000000,%r13
   1407cf990:	00 00 80 
   1407cf993:	4c 21 e9             	and    %r13,%rcx
   1407cf996:	49 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%r15
   1407cf99d:	00 f0 3f 
   1407cf9a0:	49 09 cf             	or     %rcx,%r15
   1407cf9a3:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cf9aa:	49 0f 44 cf          	cmove  %r15,%rcx
   1407cf9ae:	49 89 cd             	mov    %rcx,%r13
   1407cf9b1:	eb 3e                	jmp    0x1407cf9f1
   1407cf9b3:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cf9ba:	73 32                	jae    0x1407cf9ee
   1407cf9bc:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cf9c3:	48 89 c8             	mov    %rcx,%rax
   1407cf9c6:	4c 89 d1             	mov    %r10,%rcx
   1407cf9c9:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407cf9d0:	00 08 00 
   1407cf9d3:	49 d3 ed             	shr    %cl,%r13
   1407cf9d6:	49 01 c5             	add    %rax,%r13
   1407cf9d9:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407cf9e0:	ff 0f 00 
   1407cf9e3:	49 d3 ef             	shr    %cl,%r15
   1407cf9e6:	49 f7 d7             	not    %r15
   1407cf9e9:	4d 21 fd             	and    %r15,%r13
   1407cf9ec:	eb 03                	jmp    0x1407cf9f1
   1407cf9ee:	49 89 cd             	mov    %rcx,%r13
   1407cf9f1:	f2 0f 10 0d 47 64 40 	movsd  0x406447(%rip),%xmm1        # 0x140bd5e40
   1407cf9f8:	00 
   1407cf9f9:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407cf9fd:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407cfa02:	49 89 ca             	mov    %rcx,%r10
   1407cfa05:	49 c1 ea 34          	shr    $0x34,%r10
   1407cfa09:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cfa10:	90                   	nop
   1407cfa11:	90                   	nop
   1407cfa12:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cfa19:	73 2d                	jae    0x1407cfa48
   1407cfa1b:	49 bf 00 00 00 00 00 	movabs $0x8000000000000000,%r15
   1407cfa22:	00 00 80 
   1407cfa25:	4c 21 f9             	and    %r15,%rcx
   1407cfa28:	4c 89 e8             	mov    %r13,%rax
   1407cfa2b:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407cfa32:	00 f0 3f 
   1407cfa35:	49 09 cd             	or     %rcx,%r13
   1407cfa38:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cfa3f:	49 0f 44 cd          	cmove  %r13,%rcx
   1407cfa43:	49 89 cf             	mov    %rcx,%r15
   1407cfa46:	eb 44                	jmp    0x1407cfa8c
   1407cfa48:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cfa4f:	73 35                	jae    0x1407cfa86
   1407cfa51:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cfa58:	48 89 c8             	mov    %rcx,%rax
   1407cfa5b:	4c 89 d1             	mov    %r10,%rcx
   1407cfa5e:	49 bf 00 00 00 00 00 	movabs $0x8000000000000,%r15
   1407cfa65:	00 08 00 
   1407cfa68:	49 d3 ef             	shr    %cl,%r15
   1407cfa6b:	49 01 c7             	add    %rax,%r15
   1407cfa6e:	4c 89 e8             	mov    %r13,%rax
   1407cfa71:	49 bd ff ff ff ff ff 	movabs $0xfffffffffffff,%r13
   1407cfa78:	ff 0f 00 
   1407cfa7b:	49 d3 ed             	shr    %cl,%r13
   1407cfa7e:	49 f7 d5             	not    %r13
   1407cfa81:	4d 21 ef             	and    %r13,%r15
   1407cfa84:	eb 06                	jmp    0x1407cfa8c
   1407cfa86:	4c 89 e8             	mov    %r13,%rax
   1407cfa89:	49 89 cf             	mov    %rcx,%r15
   1407cfa8c:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407cfa91:	49 89 ca             	mov    %rcx,%r10
   1407cfa94:	49 c1 ea 34          	shr    $0x34,%r10
   1407cfa98:	41 81 e2 ff 07 00 00 	and    $0x7ff,%r10d
   1407cfa9f:	90                   	nop
   1407cfaa0:	90                   	nop
   1407cfaa1:	49 81 fa ff 03 00 00 	cmp    $0x3ff,%r10
   1407cfaa8:	73 36                	jae    0x1407cfae0
   1407cfaaa:	49 bd 00 00 00 00 00 	movabs $0x8000000000000000,%r13
   1407cfab1:	00 00 80 
   1407cfab4:	4c 21 e9             	and    %r13,%rcx
   1407cfab7:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407cfabe:	00 f0 3f 
   1407cfac1:	49 09 cd             	or     %rcx,%r13
   1407cfac4:	49 81 fa fe 03 00 00 	cmp    $0x3fe,%r10
   1407cfacb:	49 0f 44 cd          	cmove  %r13,%rcx
   1407cfacf:	4c 89 fb             	mov    %r15,%rbx
   1407cfad2:	49 89 cd             	mov    %rcx,%r13
   1407cfad5:	eb 4d                	jmp    0x1407cfb24
   1407cfad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1407cfade:	00 00 
   1407cfae0:	49 81 fa 33 04 00 00 	cmp    $0x433,%r10
   1407cfae7:	73 35                	jae    0x1407cfb1e
   1407cfae9:	49 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%r10
   1407cfaf0:	48 89 cb             	mov    %rcx,%rbx
   1407cfaf3:	4c 89 d1             	mov    %r10,%rcx
   1407cfaf6:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407cfafd:	00 08 00 
   1407cfb00:	49 d3 ed             	shr    %cl,%r13
   1407cfb03:	49 01 dd             	add    %rbx,%r13
   1407cfb06:	4c 89 fb             	mov    %r15,%rbx
   1407cfb09:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407cfb10:	ff 0f 00 
   1407cfb13:	49 d3 ef             	shr    %cl,%r15
   1407cfb16:	49 f7 d7             	not    %r15
   1407cfb19:	4d 21 fd             	and    %r15,%r13
   1407cfb1c:	eb 06                	jmp    0x1407cfb24
   1407cfb1e:	4c 89 fb             	mov    %r15,%rbx
   1407cfb21:	49 89 cd             	mov    %rcx,%r13
   1407cfb24:	48 83 c2 08          	add    $0x8,%rdx
   1407cfb28:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
   1407cfb2f:	00 
   1407cfb30:	66 49 0f 6e c3       	movq   %r11,%xmm0
   1407cfb35:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407cfb39:	66 49 0f 6e c4       	movq   %r12,%xmm0
   1407cfb3e:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407cfb42:	66 48 0f 6e c0       	movq   %rax,%xmm0
   1407cfb47:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407cfb4b:	66 48 0f 6e c3       	movq   %rbx,%xmm0
   1407cfb50:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407cfb54:	66 49 0f 6e c5       	movq   %r13,%xmm0
   1407cfb59:	f2 44 0f 2c c0       	cvttsd2si %xmm0,%r8d
   1407cfb5e:	90                   	nop
   1407cfb5f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cfb66:	00 
   1407cfb67:	89 d3                	mov    %edx,%ebx
   1407cfb69:	41 b9 b1 91 79 00    	mov    $0x7991b1,%r9d
   1407cfb6f:	e8 ac e6 ff ff       	call   0x1407ce220
   1407cfb74:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
   1407cfb7b:	00 
   1407cfb7c:	b8 14 00 00 00       	mov    $0x14,%eax
   1407cfb81:	bb 45 00 00 00       	mov    $0x45,%ebx
   1407cfb86:	b9 70 01 00 00       	mov    $0x170,%ecx
   1407cfb8b:	bf 01 00 00 00       	mov    $0x1,%edi
   1407cfb90:	48 89 d6             	mov    %rdx,%rsi
   1407cfb93:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cfb9a:	00 
   1407cfb9b:	ff d6                	call   *%rsi
   1407cfb9d:	89 fe                	mov    %edi,%esi
   1407cfb9f:	41 b8 f7 e7 dc 00    	mov    $0xdce7f7,%r8d
   1407cfba5:	89 cf                	mov    %ecx,%edi
   1407cfba7:	89 d9                	mov    %ebx,%ecx
   1407cfba9:	89 c3                	mov    %eax,%ebx
   1407cfbab:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cfbb2:	00 
   1407cfbb3:	e8 28 de ff ff       	call   0x1407cd9e0
   1407cfbb8:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
   1407cfbbf:	00 
   1407cfbc0:	4c 8b 94 24 48 01 00 	mov    0x148(%rsp),%r10
   1407cfbc7:	00 
   1407cfbc8:	45 0f 10 32          	movups (%r10),%xmm14
   1407cfbcc:	44 0f 11 32          	movups %xmm14,(%rdx)
   1407cfbd0:	45 0f 10 72 10       	movups 0x10(%r10),%xmm14
   1407cfbd5:	44 0f 11 72 10       	movups %xmm14,0x10(%rdx)
   1407cfbda:	45 0f 10 72 20       	movups 0x20(%r10),%xmm14
   1407cfbdf:	44 0f 11 72 20       	movups %xmm14,0x20(%rdx)
   1407cfbe4:	45 0f 10 72 30       	movups 0x30(%r10),%xmm14
   1407cfbe9:	44 0f 11 72 30       	movups %xmm14,0x30(%rdx)
   1407cfbee:	45 0f 10 72 40       	movups 0x40(%r10),%xmm14
   1407cfbf3:	44 0f 11 72 40       	movups %xmm14,0x40(%rdx)
   1407cfbf8:	45 0f 10 72 50       	movups 0x50(%r10),%xmm14
   1407cfbfd:	44 0f 11 72 50       	movups %xmm14,0x50(%rdx)
   1407cfc02:	45 0f 10 72 60       	movups 0x60(%r10),%xmm14
   1407cfc07:	44 0f 11 72 60       	movups %xmm14,0x60(%rdx)
   1407cfc0c:	45 0f 10 72 70       	movups 0x70(%r10),%xmm14
   1407cfc11:	44 0f 11 72 70       	movups %xmm14,0x70(%rdx)
   1407cfc16:	45 0f 10 b2 80 00 00 	movups 0x80(%r10),%xmm14
   1407cfc1d:	00 
   1407cfc1e:	44 0f 11 b2 80 00 00 	movups %xmm14,0x80(%rdx)
   1407cfc25:	00 
   1407cfc26:	45 0f 10 b2 90 00 00 	movups 0x90(%r10),%xmm14
   1407cfc2d:	00 
   1407cfc2e:	44 0f 11 b2 90 00 00 	movups %xmm14,0x90(%rdx)
   1407cfc35:	00 
   1407cfc36:	45 0f 10 b2 98 00 00 	movups 0x98(%r10),%xmm14
   1407cfc3d:	00 
   1407cfc3e:	44 0f 11 b2 98 00 00 	movups %xmm14,0x98(%rdx)
   1407cfc45:	00 
   1407cfc46:	49 89 e2             	mov    %rsp,%r10
   1407cfc49:	44 0f 10 32          	movups (%rdx),%xmm14
   1407cfc4d:	45 0f 11 32          	movups %xmm14,(%r10)
   1407cfc51:	44 0f 10 72 10       	movups 0x10(%rdx),%xmm14
   1407cfc56:	45 0f 11 72 10       	movups %xmm14,0x10(%r10)
   1407cfc5b:	44 0f 10 72 20       	movups 0x20(%rdx),%xmm14
   1407cfc60:	45 0f 11 72 20       	movups %xmm14,0x20(%r10)
   1407cfc65:	44 0f 10 72 30       	movups 0x30(%rdx),%xmm14
   1407cfc6a:	45 0f 11 72 30       	movups %xmm14,0x30(%r10)
   1407cfc6f:	44 0f 10 72 40       	movups 0x40(%rdx),%xmm14
   1407cfc74:	45 0f 11 72 40       	movups %xmm14,0x40(%r10)
   1407cfc79:	44 0f 10 72 50       	movups 0x50(%rdx),%xmm14
   1407cfc7e:	45 0f 11 72 50       	movups %xmm14,0x50(%r10)
   1407cfc83:	44 0f 10 72 60       	movups 0x60(%rdx),%xmm14
   1407cfc88:	45 0f 11 72 60       	movups %xmm14,0x60(%r10)
   1407cfc8d:	44 0f 10 72 70       	movups 0x70(%rdx),%xmm14
   1407cfc92:	45 0f 11 72 70       	movups %xmm14,0x70(%r10)
   1407cfc97:	44 0f 10 b2 80 00 00 	movups 0x80(%rdx),%xmm14
   1407cfc9e:	00 
   1407cfc9f:	45 0f 11 b2 80 00 00 	movups %xmm14,0x80(%r10)
   1407cfca6:	00 
   1407cfca7:	44 0f 10 b2 90 00 00 	movups 0x90(%rdx),%xmm14
   1407cfcae:	00 
   1407cfcaf:	45 0f 11 b2 90 00 00 	movups %xmm14,0x90(%r10)
   1407cfcb6:	00 
   1407cfcb7:	44 0f 10 b2 98 00 00 	movups 0x98(%rdx),%xmm14
   1407cfcbe:	00 
   1407cfcbf:	45 0f 11 b2 98 00 00 	movups %xmm14,0x98(%r10)
   1407cfcc6:	00 
   1407cfcc7:	e8 74 ac ff ff       	call   0x1407ca940
   1407cfccc:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   1407cfcd3:	00 
   1407cfcd4:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   1407cfcdb:	00 
   1407cfcdc:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
   1407cfce3:	00 
   1407cfce4:	b8 16 00 00 00       	mov    $0x16,%eax
   1407cfce9:	bb 52 00 00 00       	mov    $0x52,%ebx
   1407cfcee:	b9 6c 01 00 00       	mov    $0x16c,%ecx
   1407cfcf3:	bf 19 00 00 00       	mov    $0x19,%edi
   1407cfcf8:	48 89 d6             	mov    %rdx,%rsi
   1407cfcfb:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cfd02:	00 
   1407cfd03:	ff d6                	call   *%rsi
   1407cfd05:	89 04 24             	mov    %eax,(%rsp)
   1407cfd08:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407cfd0c:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407cfd10:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407cfd14:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cfd1b:	00 
   1407cfd1c:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407cfd23:	00 
   1407cfd24:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   1407cfd2b:	00 
   1407cfd2c:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   1407cfd33:	00 
   1407cfd34:	48 8d 35 78 4b 0b 00 	lea    0xb4b78(%rip),%rsi        # 0x1408848b3
   1407cfd3b:	41 b8 06 00 00 00    	mov    $0x6,%r8d
   1407cfd41:	41 b9 7f 56 34 00    	mov    $0x34567f,%r9d
   1407cfd47:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407cfd4d:	e8 ae e1 ff ff       	call   0x1407cdf00
   1407cfd52:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407cfd59:	00 
   1407cfd5a:	48 83 7a 58 04       	cmpq   $0x4,0x58(%rdx)
   1407cfd5f:	90                   	nop
   1407cfd60:	0f 85 ff 02 00 00    	jne    0x1407d0065
   1407cfd66:	48 8b 72 50          	mov    0x50(%rdx),%rsi
   1407cfd6a:	81 3e 6e 6f 74 65    	cmpl   $0x65746f6e,(%rsi)
   1407cfd70:	0f 85 ef 02 00 00    	jne    0x1407d0065
   1407cfd76:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407cfd7d:	00 
   1407cfd7e:	b8 16 00 00 00       	mov    $0x16,%eax
   1407cfd83:	bb 6e 00 00 00       	mov    $0x6e,%ebx
   1407cfd88:	b9 6c 01 00 00       	mov    $0x16c,%ecx
   1407cfd8d:	bf 1e 00 00 00       	mov    $0x1e,%edi
   1407cfd92:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cfd99:	00 
   1407cfd9a:	ff d6                	call   *%rsi
   1407cfd9c:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407cfda3:	00 
   1407cfda4:	4c 8b 86 80 00 00 00 	mov    0x80(%rsi),%r8
   1407cfdab:	4c 8b 8e 88 00 00 00 	mov    0x88(%rsi),%r9
   1407cfdb2:	89 04 24             	mov    %eax,(%rsp)
   1407cfdb5:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407cfdb9:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407cfdbd:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407cfdc1:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cfdc8:	00 
   1407cfdc9:	48 89 f3             	mov    %rsi,%rbx
   1407cfdcc:	4c 89 c1             	mov    %r8,%rcx
   1407cfdcf:	4c 89 cf             	mov    %r9,%rdi
   1407cfdd2:	48 8d 35 ba 70 0b 00 	lea    0xb70ba(%rip),%rsi        # 0x140886e93
   1407cfdd9:	41 b8 07 00 00 00    	mov    $0x7,%r8d
   1407cfddf:	41 b9 53 2d 10 00    	mov    $0x102d53,%r9d
   1407cfde5:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407cfdeb:	e8 10 e1 ff ff       	call   0x1407cdf00
   1407cfdf0:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407cfdf7:	00 
   1407cfdf8:	b8 16 00 00 00       	mov    $0x16,%eax
   1407cfdfd:	bb 8e 00 00 00       	mov    $0x8e,%ebx
   1407cfe02:	b9 6c 01 00 00       	mov    $0x16c,%ecx
   1407cfe07:	bf 12 00 00 00       	mov    $0x12,%edi
   1407cfe0c:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407cfe13:	00 
   1407cfe14:	ff d6                	call   *%rsi
   1407cfe16:	89 84 24 fc 00 00 00 	mov    %eax,0xfc(%rsp)
   1407cfe1d:	89 9c 24 f8 00 00 00 	mov    %ebx,0xf8(%rsp)
   1407cfe24:	89 8c 24 f4 00 00 00 	mov    %ecx,0xf4(%rsp)
   1407cfe2b:	89 bc 24 f0 00 00 00 	mov    %edi,0xf0(%rsp)
   1407cfe32:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407cfe39:	00 
   1407cfe3a:	48 8b be 90 00 00 00 	mov    0x90(%rsi),%rdi
   1407cfe41:	48 8b b6 98 00 00 00 	mov    0x98(%rsi),%rsi
   1407cfe48:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
   1407cfe4f:	00 
   1407cfe50:	48 8d 1d af 28 0c 00 	lea    0xc28af(%rip),%rbx        # 0x140892706
   1407cfe57:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407cfe5c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407cfe60:	e8 3b a8 89 ff       	call   0x14006a6a0
   1407cfe65:	8b b4 24 fc 00 00 00 	mov    0xfc(%rsp),%esi
   1407cfe6c:	89 34 24             	mov    %esi,(%rsp)
   1407cfe6f:	8b b4 24 f8 00 00 00 	mov    0xf8(%rsp),%esi
   1407cfe76:	89 74 24 04          	mov    %esi,0x4(%rsp)
   1407cfe7a:	8b b4 24 f4 00 00 00 	mov    0xf4(%rsp),%esi
   1407cfe81:	89 74 24 08          	mov    %esi,0x8(%rsp)
   1407cfe85:	8b b4 24 f0 00 00 00 	mov    0xf0(%rsp),%esi
   1407cfe8c:	89 74 24 0c          	mov    %esi,0xc(%rsp)
   1407cfe90:	48 89 c1             	mov    %rax,%rcx
   1407cfe93:	48 89 df             	mov    %rbx,%rdi
   1407cfe96:	48 8d 35 04 2a 0b 00 	lea    0xb2a04(%rip),%rsi        # 0x1408828a1
   1407cfe9d:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   1407cfea3:	41 b9 a3 86 71 00    	mov    $0x7186a3,%r9d
   1407cfea9:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407cfeaf:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407cfeb6:	00 
   1407cfeb7:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407cfebe:	00 
   1407cfebf:	90                   	nop
   1407cfec0:	e8 3b e0 ff ff       	call   0x1407cdf00
   1407cfec5:	48 8d b4 24 58 01 00 	lea    0x158(%rsp),%rsi
   1407cfecc:	00 
   1407cfecd:	4c 8b 84 24 48 01 00 	mov    0x148(%rsp),%r8
   1407cfed4:	00 
   1407cfed5:	45 0f 10 30          	movups (%r8),%xmm14
   1407cfed9:	44 0f 11 36          	movups %xmm14,(%rsi)
   1407cfedd:	45 0f 10 70 10       	movups 0x10(%r8),%xmm14
   1407cfee2:	44 0f 11 76 10       	movups %xmm14,0x10(%rsi)
   1407cfee7:	45 0f 10 70 20       	movups 0x20(%r8),%xmm14
   1407cfeec:	44 0f 11 76 20       	movups %xmm14,0x20(%rsi)
   1407cfef1:	45 0f 10 70 30       	movups 0x30(%r8),%xmm14
   1407cfef6:	44 0f 11 76 30       	movups %xmm14,0x30(%rsi)
   1407cfefb:	45 0f 10 70 40       	movups 0x40(%r8),%xmm14
   1407cff00:	44 0f 11 76 40       	movups %xmm14,0x40(%rsi)
   1407cff05:	45 0f 10 70 50       	movups 0x50(%r8),%xmm14
   1407cff0a:	44 0f 11 76 50       	movups %xmm14,0x50(%rsi)
   1407cff0f:	45 0f 10 70 60       	movups 0x60(%r8),%xmm14
   1407cff14:	44 0f 11 76 60       	movups %xmm14,0x60(%rsi)
   1407cff19:	45 0f 10 70 70       	movups 0x70(%r8),%xmm14
   1407cff1e:	44 0f 11 76 70       	movups %xmm14,0x70(%rsi)
   1407cff23:	45 0f 10 b0 80 00 00 	movups 0x80(%r8),%xmm14
   1407cff2a:	00 
   1407cff2b:	44 0f 11 b6 80 00 00 	movups %xmm14,0x80(%rsi)
   1407cff32:	00 
   1407cff33:	45 0f 10 b0 90 00 00 	movups 0x90(%r8),%xmm14
   1407cff3a:	00 
   1407cff3b:	44 0f 11 b6 90 00 00 	movups %xmm14,0x90(%rsi)
   1407cff42:	00 
   1407cff43:	45 0f 10 b0 98 00 00 	movups 0x98(%r8),%xmm14
   1407cff4a:	00 
   1407cff4b:	44 0f 11 b6 98 00 00 	movups %xmm14,0x98(%rsi)
   1407cff52:	00 
   1407cff53:	49 89 e0             	mov    %rsp,%r8
   1407cff56:	44 0f 10 36          	movups (%rsi),%xmm14
   1407cff5a:	45 0f 11 30          	movups %xmm14,(%r8)
   1407cff5e:	44 0f 10 76 10       	movups 0x10(%rsi),%xmm14
   1407cff63:	45 0f 11 70 10       	movups %xmm14,0x10(%r8)
   1407cff68:	44 0f 10 76 20       	movups 0x20(%rsi),%xmm14
   1407cff6d:	45 0f 11 70 20       	movups %xmm14,0x20(%r8)
   1407cff72:	44 0f 10 76 30       	movups 0x30(%rsi),%xmm14
   1407cff77:	45 0f 11 70 30       	movups %xmm14,0x30(%r8)
   1407cff7c:	44 0f 10 76 40       	movups 0x40(%rsi),%xmm14
   1407cff81:	45 0f 11 70 40       	movups %xmm14,0x40(%r8)
   1407cff86:	44 0f 10 76 50       	movups 0x50(%rsi),%xmm14
   1407cff8b:	45 0f 11 70 50       	movups %xmm14,0x50(%r8)
   1407cff90:	44 0f 10 76 60       	movups 0x60(%rsi),%xmm14
   1407cff95:	45 0f 11 70 60       	movups %xmm14,0x60(%r8)
   1407cff9a:	44 0f 10 76 70       	movups 0x70(%rsi),%xmm14
   1407cff9f:	45 0f 11 70 70       	movups %xmm14,0x70(%r8)
   1407cffa4:	44 0f 10 b6 80 00 00 	movups 0x80(%rsi),%xmm14
   1407cffab:	00 
   1407cffac:	45 0f 11 b0 80 00 00 	movups %xmm14,0x80(%r8)
   1407cffb3:	00 
   1407cffb4:	44 0f 10 b6 90 00 00 	movups 0x90(%rsi),%xmm14
   1407cffbb:	00 
   1407cffbc:	45 0f 11 b0 90 00 00 	movups %xmm14,0x90(%r8)
   1407cffc3:	00 
   1407cffc4:	44 0f 10 b6 98 00 00 	movups 0x98(%rsi),%xmm14
   1407cffcb:	00 
   1407cffcc:	45 0f 11 b0 98 00 00 	movups %xmm14,0x98(%r8)
   1407cffd3:	00 
   1407cffd4:	e8 a7 ab ff ff       	call   0x1407cab80
   1407cffd9:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   1407cffe0:	00 
   1407cffe1:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   1407cffe8:	00 
   1407cffe9:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407cfff0:	00 
   1407cfff1:	b8 16 00 00 00       	mov    $0x16,%eax
   1407cfff6:	bb a6 00 00 00       	mov    $0xa6,%ebx
   1407cfffb:	b9 6c 01 00 00       	mov    $0x16c,%ecx
   1407d0000:	bf 23 00 00 00       	mov    $0x23,%edi
   1407d0005:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d000c:	00 
   1407d000d:	ff d6                	call   *%rsi
   1407d000f:	89 04 24             	mov    %eax,(%rsp)
   1407d0012:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407d0016:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407d001a:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407d001e:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d0025:	00 
   1407d0026:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407d002d:	00 
   1407d002e:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   1407d0035:	00 
   1407d0036:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   1407d003d:	00 
   1407d003e:	48 8d 35 5c 28 0b 00 	lea    0xb285c(%rip),%rsi        # 0x1408828a1
   1407d0045:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   1407d004b:	41 b9 7f 57 31 00    	mov    $0x31577f,%r9d
   1407d0051:	41 ba 10 00 00 00    	mov    $0x10,%r10d
   1407d0057:	e8 a4 de ff ff       	call   0x1407cdf00
   1407d005c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407d0060:	e9 4a 01 00 00       	jmp    0x1407d01af
   1407d0065:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407d006c:	00 
   1407d006d:	b8 16 00 00 00       	mov    $0x16,%eax
   1407d0072:	bb 70 00 00 00       	mov    $0x70,%ebx
   1407d0077:	b9 6c 01 00 00       	mov    $0x16c,%ecx
   1407d007c:	bf 37 00 00 00       	mov    $0x37,%edi
   1407d0081:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d0088:	00 
   1407d0089:	ff d6                	call   *%rsi
   1407d008b:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407d0092:	00 
   1407d0093:	4c 8b 86 80 00 00 00 	mov    0x80(%rsi),%r8
   1407d009a:	4c 8b 8e 88 00 00 00 	mov    0x88(%rsi),%r9
   1407d00a1:	89 04 24             	mov    %eax,(%rsp)
   1407d00a4:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407d00a8:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407d00ac:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407d00b0:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d00b7:	00 
   1407d00b8:	48 89 f3             	mov    %rsi,%rbx
   1407d00bb:	4c 89 c1             	mov    %r8,%rcx
   1407d00be:	4c 89 cf             	mov    %r9,%rdi
   1407d00c1:	48 8d 35 cb 6d 0b 00 	lea    0xb6dcb(%rip),%rsi        # 0x140886e93
   1407d00c8:	41 b8 07 00 00 00    	mov    $0x7,%r8d
   1407d00ce:	41 b9 53 2d 10 00    	mov    $0x102d53,%r9d
   1407d00d4:	41 ba 10 00 00 00    	mov    $0x10,%r10d
   1407d00da:	e8 21 de ff ff       	call   0x1407cdf00
   1407d00df:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407d00e6:	00 
   1407d00e7:	b8 16 00 00 00       	mov    $0x16,%eax
   1407d00ec:	bb ae 00 00 00       	mov    $0xae,%ebx
   1407d00f1:	b9 6c 01 00 00       	mov    $0x16c,%ecx
   1407d00f6:	bf 14 00 00 00       	mov    $0x14,%edi
   1407d00fb:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d0102:	00 
   1407d0103:	ff d6                	call   *%rsi
   1407d0105:	89 84 24 fc 00 00 00 	mov    %eax,0xfc(%rsp)
   1407d010c:	89 9c 24 f8 00 00 00 	mov    %ebx,0xf8(%rsp)
   1407d0113:	89 8c 24 f4 00 00 00 	mov    %ecx,0xf4(%rsp)
   1407d011a:	89 bc 24 f0 00 00 00 	mov    %edi,0xf0(%rsp)
   1407d0121:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407d0128:	00 
   1407d0129:	48 8b be 90 00 00 00 	mov    0x90(%rsi),%rdi
   1407d0130:	48 8b b6 98 00 00 00 	mov    0x98(%rsi),%rsi
   1407d0137:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
   1407d013e:	00 
   1407d013f:	48 8d 1d c0 25 0c 00 	lea    0xc25c0(%rip),%rbx        # 0x140892706
   1407d0146:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407d014b:	e8 50 a5 89 ff       	call   0x14006a6a0
   1407d0150:	8b b4 24 fc 00 00 00 	mov    0xfc(%rsp),%esi
   1407d0157:	89 34 24             	mov    %esi,(%rsp)
   1407d015a:	8b b4 24 f8 00 00 00 	mov    0xf8(%rsp),%esi
   1407d0161:	89 74 24 04          	mov    %esi,0x4(%rsp)
   1407d0165:	8b b4 24 f4 00 00 00 	mov    0xf4(%rsp),%esi
   1407d016c:	89 74 24 08          	mov    %esi,0x8(%rsp)
   1407d0170:	8b b4 24 f0 00 00 00 	mov    0xf0(%rsp),%esi
   1407d0177:	89 74 24 0c          	mov    %esi,0xc(%rsp)
   1407d017b:	48 89 c1             	mov    %rax,%rcx
   1407d017e:	48 89 df             	mov    %rbx,%rdi
   1407d0181:	48 8d 35 19 27 0b 00 	lea    0xb2719(%rip),%rsi        # 0x1408828a1
   1407d0188:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   1407d018e:	41 b9 a3 86 71 00    	mov    $0x7186a3,%r9d
   1407d0194:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407d019a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d01a1:	00 
   1407d01a2:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407d01a9:	00 
   1407d01aa:	e8 51 dd ff ff       	call   0x1407cdf00
   1407d01af:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407d01b6:	00 
   1407d01b7:	b8 01 00 00 00       	mov    $0x1,%eax
   1407d01bc:	bb cd 00 00 00       	mov    $0xcd,%ebx
   1407d01c1:	b9 96 01 00 00       	mov    $0x196,%ecx
   1407d01c6:	bf 2a 00 00 00       	mov    $0x2a,%edi
   1407d01cb:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d01d2:	00 
   1407d01d3:	ff d6                	call   *%rsi
   1407d01d5:	89 fe                	mov    %edi,%esi
   1407d01d7:	41 b8 ff f4 ed 00    	mov    $0xedf4ff,%r8d
   1407d01dd:	89 cf                	mov    %ecx,%edi
   1407d01df:	89 d9                	mov    %ebx,%ecx
   1407d01e1:	89 c3                	mov    %eax,%ebx
   1407d01e3:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d01ea:	00 
   1407d01eb:	e8 f0 d7 ff ff       	call   0x1407cd9e0
   1407d01f0:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407d01f7:	00 
   1407d01f8:	b8 14 00 00 00       	mov    $0x14,%eax
   1407d01fd:	bb cd 00 00 00       	mov    $0xcd,%ebx
   1407d0202:	b9 70 01 00 00       	mov    $0x170,%ecx
   1407d0207:	bf 01 00 00 00       	mov    $0x1,%edi
   1407d020c:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d0213:	00 
   1407d0214:	ff d6                	call   *%rsi
   1407d0216:	89 fe                	mov    %edi,%esi
   1407d0218:	41 b8 f6 df ce 00    	mov    $0xcedff6,%r8d
   1407d021e:	89 cf                	mov    %ecx,%edi
   1407d0220:	89 d9                	mov    %ebx,%ecx
   1407d0222:	89 c3                	mov    %eax,%ebx
   1407d0224:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d022b:	00 
   1407d022c:	e8 af d7 ff ff       	call   0x1407cd9e0
   1407d0231:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407d0238:	00 
   1407d0239:	80 7e 10 00          	cmpb   $0x0,0x10(%rsi)
   1407d023d:	4c 8d 05 b6 c3 0c 00 	lea    0xcc3b6(%rip),%r8        # 0x14089c5fa
   1407d0244:	4c 8d 0d c3 c3 0c 00 	lea    0xcc3c3(%rip),%r9        # 0x14089c60e
   1407d024b:	4d 0f 45 c1          	cmovne %r9,%r8
   1407d024f:	48 83 7e 58 04       	cmpq   $0x4,0x58(%rsi)
   1407d0254:	75 22                	jne    0x1407d0278
   1407d0256:	4c 8b 4e 50          	mov    0x50(%rsi),%r9
   1407d025a:	41 81 39 6e 6f 74 65 	cmpl   $0x65746f6e,(%r9)
   1407d0261:	75 0e                	jne    0x1407d0271
   1407d0263:	b8 1b 00 00 00       	mov    $0x1b,%eax
   1407d0268:	4c 8d 05 8c 6c 0d 00 	lea    0xd6c8c(%rip),%r8        # 0x1408a6efb
   1407d026f:	eb 0c                	jmp    0x1407d027d
   1407d0271:	b8 14 00 00 00       	mov    $0x14,%eax
   1407d0276:	eb 05                	jmp    0x1407d027d
   1407d0278:	b8 14 00 00 00       	mov    $0x14,%eax
   1407d027d:	4c 89 84 24 40 01 00 	mov    %r8,0x140(%rsp)
   1407d0284:	00 
   1407d0285:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   1407d028c:	00 
   1407d028d:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407d0294:	00 
   1407d0295:	b8 16 00 00 00       	mov    $0x16,%eax
   1407d029a:	bb d5 00 00 00       	mov    $0xd5,%ebx
   1407d029f:	b9 4a 01 00 00       	mov    $0x14a,%ecx
   1407d02a4:	bf 19 00 00 00       	mov    $0x19,%edi
   1407d02a9:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d02b0:	00 
   1407d02b1:	ff d6                	call   *%rsi
   1407d02b3:	89 04 24             	mov    %eax,(%rsp)
   1407d02b6:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407d02ba:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407d02be:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407d02c2:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d02c9:	00 
   1407d02ca:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407d02d1:	00 
   1407d02d2:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
   1407d02d9:	00 
   1407d02da:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
   1407d02e1:	00 
   1407d02e2:	48 8d 35 d8 46 0b 00 	lea    0xb46d8(%rip),%rsi        # 0x1408849c1
   1407d02e9:	41 b8 06 00 00 00    	mov    $0x6,%r8d
   1407d02ef:	41 b9 9a 54 23 00    	mov    $0x23549a,%r9d
   1407d02f5:	41 ba 24 00 00 00    	mov    $0x24,%r10d
   1407d02fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407d0300:	e8 fb db ff ff       	call   0x1407cdf00
   1407d0305:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   1407d030c:	00 
   1407d030d:	b8 67 01 00 00       	mov    $0x167,%eax
   1407d0312:	bb d5 00 00 00       	mov    $0xd5,%ebx
   1407d0317:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   1407d031c:	bf 19 00 00 00       	mov    $0x19,%edi
   1407d0321:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   1407d0328:	00 
   1407d0329:	ff d6                	call   *%rsi
   1407d032b:	89 04 24             	mov    %eax,(%rsp)
   1407d032e:	89 5c 24 04          	mov    %ebx,0x4(%rsp)
   1407d0332:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   1407d0336:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   1407d033a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d0341:	00 
   1407d0342:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
   1407d0349:	00 
   1407d034a:	48 8d 0d f2 03 0b 00 	lea    0xb03f2(%rip),%rcx        # 0x140880743
   1407d0351:	bf 03 00 00 00       	mov    $0x3,%edi
   1407d0356:	48 8d 35 64 46 0b 00 	lea    0xb4664(%rip),%rsi        # 0x1408849c1
   1407d035d:	41 b8 06 00 00 00    	mov    $0x6,%r8d
   1407d0363:	41 b9 9a 54 23 00    	mov    $0x23549a,%r9d
   1407d0369:	41 ba 25 00 00 00    	mov    $0x25,%r10d
   1407d036f:	e8 8c db ff ff       	call   0x1407cdf00
   1407d0374:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407d0377:	f2 0f 10 0d a1 5b 40 	movsd  0x405ba1(%rip),%xmm1        # 0x140bd5f20
   1407d037e:	00 
   1407d037f:	66 0f ef c1          	pxor   %xmm1,%xmm0
   1407d0383:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
   1407d038a:	00 
   1407d038b:	4c 8b 86 18 01 00 00 	mov    0x118(%rsi),%r8
   1407d0392:	0f 57 d2             	xorps  %xmm2,%xmm2
   1407d0395:	f2 49 0f 2a d0       	cvtsi2sd %r8,%xmm2
   1407d039a:	f2 0f 10 1d 5e 5b 40 	movsd  0x405b5e(%rip),%xmm3        # 0x140bd5f00
   1407d03a1:	00 
   1407d03a2:	f2 0f 5e d3          	divsd  %xmm3,%xmm2
   1407d03a6:	f2 0f 10 1d 2a 5a 40 	movsd  0x405a2a(%rip),%xmm3        # 0x140bd5dd8
   1407d03ad:	00 
   1407d03ae:	f2 0f 5d da          	minsd  %xmm2,%xmm3
   1407d03b2:	f2 0f 10 15 1e 5a 40 	movsd  0x405a1e(%rip),%xmm2        # 0x140bd5dd8
   1407d03b9:	00 
   1407d03ba:	0f 10 e3             	movups %xmm3,%xmm4
   1407d03bd:	f2 0f 5d da          	minsd  %xmm2,%xmm3
   1407d03c1:	66 0f eb e3          	por    %xmm3,%xmm4
   1407d03c5:	66 0f ef e1          	pxor   %xmm1,%xmm4
   1407d03c9:	0f 10 d0             	movups %xmm0,%xmm2
   1407d03cc:	f2 0f 5d c4          	minsd  %xmm4,%xmm0
   1407d03d0:	0f 10 d8             	movups %xmm0,%xmm3
   1407d03d3:	f2 0f 5d c2          	minsd  %xmm2,%xmm0
   1407d03d7:	66 0f eb d8          	por    %xmm0,%xmm3
   1407d03db:	f2 0f 10 86 b8 00 00 	movsd  0xb8(%rsi),%xmm0
   1407d03e2:	00 
   1407d03e3:	f2 0f 10 15 0d 5a 40 	movsd  0x405a0d(%rip),%xmm2        # 0x140bd5df8
   1407d03ea:	00 
   1407d03eb:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   1407d03ef:	66 48 0f 7e d1       	movq   %xmm2,%rcx
   1407d03f4:	49 89 c8             	mov    %rcx,%r8
   1407d03f7:	49 c1 e8 34          	shr    $0x34,%r8
   1407d03fb:	41 81 e0 ff 07 00 00 	and    $0x7ff,%r8d
   1407d0402:	66 0f ef d9          	pxor   %xmm1,%xmm3
   1407d0406:	90                   	nop
   1407d0407:	49 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8
   1407d040e:	73 30                	jae    0x1407d0440
   1407d0410:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
   1407d0417:	00 00 80 
   1407d041a:	48 21 ca             	and    %rcx,%rdx
   1407d041d:	49 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%r9
   1407d0424:	00 f0 3f 
   1407d0427:	49 09 d1             	or     %rdx,%r9
   1407d042a:	49 81 f8 fe 03 00 00 	cmp    $0x3fe,%r8
   1407d0431:	49 0f 44 d1          	cmove  %r9,%rdx
   1407d0435:	48 89 c8             	mov    %rcx,%rax
   1407d0438:	49 89 d1             	mov    %rdx,%r9
   1407d043b:	eb 44                	jmp    0x1407d0481
   1407d043d:	0f 1f 00             	nopl   (%rax)
   1407d0440:	49 81 f8 33 04 00 00 	cmp    $0x433,%r8
   1407d0447:	73 32                	jae    0x1407d047b
   1407d0449:	49 8d 90 01 fc ff ff 	lea    -0x3ff(%r8),%rdx
   1407d0450:	48 89 c8             	mov    %rcx,%rax
   1407d0453:	48 89 d1             	mov    %rdx,%rcx
   1407d0456:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407d045d:	00 08 00 
   1407d0460:	49 d3 e9             	shr    %cl,%r9
   1407d0463:	49 01 c1             	add    %rax,%r9
   1407d0466:	49 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%r10
   1407d046d:	ff 0f 00 
   1407d0470:	49 d3 ea             	shr    %cl,%r10
   1407d0473:	49 f7 d2             	not    %r10
   1407d0476:	4d 21 d1             	and    %r10,%r9
   1407d0479:	eb 06                	jmp    0x1407d0481
   1407d047b:	48 89 c8             	mov    %rcx,%rax
   1407d047e:	49 89 c1             	mov    %rax,%r9
   1407d0481:	f2 0f 10 0d 57 59 40 	movsd  0x405957(%rip),%xmm1        # 0x140bd5de0
   1407d0488:	00 
   1407d0489:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407d048d:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407d0492:	48 89 ca             	mov    %rcx,%rdx
   1407d0495:	48 c1 ea 34          	shr    $0x34,%rdx
   1407d0499:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407d049f:	90                   	nop
   1407d04a0:	90                   	nop
   1407d04a1:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d04a8:	73 36                	jae    0x1407d04e0
   1407d04aa:	49 ba 00 00 00 00 00 	movabs $0x8000000000000000,%r10
   1407d04b1:	00 00 80 
   1407d04b4:	4c 21 d1             	and    %r10,%rcx
   1407d04b7:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407d04be:	00 f0 3f 
   1407d04c1:	49 09 cb             	or     %rcx,%r11
   1407d04c4:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407d04cb:	49 0f 44 cb          	cmove  %r11,%rcx
   1407d04cf:	49 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8
   1407d04d6:	49 89 ca             	mov    %rcx,%r10
   1407d04d9:	eb 51                	jmp    0x1407d052c
   1407d04db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407d04e0:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407d04e7:	73 39                	jae    0x1407d0522
   1407d04e9:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407d04f0:	48 89 cb             	mov    %rcx,%rbx
   1407d04f3:	48 89 d1             	mov    %rdx,%rcx
   1407d04f6:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407d04fd:	00 08 00 
   1407d0500:	49 d3 ea             	shr    %cl,%r10
   1407d0503:	49 01 da             	add    %rbx,%r10
   1407d0506:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407d050d:	ff 0f 00 
   1407d0510:	49 d3 eb             	shr    %cl,%r11
   1407d0513:	49 f7 d3             	not    %r11
   1407d0516:	4d 21 da             	and    %r11,%r10
   1407d0519:	49 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8
   1407d0520:	eb 0a                	jmp    0x1407d052c
   1407d0522:	49 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8
   1407d0529:	49 89 ca             	mov    %rcx,%r10
   1407d052c:	90                   	nop
   1407d052d:	73 31                	jae    0x1407d0560
   1407d052f:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
   1407d0536:	00 00 80 
   1407d0539:	48 21 d0             	and    %rdx,%rax
   1407d053c:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407d0543:	00 f0 3f 
   1407d0546:	49 09 c3             	or     %rax,%r11
   1407d0549:	49 81 f8 fe 03 00 00 	cmp    $0x3fe,%r8
   1407d0550:	49 0f 44 c3          	cmove  %r11,%rax
   1407d0554:	48 89 c2             	mov    %rax,%rdx
   1407d0557:	eb 3f                	jmp    0x1407d0598
   1407d0559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407d0560:	49 81 f8 33 04 00 00 	cmp    $0x433,%r8
   1407d0567:	73 2c                	jae    0x1407d0595
   1407d0569:	49 8d 88 01 fc ff ff 	lea    -0x3ff(%r8),%rcx
   1407d0570:	48 ba 00 00 00 00 00 	movabs $0x8000000000000,%rdx
   1407d0577:	00 08 00 
   1407d057a:	48 d3 ea             	shr    %cl,%rdx
   1407d057d:	48 01 c2             	add    %rax,%rdx
   1407d0580:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407d0587:	ff 0f 00 
   1407d058a:	49 d3 eb             	shr    %cl,%r11
   1407d058d:	49 f7 d3             	not    %r11
   1407d0590:	4c 21 da             	and    %r11,%rdx
   1407d0593:	eb 03                	jmp    0x1407d0598
   1407d0595:	48 89 c2             	mov    %rax,%rdx
   1407d0598:	f2 0f 10 0d a8 58 40 	movsd  0x4058a8(%rip),%xmm1        # 0x140bd5e48
   1407d059f:	00 
   1407d05a0:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407d05a4:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   1407d05a9:	49 89 cb             	mov    %rcx,%r11
   1407d05ac:	49 c1 eb 34          	shr    $0x34,%r11
   1407d05b0:	41 81 e3 ff 07 00 00 	and    $0x7ff,%r11d
   1407d05b7:	90                   	nop
   1407d05b8:	90                   	nop
   1407d05b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407d05c0:	49 81 fb ff 03 00 00 	cmp    $0x3ff,%r11
   1407d05c7:	73 2a                	jae    0x1407d05f3
   1407d05c9:	49 bc 00 00 00 00 00 	movabs $0x8000000000000000,%r12
   1407d05d0:	00 00 80 
   1407d05d3:	4c 21 e1             	and    %r12,%rcx
   1407d05d6:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407d05dd:	00 f0 3f 
   1407d05e0:	49 09 cd             	or     %rcx,%r13
   1407d05e3:	49 81 fb fe 03 00 00 	cmp    $0x3fe,%r11
   1407d05ea:	49 0f 44 cd          	cmove  %r13,%rcx
   1407d05ee:	49 89 cc             	mov    %rcx,%r12
   1407d05f1:	eb 3e                	jmp    0x1407d0631
   1407d05f3:	49 81 fb 33 04 00 00 	cmp    $0x433,%r11
   1407d05fa:	73 32                	jae    0x1407d062e
   1407d05fc:	49 81 c3 01 fc ff ff 	add    $0xfffffffffffffc01,%r11
   1407d0603:	48 89 c8             	mov    %rcx,%rax
   1407d0606:	4c 89 d9             	mov    %r11,%rcx
   1407d0609:	49 bc 00 00 00 00 00 	movabs $0x8000000000000,%r12
   1407d0610:	00 08 00 
   1407d0613:	49 d3 ec             	shr    %cl,%r12
   1407d0616:	49 01 c4             	add    %rax,%r12
   1407d0619:	49 bd ff ff ff ff ff 	movabs $0xfffffffffffff,%r13
   1407d0620:	ff 0f 00 
   1407d0623:	49 d3 ed             	shr    %cl,%r13
   1407d0626:	49 f7 d5             	not    %r13
   1407d0629:	4d 21 ec             	and    %r13,%r12
   1407d062c:	eb 03                	jmp    0x1407d0631
   1407d062e:	49 89 cc             	mov    %rcx,%r12
   1407d0631:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d0636:	49 89 cb             	mov    %rcx,%r11
   1407d0639:	49 c1 eb 34          	shr    $0x34,%r11
   1407d063d:	41 81 e3 ff 07 00 00 	and    $0x7ff,%r11d
   1407d0644:	90                   	nop
   1407d0645:	90                   	nop
   1407d0646:	49 81 fb ff 03 00 00 	cmp    $0x3ff,%r11
   1407d064d:	73 31                	jae    0x1407d0680
   1407d064f:	49 bd 00 00 00 00 00 	movabs $0x8000000000000000,%r13
   1407d0656:	00 00 80 
   1407d0659:	4c 21 e9             	and    %r13,%rcx
   1407d065c:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
   1407d0663:	00 f0 3f 
   1407d0666:	49 09 cd             	or     %rcx,%r13
   1407d0669:	49 81 fb fe 03 00 00 	cmp    $0x3fe,%r11
   1407d0670:	49 0f 44 cd          	cmove  %r13,%rcx
   1407d0674:	49 89 cd             	mov    %rcx,%r13
   1407d0677:	eb 45                	jmp    0x1407d06be
   1407d0679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407d0680:	49 81 fb 33 04 00 00 	cmp    $0x433,%r11
   1407d0687:	73 32                	jae    0x1407d06bb
   1407d0689:	49 81 c3 01 fc ff ff 	add    $0xfffffffffffffc01,%r11
   1407d0690:	48 89 c8             	mov    %rcx,%rax
   1407d0693:	4c 89 d9             	mov    %r11,%rcx
   1407d0696:	49 bd 00 00 00 00 00 	movabs $0x8000000000000,%r13
   1407d069d:	00 08 00 
   1407d06a0:	49 d3 ed             	shr    %cl,%r13
   1407d06a3:	49 01 c5             	add    %rax,%r13
   1407d06a6:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
   1407d06ad:	ff 0f 00 
   1407d06b0:	49 d3 ef             	shr    %cl,%r15
   1407d06b3:	49 f7 d7             	not    %r15
   1407d06b6:	4d 21 fd             	and    %r15,%r13
   1407d06b9:	eb 03                	jmp    0x1407d06be
   1407d06bb:	49 89 cd             	mov    %rcx,%r13
   1407d06be:	8b 8e c4 00 00 00    	mov    0xc4(%rsi),%ecx
   1407d06c4:	44 8b 9e c0 00 00 00 	mov    0xc0(%rsi),%r11d
   1407d06cb:	66 49 0f 6e c1       	movq   %r9,%xmm0
   1407d06d0:	f2 0f 2c d8          	cvttsd2si %xmm0,%ebx
   1407d06d4:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407d06d9:	f2 44 0f 2c c8       	cvttsd2si %xmm0,%r9d
   1407d06de:	89 ce                	mov    %ecx,%esi
   1407d06e0:	44 29 c9             	sub    %r9d,%ecx
   1407d06e3:	66 48 0f 6e c2       	movq   %rdx,%xmm0
   1407d06e8:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407d06ec:	66 49 0f 6e c4       	movq   %r12,%xmm0
   1407d06f1:	f2 44 0f 2c c8       	cvttsd2si %xmm0,%r9d
   1407d06f6:	45 29 cb             	sub    %r9d,%r11d
   1407d06f9:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407d06fc:	f2 41 0f 2a c3       	cvtsi2sd %r11d,%xmm0
   1407d0701:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
   1407d0705:	f2 44 0f 2c c8       	cvttsd2si %xmm0,%r9d
   1407d070a:	42 8d 3c 0a          	lea    (%rdx,%r9,1),%edi
   1407d070e:	66 49 0f 6e c5       	movq   %r13,%xmm0
   1407d0713:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407d0717:	29 d6                	sub    %edx,%esi
   1407d0719:	90                   	nop
   1407d071a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   1407d0721:	00 
   1407d0722:	41 b8 eb 63 25 00    	mov    $0x2563eb,%r8d
   1407d0728:	e8 b3 d2 ff ff       	call   0x1407cd9e0
   1407d072d:	b8 48 00 00 00       	mov    $0x48,%eax
   1407d0732:	48 8d 1d 0f 05 af 00 	lea    0xaf050f(%rip),%rbx        # 0x1412c0c48
   1407d0739:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d073e:	66 90                	xchg   %ax,%ax
   1407d0740:	e8 fb 44 85 ff       	call   0x140024c40
   1407d0745:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
   1407d074c:	00 
   1407d074d:	48 89 10             	mov    %rdx,(%rax)
   1407d0750:	44 0f 11 78 08       	movups %xmm15,0x8(%rax)
   1407d0755:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
   1407d075c:	00 
   1407d075d:	4c 63 8a c0 00 00 00 	movslq 0xc0(%rdx),%r9
   1407d0764:	4c 89 48 18          	mov    %r9,0x18(%rax)
   1407d0768:	48 63 92 c4 00 00 00 	movslq 0xc4(%rdx),%rdx
   1407d076f:	48 89 50 20          	mov    %rdx,0x20(%rax)
   1407d0773:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407d077a:	00 
   1407d077b:	48 89 50 28          	mov    %rdx,0x28(%rax)
   1407d077f:	44 0f 11 78 30       	movups %xmm15,0x30(%rax)
   1407d0784:	48 c7 40 40 20 00 cc 	movq   $0xcc0020,0x40(%rax)
   1407d078b:	00 
   1407d078c:	48 8b 15 c5 a7 21 04 	mov    0x421a7c5(%rip),%rdx        # 0x1449eaf58
   1407d0793:	48 8d 1d 3d 41 0b 00 	lea    0xb413d(%rip),%rbx        # 0x1408848d7
   1407d079a:	b9 06 00 00 00       	mov    $0x6,%ecx
   1407d079f:	48 89 c7             	mov    %rax,%rdi
   1407d07a2:	be 09 00 00 00       	mov    $0x9,%esi
   1407d07a7:	41 89 f0             	mov    %esi,%r8d
   1407d07aa:	48 89 d0             	mov    %rdx,%rax
   1407d07ad:	e8 ee 91 fc ff       	call   0x1407999a0
   1407d07b2:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d07b7:	48 8d 1d 8a e0 ae 00 	lea    0xaee08a(%rip),%rbx        # 0x1412be848
   1407d07be:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d07c3:	e8 98 38 85 ff       	call   0x140024060
   1407d07c8:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407d07cf:	00 
   1407d07d0:	48 89 10             	mov    %rdx,(%rax)
   1407d07d3:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
   1407d07da:	00 
   1407d07db:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d07df:	48 8b 15 72 a7 21 04 	mov    0x421a772(%rip),%rdx        # 0x1449eaf58
   1407d07e6:	48 8d 1d aa ef 0b 00 	lea    0xbefaa(%rip),%rbx        # 0x14088f797
   1407d07ed:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d07f2:	48 89 c7             	mov    %rax,%rdi
   1407d07f5:	be 02 00 00 00       	mov    $0x2,%esi
   1407d07fa:	41 89 f0             	mov    %esi,%r8d
   1407d07fd:	48 89 d0             	mov    %rdx,%rax
   1407d0800:	e8 9b 91 fc ff       	call   0x1407999a0
   1407d0805:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d080a:	48 8d 1d 5f cd ae 00 	lea    0xaecd5f(%rip),%rbx        # 0x1412bd570
   1407d0811:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d0816:	e8 65 35 85 ff       	call   0x140023d80
   1407d081b:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
   1407d0822:	00 
   1407d0823:	48 89 10             	mov    %rdx,(%rax)
   1407d0826:	48 8b 15 2b a7 21 04 	mov    0x421a72b(%rip),%rdx        # 0x1449eaf58
   1407d082d:	48 8d 1d 57 ef 0b 00 	lea    0xbef57(%rip),%rbx        # 0x14088f78b
   1407d0834:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d0839:	48 89 c7             	mov    %rax,%rdi
   1407d083c:	be 01 00 00 00       	mov    $0x1,%esi
   1407d0841:	41 89 f0             	mov    %esi,%r8d
   1407d0844:	48 89 d0             	mov    %rdx,%rax
   1407d0847:	e8 54 91 fc ff       	call   0x1407999a0
   1407d084c:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d0851:	48 8d 1d 18 cd ae 00 	lea    0xaecd18(%rip),%rbx        # 0x1412bd570
   1407d0858:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d085d:	0f 1f 00             	nopl   (%rax)
   1407d0860:	e8 1b 35 85 ff       	call   0x140023d80
   1407d0865:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
   1407d086c:	00 
   1407d086d:	48 89 10             	mov    %rdx,(%rax)
   1407d0870:	48 8b 15 e1 a6 21 04 	mov    0x421a6e1(%rip),%rdx        # 0x1449eaf58
   1407d0877:	48 8d 1d 0a 85 0b 00 	lea    0xb850a(%rip),%rbx        # 0x140888d88
   1407d087e:	b9 08 00 00 00       	mov    $0x8,%ecx
   1407d0883:	48 89 c7             	mov    %rax,%rdi
   1407d0886:	be 01 00 00 00       	mov    $0x1,%esi
   1407d088b:	41 89 f0             	mov    %esi,%r8d
   1407d088e:	48 89 d0             	mov    %rdx,%rax
   1407d0891:	e8 0a 91 fc ff       	call   0x1407999a0
   1407d0896:	c6 84 24 af 00 00 00 	movb   $0x0,0xaf(%rsp)
   1407d089d:	00 
   1407d089e:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   1407d08a5:	00 
   1407d08a6:	4c 8b 0a             	mov    (%rdx),%r9
   1407d08a9:	41 ff d1             	call   *%r9
   1407d08ac:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
   1407d08b3:	5d                   	pop    %rbp
   1407d08b4:	c3                   	ret
   1407d08b5:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
   1407d08bc:	5d                   	pop    %rbp
   1407d08bd:	c3                   	ret
   1407d08be:	66 90                	xchg   %ax,%ax
   1407d08c0:	e8 bb dc 87 ff       	call   0x14004e580
   1407d08c5:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
   1407d08cc:	5d                   	pop    %rbp
   1407d08cd:	c3                   	ret
   1407d08ce:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1407d08d3:	e8 68 ba 8b ff       	call   0x14008c340
   1407d08d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1407d08dd:	0f 1f 00             	nopl   (%rax)
   1407d08e0:	e9 fb db ff ff       	jmp    0x1407ce4e0
   1407d08e5:	cc                   	int3
   1407d08e6:	cc                   	int3
   1407d08e7:	cc                   	int3
   1407d08e8:	cc                   	int3
   1407d08e9:	cc                   	int3
   1407d08ea:	cc                   	int3
   1407d08eb:	cc                   	int3
   1407d08ec:	cc                   	int3
   1407d08ed:	cc                   	int3
   1407d08ee:	cc                   	int3
   1407d08ef:	cc                   	int3
   1407d08f0:	cc                   	int3
   1407d08f1:	cc                   	int3
   1407d08f2:	cc                   	int3
   1407d08f3:	cc                   	int3
   1407d08f4:	cc                   	int3
   1407d08f5:	cc                   	int3
   1407d08f6:	cc                   	int3
   1407d08f7:	cc                   	int3
   1407d08f8:	cc                   	int3
   1407d08f9:	cc                   	int3
   1407d08fa:	cc                   	int3
   1407d08fb:	cc                   	int3
   1407d08fc:	cc                   	int3
   1407d08fd:	cc                   	int3
   1407d08fe:	cc                   	int3
   1407d08ff:	cc                   	int3

# main.toastProc @ 0x1407d0900
   1407d0900:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407d0904:	0f 86 41 05 00 00    	jbe    0x1407d0e4b
   1407d090a:	55                   	push   %rbp
   1407d090b:	48 89 e5             	mov    %rsp,%rbp
   1407d090e:	48 83 ec 58          	sub    $0x58,%rsp
   1407d0912:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   1407d0917:	89 5c 24 70          	mov    %ebx,0x70(%rsp)
   1407d091b:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   1407d0920:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
   1407d0927:	00 
   1407d0928:	48 8b 1d 99 9b 27 04 	mov    0x4279b99(%rip),%rbx        # 0x144a4a4c8
   1407d092f:	48 89 c1             	mov    %rax,%rcx
   1407d0932:	48 8d 05 37 f9 b1 00 	lea    0xb1f937(%rip),%rax        # 0x1412f0270
   1407d0939:	e8 82 b4 83 ff       	call   0x14000bdc0
   1407d093e:	48 8b 00             	mov    (%rax),%rax
   1407d0941:	8b 54 24 70          	mov    0x70(%rsp),%edx
   1407d0945:	83 fa 10             	cmp    $0x10,%edx
   1407d0948:	0f 87 14 01 00 00    	ja     0x1407d0a62
   1407d094e:	83 fa 02             	cmp    $0x2,%edx
   1407d0951:	0f 85 97 00 00 00    	jne    0x1407d09ee
   1407d0957:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   1407d095c:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d0961:	48 8d 1d e0 de ae 00 	lea    0xaedee0(%rip),%rbx        # 0x1412be848
   1407d0968:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d096d:	e8 ee 36 85 ff       	call   0x140024060
   1407d0972:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
   1407d0977:	48 89 10             	mov    %rdx,(%rax)
   1407d097a:	48 c7 40 08 01 00 00 	movq   $0x1,0x8(%rax)
   1407d0981:	00 
   1407d0982:	48 8b 15 bf a5 21 04 	mov    0x421a5bf(%rip),%rdx        # 0x1449eaf48
   1407d0989:	48 8d 1d ef a2 0b 00 	lea    0xba2ef(%rip),%rbx        # 0x14088ac7f
   1407d0990:	b9 09 00 00 00       	mov    $0x9,%ecx
   1407d0995:	48 89 c7             	mov    %rax,%rdi
   1407d0998:	be 02 00 00 00       	mov    $0x2,%esi
   1407d099d:	41 89 f0             	mov    %esi,%r8d
   1407d09a0:	48 89 d0             	mov    %rdx,%rax
   1407d09a3:	e8 f8 8f fc ff       	call   0x1407999a0
   1407d09a8:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d09ad:	48 85 d2             	test   %rdx,%rdx
   1407d09b0:	0f 84 46 03 00 00    	je     0x1407d0cfc
   1407d09b6:	48 8b 1d 0b 9b 27 04 	mov    0x4279b0b(%rip),%rbx        # 0x144a4a4c8
   1407d09bd:	48 8d 05 ac f8 b1 00 	lea    0xb1f8ac(%rip),%rax        # 0x1412f0270
   1407d09c4:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   1407d09c9:	e8 72 be 83 ff       	call   0x14000c840
   1407d09ce:	48 8b 05 b3 d8 27 04 	mov    0x427d8b3(%rip),%rax        # 0x144a4e288
   1407d09d5:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d09da:	48 8b 12             	mov    (%rdx),%rdx
   1407d09dd:	48 89 c6             	mov    %rax,%rsi
   1407d09e0:	48 8b 1d a9 d8 27 04 	mov    0x427d8a9(%rip),%rbx        # 0x144a4e290
   1407d09e7:	31 ff                	xor    %edi,%edi
   1407d09e9:	e9 32 03 00 00       	jmp    0x1407d0d20
   1407d09ee:	83 fa 0f             	cmp    $0xf,%edx
   1407d09f1:	75 1a                	jne    0x1407d0a0d
   1407d09f3:	48 85 c0             	test   %rax,%rax
   1407d09f6:	0f 84 97 02 00 00    	je     0x1407d0c93
   1407d09fc:	0f 1f 40 00          	nopl   0x0(%rax)
   1407d0a00:	e8 db da ff ff       	call   0x1407ce4e0
   1407d0a05:	31 c0                	xor    %eax,%eax
   1407d0a07:	48 83 c4 58          	add    $0x58,%rsp
   1407d0a0b:	5d                   	pop    %rbp
   1407d0a0c:	c3                   	ret
   1407d0a0d:	83 fa 10             	cmp    $0x10,%edx
   1407d0a10:	0f 85 7d 02 00 00    	jne    0x1407d0c93
   1407d0a16:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d0a1b:	48 8d 1d 4e cb ae 00 	lea    0xaecb4e(%rip),%rbx        # 0x1412bd570
   1407d0a22:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d0a27:	e8 54 33 85 ff       	call   0x140023d80
   1407d0a2c:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
   1407d0a31:	48 89 10             	mov    %rdx,(%rax)
   1407d0a34:	48 8b 15 0d a5 21 04 	mov    0x421a50d(%rip),%rdx        # 0x1449eaf48
   1407d0a3b:	48 8d 1d 43 09 0c 00 	lea    0xc0943(%rip),%rbx        # 0x140891385
   1407d0a42:	b9 0d 00 00 00       	mov    $0xd,%ecx
   1407d0a47:	48 89 c7             	mov    %rax,%rdi
   1407d0a4a:	be 01 00 00 00       	mov    $0x1,%esi
   1407d0a4f:	41 89 f0             	mov    %esi,%r8d
   1407d0a52:	48 89 d0             	mov    %rdx,%rax
   1407d0a55:	e8 46 8f fc ff       	call   0x1407999a0
   1407d0a5a:	31 c0                	xor    %eax,%eax
   1407d0a5c:	48 83 c4 58          	add    $0x58,%rsp
   1407d0a60:	5d                   	pop    %rbp
   1407d0a61:	c3                   	ret
   1407d0a62:	83 fa 21             	cmp    $0x21,%edx
   1407d0a65:	77 25                	ja     0x1407d0a8c
   1407d0a67:	83 fa 14             	cmp    $0x14,%edx
   1407d0a6a:	74 15                	je     0x1407d0a81
   1407d0a6c:	83 fa 21             	cmp    $0x21,%edx
   1407d0a6f:	0f 85 1e 02 00 00    	jne    0x1407d0c93
   1407d0a75:	b8 03 00 00 00       	mov    $0x3,%eax
   1407d0a7a:	48 83 c4 58          	add    $0x58,%rsp
   1407d0a7e:	5d                   	pop    %rbp
   1407d0a7f:	90                   	nop
   1407d0a80:	c3                   	ret
   1407d0a81:	b8 01 00 00 00       	mov    $0x1,%eax
   1407d0a86:	48 83 c4 58          	add    $0x58,%rsp
   1407d0a8a:	5d                   	pop    %rbp
   1407d0a8b:	c3                   	ret
   1407d0a8c:	81 fa 13 01 00 00    	cmp    $0x113,%edx
   1407d0a92:	75 12                	jne    0x1407d0aa6
   1407d0a94:	48 85 c0             	test   %rax,%rax
   1407d0a97:	74 05                	je     0x1407d0a9e
   1407d0a99:	e8 62 c8 ff ff       	call   0x1407cd300
   1407d0a9e:	31 c0                	xor    %eax,%eax
   1407d0aa0:	48 83 c4 58          	add    $0x58,%rsp
   1407d0aa4:	5d                   	pop    %rbp
   1407d0aa5:	c3                   	ret
   1407d0aa6:	81 fa 02 02 00 00    	cmp    $0x202,%edx
   1407d0aac:	0f 85 e1 01 00 00    	jne    0x1407d0c93
   1407d0ab2:	48 85 c0             	test   %rax,%rax
   1407d0ab5:	0f 84 d0 01 00 00    	je     0x1407d0c8b
   1407d0abb:	f2 0f 10 05 a5 53 40 	movsd  0x4053a5(%rip),%xmm0        # 0x140bd5e68
   1407d0ac2:	00 
   1407d0ac3:	f2 0f 59 80 b8 00 00 	mulsd  0xb8(%rax),%xmm0
   1407d0aca:	00 
   1407d0acb:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d0ad0:	48 89 ca             	mov    %rcx,%rdx
   1407d0ad3:	48 c1 ea 34          	shr    $0x34,%rdx
   1407d0ad7:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407d0add:	90                   	nop
   1407d0ade:	66 90                	xchg   %ax,%ax
   1407d0ae0:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d0ae7:	73 2a                	jae    0x1407d0b13
   1407d0ae9:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407d0af0:	00 00 80 
   1407d0af3:	48 21 f1             	and    %rsi,%rcx
   1407d0af6:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407d0afd:	00 f0 3f 
   1407d0b00:	48 09 cf             	or     %rcx,%rdi
   1407d0b03:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407d0b0a:	48 0f 44 cf          	cmove  %rdi,%rcx
   1407d0b0e:	48 89 ce             	mov    %rcx,%rsi
   1407d0b11:	eb 3e                	jmp    0x1407d0b51
   1407d0b13:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407d0b1a:	73 32                	jae    0x1407d0b4e
   1407d0b1c:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407d0b23:	48 89 cb             	mov    %rcx,%rbx
   1407d0b26:	48 89 d1             	mov    %rdx,%rcx
   1407d0b29:	48 be 00 00 00 00 00 	movabs $0x8000000000000,%rsi
   1407d0b30:	00 08 00 
   1407d0b33:	48 d3 ee             	shr    %cl,%rsi
   1407d0b36:	48 01 de             	add    %rbx,%rsi
   1407d0b39:	48 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%rdi
   1407d0b40:	ff 0f 00 
   1407d0b43:	48 d3 ef             	shr    %cl,%rdi
   1407d0b46:	48 f7 d7             	not    %rdi
   1407d0b49:	48 21 fe             	and    %rdi,%rsi
   1407d0b4c:	eb 03                	jmp    0x1407d0b51
   1407d0b4e:	48 89 ce             	mov    %rcx,%rsi
   1407d0b51:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407d0b58:	00 
   1407d0b59:	48 0f bf fa          	movswq %dx,%rdi
   1407d0b5d:	44 8b 80 c0 00 00 00 	mov    0xc0(%rax),%r8d
   1407d0b64:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407d0b69:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407d0b6d:	41 29 f0             	sub    %esi,%r8d
   1407d0b70:	90                   	nop
   1407d0b71:	44 39 c7             	cmp    %r8d,%edi
   1407d0b74:	0f 8c b0 00 00 00    	jl     0x1407d0c2a
   1407d0b7a:	f2 0f 10 05 ee 52 40 	movsd  0x4052ee(%rip),%xmm0        # 0x140bd5e70
   1407d0b81:	00 
   1407d0b82:	f2 0f 59 80 b8 00 00 	mulsd  0xb8(%rax),%xmm0
   1407d0b89:	00 
   1407d0b8a:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d0b8f:	48 89 ce             	mov    %rcx,%rsi
   1407d0b92:	48 c1 ee 34          	shr    $0x34,%rsi
   1407d0b96:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407d0b9c:	90                   	nop
   1407d0b9d:	0f 1f 00             	nopl   (%rax)
   1407d0ba0:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407d0ba7:	73 2a                	jae    0x1407d0bd3
   1407d0ba9:	48 bf 00 00 00 00 00 	movabs $0x8000000000000000,%rdi
   1407d0bb0:	00 00 80 
   1407d0bb3:	48 21 f9             	and    %rdi,%rcx
   1407d0bb6:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407d0bbd:	00 f0 3f 
   1407d0bc0:	48 09 cf             	or     %rcx,%rdi
   1407d0bc3:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407d0bca:	48 0f 44 cf          	cmove  %rdi,%rcx
   1407d0bce:	48 89 cf             	mov    %rcx,%rdi
   1407d0bd1:	eb 3e                	jmp    0x1407d0c11
   1407d0bd3:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407d0bda:	73 32                	jae    0x1407d0c0e
   1407d0bdc:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407d0be3:	48 89 cb             	mov    %rcx,%rbx
   1407d0be6:	48 89 f1             	mov    %rsi,%rcx
   1407d0be9:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407d0bf0:	00 08 00 
   1407d0bf3:	48 d3 ef             	shr    %cl,%rdi
   1407d0bf6:	48 01 df             	add    %rbx,%rdi
   1407d0bf9:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407d0c00:	ff 0f 00 
   1407d0c03:	49 d3 e8             	shr    %cl,%r8
   1407d0c06:	49 f7 d0             	not    %r8
   1407d0c09:	4c 21 c7             	and    %r8,%rdi
   1407d0c0c:	eb 03                	jmp    0x1407d0c11
   1407d0c0e:	48 89 cf             	mov    %rcx,%rdi
   1407d0c11:	48 c1 ea 10          	shr    $0x10,%rdx
   1407d0c15:	48 0f bf d2          	movswq %dx,%rdx
   1407d0c19:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   1407d0c1e:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407d0c22:	90                   	nop
   1407d0c23:	39 d6                	cmp    %edx,%esi
   1407d0c25:	0f 9f c2             	setg   %dl
   1407d0c28:	eb 02                	jmp    0x1407d0c2c
   1407d0c2a:	31 d2                	xor    %edx,%edx
   1407d0c2c:	84 d2                	test   %dl,%dl
   1407d0c2e:	75 17                	jne    0x1407d0c47
   1407d0c30:	48 8b 40 68          	mov    0x68(%rax),%rax
   1407d0c34:	48 85 c0             	test   %rax,%rax
   1407d0c37:	7e 09                	jle    0x1407d0c42
   1407d0c39:	e8 c2 13 fc ff       	call   0x140792000
   1407d0c3e:	66 90                	xchg   %ax,%ax
   1407d0c40:	eb 05                	jmp    0x1407d0c47
   1407d0c42:	e8 d9 03 fc ff       	call   0x140791020
   1407d0c47:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d0c4c:	48 8d 1d 1d c9 ae 00 	lea    0xaec91d(%rip),%rbx        # 0x1412bd570
   1407d0c53:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d0c58:	e8 23 31 85 ff       	call   0x140023d80
   1407d0c5d:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
   1407d0c62:	48 89 10             	mov    %rdx,(%rax)
   1407d0c65:	48 8b 15 dc a2 21 04 	mov    0x421a2dc(%rip),%rdx        # 0x1449eaf48
   1407d0c6c:	48 8d 1d 12 07 0c 00 	lea    0xc0712(%rip),%rbx        # 0x140891385
   1407d0c73:	b9 0d 00 00 00       	mov    $0xd,%ecx
   1407d0c78:	48 89 c7             	mov    %rax,%rdi
   1407d0c7b:	be 01 00 00 00       	mov    $0x1,%esi
   1407d0c80:	41 89 f0             	mov    %esi,%r8d
   1407d0c83:	48 89 d0             	mov    %rdx,%rax
   1407d0c86:	e8 15 8d fc ff       	call   0x1407999a0
   1407d0c8b:	31 c0                	xor    %eax,%eax
   1407d0c8d:	48 83 c4 58          	add    $0x58,%rsp
   1407d0c91:	5d                   	pop    %rbp
   1407d0c92:	c3                   	ret
   1407d0c93:	b8 20 00 00 00       	mov    $0x20,%eax
   1407d0c98:	48 8d 1d 41 ec ae 00 	lea    0xaeec41(%rip),%rbx        # 0x1412bf8e0
   1407d0c9f:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d0ca4:	e8 77 38 85 ff       	call   0x140024520
   1407d0ca9:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
   1407d0cae:	48 89 10             	mov    %rdx,(%rax)
   1407d0cb1:	8b 54 24 70          	mov    0x70(%rsp),%edx
   1407d0cb5:	89 d2                	mov    %edx,%edx
   1407d0cb7:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d0cbb:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407d0cc0:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407d0cc4:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407d0ccb:	00 
   1407d0ccc:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407d0cd0:	48 8b 15 71 a2 21 04 	mov    0x421a271(%rip),%rdx        # 0x1449eaf48
   1407d0cd7:	48 8d 1d 80 19 0c 00 	lea    0xc1980(%rip),%rbx        # 0x14089265e
   1407d0cde:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407d0ce3:	48 89 c7             	mov    %rax,%rdi
   1407d0ce6:	be 04 00 00 00       	mov    $0x4,%esi
   1407d0ceb:	41 89 f0             	mov    %esi,%r8d
   1407d0cee:	48 89 d0             	mov    %rdx,%rax
   1407d0cf1:	e8 aa 8c fc ff       	call   0x1407999a0
   1407d0cf6:	48 83 c4 58          	add    $0x58,%rsp
   1407d0cfa:	5d                   	pop    %rbp
   1407d0cfb:	c3                   	ret
   1407d0cfc:	80 3d 46 46 2c 04 00 	cmpb   $0x0,0x42c4646(%rip)        # 0x144a95349
   1407d0d03:	75 05                	jne    0x1407d0d0a
   1407d0d05:	e8 b6 ae ff ff       	call   0x1407cbbc0
   1407d0d0a:	31 c0                	xor    %eax,%eax
   1407d0d0c:	48 83 c4 58          	add    $0x58,%rsp
   1407d0d10:	5d                   	pop    %rbp
   1407d0d11:	c3                   	ret
   1407d0d12:	48 81 c6 b0 00 00 00 	add    $0xb0,%rsi
   1407d0d19:	48 ff c7             	inc    %rdi
   1407d0d1c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407d0d20:	48 39 df             	cmp    %rbx,%rdi
   1407d0d23:	7d d7                	jge    0x1407d0cfc
   1407d0d25:	48 39 16             	cmp    %rdx,(%rsi)
   1407d0d28:	75 e8                	jne    0x1407d0d12
   1407d0d2a:	48 8b 0d 67 d5 27 04 	mov    0x427d567(%rip),%rcx        # 0x144a4e298
   1407d0d31:	48 39 cf             	cmp    %rcx,%rdi
   1407d0d34:	0f 87 0b 01 00 00    	ja     0x1407d0e45
   1407d0d3a:	48 8d 57 01          	lea    0x1(%rdi),%rdx
   1407d0d3e:	66 90                	xchg   %ax,%ax
   1407d0d40:	48 39 d3             	cmp    %rdx,%rbx
   1407d0d43:	0f 82 f4 00 00 00    	jb     0x1407d0e3d
   1407d0d49:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
   1407d0d4d:	49 89 c8             	mov    %rcx,%r8
   1407d0d50:	49 29 f8             	sub    %rdi,%r8
   1407d0d53:	48 29 fb             	sub    %rdi,%rbx
   1407d0d56:	4c 69 cf b0 00 00 00 	imul   $0xb0,%rdi,%r9
   1407d0d5d:	49 ff c8             	dec    %r8
   1407d0d60:	49 f7 d8             	neg    %r8
   1407d0d63:	49 c1 f8 3f          	sar    $0x3f,%r8
   1407d0d67:	4d 8d 91 b0 00 00 00 	lea    0xb0(%r9),%r10
   1407d0d6e:	4d 21 c2             	and    %r8,%r10
   1407d0d71:	4d 8d 04 02          	lea    (%r10,%rax,1),%r8
   1407d0d75:	48 8d 73 ff          	lea    -0x1(%rbx),%rsi
   1407d0d79:	48 39 d1             	cmp    %rdx,%rcx
   1407d0d7c:	73 3e                	jae    0x1407d0dbc
   1407d0d7e:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
   1407d0d83:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
   1407d0d88:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
   1407d0d8d:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
   1407d0d92:	48 89 d3             	mov    %rdx,%rbx
   1407d0d95:	48 89 f7             	mov    %rsi,%rdi
   1407d0d98:	48 8d 35 a1 c6 bb 00 	lea    0xbbc6a1(%rip),%rsi        # 0x14138d440
   1407d0d9f:	90                   	nop
   1407d0da0:	e8 5b 7f 8b ff       	call   0x140088d00
   1407d0da5:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   1407d0daa:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   1407d0daf:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
   1407d0db4:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
   1407d0db9:	48 89 da             	mov    %rbx,%rdx
   1407d0dbc:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
   1407d0dc1:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407d0dc6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   1407d0dcb:	49 89 fa             	mov    %rdi,%r10
   1407d0dce:	48 29 cf             	sub    %rcx,%rdi
   1407d0dd1:	48 89 d1             	mov    %rdx,%rcx
   1407d0dd4:	4c 29 d1             	sub    %r10,%rcx
   1407d0dd7:	48 c1 ff 3f          	sar    $0x3f,%rdi
   1407d0ddb:	49 21 f9             	and    %rdi,%r9
   1407d0dde:	4a 8d 1c 08          	lea    (%rax,%r9,1),%rbx
   1407d0de2:	48 8d 05 57 c6 bb 00 	lea    0xbbc657(%rip),%rax        # 0x14138d440
   1407d0de9:	4c 89 c7             	mov    %r8,%rdi
   1407d0dec:	e8 ef 47 8b ff       	call   0x1400855e0
   1407d0df1:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   1407d0df6:	48 89 15 93 d4 27 04 	mov    %rdx,0x427d493(%rip)        # 0x144a4e290
   1407d0dfd:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407d0e02:	48 89 15 8f d4 27 04 	mov    %rdx,0x427d48f(%rip)        # 0x144a4e298
   1407d0e09:	83 3d 50 4b 2c 04 00 	cmpl   $0x0,0x42c4b50(%rip)        # 0x144a95960
   1407d0e10:	75 07                	jne    0x1407d0e19
   1407d0e12:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   1407d0e17:	eb 18                	jmp    0x1407d0e31
   1407d0e19:	48 8b 0d 68 d4 27 04 	mov    0x427d468(%rip),%rcx        # 0x144a4e288
   1407d0e20:	e8 bb cf 8b ff       	call   0x14008dde0
   1407d0e25:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   1407d0e2a:	49 89 13             	mov    %rdx,(%r11)
   1407d0e2d:	49 89 4b 08          	mov    %rcx,0x8(%r11)
   1407d0e31:	48 89 15 50 d4 27 04 	mov    %rdx,0x427d450(%rip)        # 0x144a4e288
   1407d0e38:	e9 bf fe ff ff       	jmp    0x1407d0cfc
   1407d0e3d:	0f 1f 00             	nopl   (%rax)
   1407d0e40:	e8 3b d3 8b ff       	call   0x14008e180
   1407d0e45:	e8 36 d3 8b ff       	call   0x14008e180
   1407d0e4a:	90                   	nop
   1407d0e4b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1407d0e50:	89 5c 24 10          	mov    %ebx,0x10(%rsp)
   1407d0e54:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   1407d0e59:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   1407d0e5e:	66 90                	xchg   %ax,%ax
   1407d0e60:	e8 db b4 8b ff       	call   0x14008c340
   1407d0e65:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1407d0e6a:	8b 5c 24 10          	mov    0x10(%rsp),%ebx
   1407d0e6e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   1407d0e73:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   1407d0e78:	e9 83 fa ff ff       	jmp    0x1407d0900
   1407d0e7d:	cc                   	int3
   1407d0e7e:	cc                   	int3
   1407d0e7f:	cc                   	int3

# main.cleanupToasts @ 0x1407d0e80
   1407d0e80:	4c 8d a4 24 78 ff ff 	lea    -0x88(%rsp),%r12
   1407d0e87:	ff 
   1407d0e88:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407d0e8c:	0f 86 1c 02 00 00    	jbe    0x1407d10ae
   1407d0e92:	55                   	push   %rbp
   1407d0e93:	48 89 e5             	mov    %rsp,%rbp
   1407d0e96:	48 81 ec 00 01 00 00 	sub    $0x100,%rsp
   1407d0e9d:	c6 05 a5 44 2c 04 01 	movb   $0x1,0x42c44a5(%rip)        # 0x144a95349
   1407d0ea4:	48 8b 1d 1d 96 27 04 	mov    0x427961d(%rip),%rbx        # 0x144a4a4c8
   1407d0eab:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
   1407d0eb2:	00 
   1407d0eb3:	44 0f 11 39          	movups %xmm15,(%rcx)
   1407d0eb7:	44 0f 11 79 10       	movups %xmm15,0x10(%rcx)
   1407d0ebc:	44 0f 11 79 20       	movups %xmm15,0x20(%rcx)
   1407d0ec1:	44 0f 11 79 30       	movups %xmm15,0x30(%rcx)
   1407d0ec6:	44 0f 11 79 40       	movups %xmm15,0x40(%rcx)
   1407d0ecb:	44 0f 11 79 50       	movups %xmm15,0x50(%rcx)
   1407d0ed0:	48 8d 05 99 f3 b1 00 	lea    0xb1f399(%rip),%rax        # 0x1412f0270
   1407d0ed7:	e8 84 4d 85 ff       	call   0x140025c60
   1407d0edc:	eb 59                	jmp    0x1407d0f37
   1407d0ede:	48 8b 12             	mov    (%rdx),%rdx
   1407d0ee1:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   1407d0ee6:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d0eeb:	48 8d 1d 7e c6 ae 00 	lea    0xaec67e(%rip),%rbx        # 0x1412bd570
   1407d0ef2:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d0ef7:	e8 84 2e 85 ff       	call   0x140023d80
   1407d0efc:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   1407d0f01:	48 89 10             	mov    %rdx,(%rax)
   1407d0f04:	48 8b 15 3d a0 21 04 	mov    0x421a03d(%rip),%rdx        # 0x1449eaf48
   1407d0f0b:	48 8d 1d 73 04 0c 00 	lea    0xc0473(%rip),%rbx        # 0x140891385
   1407d0f12:	b9 0d 00 00 00       	mov    $0xd,%ecx
   1407d0f17:	48 89 c7             	mov    %rax,%rdi
   1407d0f1a:	be 01 00 00 00       	mov    $0x1,%esi
   1407d0f1f:	41 89 f0             	mov    %esi,%r8d
   1407d0f22:	48 89 d0             	mov    %rdx,%rax
   1407d0f25:	e8 76 8a fc ff       	call   0x1407999a0
   1407d0f2a:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
   1407d0f31:	00 
   1407d0f32:	e8 89 4d 85 ff       	call   0x140025cc0
   1407d0f37:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   1407d0f3e:	00 
   1407d0f3f:	90                   	nop
   1407d0f40:	48 85 d2             	test   %rdx,%rdx
   1407d0f43:	75 99                	jne    0x1407d0ede
   1407d0f45:	48 8b 1d 84 95 27 04 	mov    0x4279584(%rip),%rbx        # 0x144a4a4d0
   1407d0f4c:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
   1407d0f53:	00 
   1407d0f54:	44 0f 11 39          	movups %xmm15,(%rcx)
   1407d0f58:	44 0f 11 79 10       	movups %xmm15,0x10(%rcx)
   1407d0f5d:	44 0f 11 79 20       	movups %xmm15,0x20(%rcx)
   1407d0f62:	44 0f 11 79 30       	movups %xmm15,0x30(%rcx)
   1407d0f67:	44 0f 11 79 40       	movups %xmm15,0x40(%rcx)
   1407d0f6c:	44 0f 11 79 50       	movups %xmm15,0x50(%rcx)
   1407d0f71:	48 8d 05 98 97 b1 00 	lea    0xb19798(%rip),%rax        # 0x1412ea710
   1407d0f78:	e8 e3 4c 85 ff       	call   0x140025c60
   1407d0f7d:	eb 0d                	jmp    0x1407d0f8c
   1407d0f7f:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
   1407d0f86:	00 
   1407d0f87:	e8 34 4d 85 ff       	call   0x140025cc0
   1407d0f8c:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
   1407d0f93:	00 00 
   1407d0f95:	0f 84 a3 00 00 00    	je     0x1407d103e
   1407d0f9b:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
   1407d0fa2:	00 
   1407d0fa3:	48 8b 1a             	mov    (%rdx),%rbx
   1407d0fa6:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
   1407d0fab:	44 0f 11 39          	movups %xmm15,(%rcx)
   1407d0faf:	44 0f 11 79 10       	movups %xmm15,0x10(%rcx)
   1407d0fb4:	44 0f 11 79 20       	movups %xmm15,0x20(%rcx)
   1407d0fb9:	44 0f 11 79 30       	movups %xmm15,0x30(%rcx)
   1407d0fbe:	44 0f 11 79 40       	movups %xmm15,0x40(%rcx)
   1407d0fc3:	44 0f 11 79 50       	movups %xmm15,0x50(%rcx)
   1407d0fc8:	48 8d 05 e1 e5 b1 00 	lea    0xb1e5e1(%rip),%rax        # 0x1412ef5b0
   1407d0fcf:	e8 8c 4c 85 ff       	call   0x140025c60
   1407d0fd4:	eb 5b                	jmp    0x1407d1031
   1407d0fd6:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d0fdb:	48 8b 12             	mov    (%rdx),%rdx
   1407d0fde:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407d0fe3:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d0fe8:	48 8d 1d 81 c5 ae 00 	lea    0xaec581(%rip),%rbx        # 0x1412bd570
   1407d0fef:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d0ff4:	e8 87 2d 85 ff       	call   0x140023d80
   1407d0ff9:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   1407d0ffe:	48 89 10             	mov    %rdx,(%rax)
   1407d1001:	48 8b 15 50 9f 21 04 	mov    0x4219f50(%rip),%rdx        # 0x1449eaf58
   1407d1008:	48 8d 1d 7c e7 0b 00 	lea    0xbe77c(%rip),%rbx        # 0x14088f78b
   1407d100f:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d1014:	48 89 c7             	mov    %rax,%rdi
   1407d1017:	be 01 00 00 00       	mov    $0x1,%esi
   1407d101c:	41 89 f0             	mov    %esi,%r8d
   1407d101f:	48 89 d0             	mov    %rdx,%rax
   1407d1022:	e8 79 89 fc ff       	call   0x1407999a0
   1407d1027:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
   1407d102c:	e8 8f 4c 85 ff       	call   0x140025cc0
   1407d1031:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
   1407d1037:	75 9d                	jne    0x1407d0fd6
   1407d1039:	e9 41 ff ff ff       	jmp    0x1407d0f7f
   1407d103e:	66 90                	xchg   %ax,%ax
   1407d1040:	e8 5b 3f 8b ff       	call   0x140084fa0
   1407d1045:	83 3d 14 49 2c 04 00 	cmpl   $0x0,0x42c4914(%rip)        # 0x144a95960
   1407d104c:	74 13                	je     0x1407d1061
   1407d104e:	48 8b 15 7b 94 27 04 	mov    0x427947b(%rip),%rdx        # 0x144a4a4d0
   1407d1055:	e8 86 cd 8b ff       	call   0x14008dde0
   1407d105a:	49 89 03             	mov    %rax,(%r11)
   1407d105d:	49 89 53 08          	mov    %rdx,0x8(%r11)
   1407d1061:	48 89 05 68 94 27 04 	mov    %rax,0x4279468(%rip)        # 0x144a4a4d0
   1407d1068:	b8 18 00 00 00       	mov    $0x18,%eax
   1407d106d:	48 8d 1d b4 df ae 00 	lea    0xaedfb4(%rip),%rbx        # 0x1412bf028
   1407d1074:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d1079:	e8 42 32 85 ff       	call   0x1400242c0
   1407d107e:	48 8b 15 eb 9e 21 04 	mov    0x4219eeb(%rip),%rdx        # 0x1449eaf70
   1407d1085:	48 8d 1d ae b7 0b 00 	lea    0xbb7ae(%rip),%rbx        # 0x14088c83a
   1407d108c:	b9 0a 00 00 00       	mov    $0xa,%ecx
   1407d1091:	48 89 c7             	mov    %rax,%rdi
   1407d1094:	be 03 00 00 00       	mov    $0x3,%esi
   1407d1099:	41 89 f0             	mov    %esi,%r8d
   1407d109c:	48 89 d0             	mov    %rdx,%rax
   1407d109f:	90                   	nop
   1407d10a0:	e8 fb 88 fc ff       	call   0x1407999a0
   1407d10a5:	48 81 c4 00 01 00 00 	add    $0x100,%rsp
   1407d10ac:	5d                   	pop    %rbp
   1407d10ad:	c3                   	ret
   1407d10ae:	e8 8d b2 8b ff       	call   0x14008c340
   1407d10b3:	e9 c8 fd ff ff       	jmp    0x1407d0e80
   1407d10b8:	cc                   	int3
   1407d10b9:	cc                   	int3
   1407d10ba:	cc                   	int3
   1407d10bb:	cc                   	int3
   1407d10bc:	cc                   	int3
   1407d10bd:	cc                   	int3
   1407d10be:	cc                   	int3
   1407d10bf:	cc                   	int3

# main.refreshUnreadBadge @ 0x1407d3ea0
   1407d3ea0:	4c 8d 64 24 d8       	lea    -0x28(%rsp),%r12
   1407d3ea5:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407d3ea9:	0f 86 8f 08 00 00    	jbe    0x1407d473e
   1407d3eaf:	55                   	push   %rbp
   1407d3eb0:	48 89 e5             	mov    %rsp,%rbp
   1407d3eb3:	48 81 ec a0 00 00 00 	sub    $0xa0,%rsp
   1407d3eba:	48 8b 05 97 65 27 04 	mov    0x4276597(%rip),%rax        # 0x144a4a458
   1407d3ec1:	48 85 c0             	test   %rax,%rax
   1407d3ec4:	0f 84 6b 08 00 00    	je     0x1407d4735
   1407d3eca:	e8 91 ed ff ff       	call   0x1407d2c60
   1407d3ecf:	48 89 5c 24 78       	mov    %rbx,0x78(%rsp)
   1407d3ed4:	48 8b 0d b5 15 2c 04 	mov    0x42c15b5(%rip),%rcx        # 0x144a95490
   1407d3edb:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   1407d3ee0:	48 39 d9             	cmp    %rbx,%rcx
   1407d3ee3:	48 89 1d a6 15 2c 04 	mov    %rbx,0x42c15a6(%rip)        # 0x144a95490
   1407d3eea:	48 85 db             	test   %rbx,%rbx
   1407d3eed:	75 7f                	jne    0x1407d3f6e
   1407d3eef:	48 83 3d 91 15 2c 04 	cmpq   $0x0,0x42c1591(%rip)        # 0x144a95488
   1407d3ef6:	00 
   1407d3ef7:	75 05                	jne    0x1407d3efe
   1407d3ef9:	48 39 d9             	cmp    %rbx,%rcx
   1407d3efc:	eb 5b                	jmp    0x1407d3f59
   1407d3efe:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d3f03:	48 8d 1d 3e a9 ae 00 	lea    0xaea93e(%rip),%rbx        # 0x1412be848
   1407d3f0a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d3f0f:	e8 4c 01 85 ff       	call   0x140024060
   1407d3f14:	48 8b 15 6d 15 2c 04 	mov    0x42c156d(%rip),%rdx        # 0x144a95488
   1407d3f1b:	48 89 10             	mov    %rdx,(%rax)
   1407d3f1e:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
   1407d3f25:	00 
   1407d3f26:	48 8b 15 1b 70 21 04 	mov    0x421701b(%rip),%rdx        # 0x1449eaf48
   1407d3f2d:	48 8d 1d 84 88 0b 00 	lea    0xb8884(%rip),%rbx        # 0x14088c7b8
   1407d3f34:	b9 0a 00 00 00       	mov    $0xa,%ecx
   1407d3f39:	48 89 c7             	mov    %rax,%rdi
   1407d3f3c:	be 02 00 00 00       	mov    $0x2,%esi
   1407d3f41:	41 89 f0             	mov    %esi,%r8d
   1407d3f44:	48 89 d0             	mov    %rdx,%rax
   1407d3f47:	e8 54 5a fc ff       	call   0x1407999a0
   1407d3f4c:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
   1407d3f51:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
   1407d3f56:	48 39 f2             	cmp    %rsi,%rdx
   1407d3f59:	74 0a                	je     0x1407d3f65
   1407d3f5b:	31 c0                	xor    %eax,%eax
   1407d3f5d:	0f 1f 00             	nopl   (%rax)
   1407d3f60:	e8 db 8d ff ff       	call   0x1407ccd40
   1407d3f65:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   1407d3f6c:	5d                   	pop    %rbp
   1407d3f6d:	c3                   	ret
   1407d3f6e:	e8 ed 6c ff ff       	call   0x1407cac60
   1407d3f73:	f2 0f 11 44 24 50    	movsd  %xmm0,0x50(%rsp)
   1407d3f79:	89 4c 24 44          	mov    %ecx,0x44(%rsp)
   1407d3f7d:	89 7c 24 40          	mov    %edi,0x40(%rsp)
   1407d3f81:	f2 0f 11 05 17 d7 c4 	movsd  %xmm0,0xc4d717(%rip)        # 0x1414216a0
   1407d3f88:	00 
   1407d3f89:	90                   	nop
   1407d3f8a:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   1407d3f8f:	bb 0a 00 00 00       	mov    $0xa,%ebx
   1407d3f94:	e8 67 0c 84 ff       	call   0x140014c00
   1407d3f99:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
   1407d3f9d:	48 8d 04 83          	lea    (%rbx,%rax,4),%rax
   1407d3fa1:	48 8d 40 18          	lea    0x18(%rax),%rax
   1407d3fa5:	90                   	nop
   1407d3fa6:	48 3d 8c 00 00 00    	cmp    $0x8c,%rax
   1407d3fac:	b9 8c 00 00 00       	mov    $0x8c,%ecx
   1407d3fb1:	48 0f 4c c8          	cmovl  %rax,%rcx
   1407d3fb5:	48 83 f9 40          	cmp    $0x40,%rcx
   1407d3fb9:	b8 40 00 00 00       	mov    $0x40,%eax
   1407d3fbe:	48 0f 4f c1          	cmovg  %rcx,%rax
   1407d3fc2:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407d3fc5:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   1407d3fca:	f2 0f 10 4c 24 50    	movsd  0x50(%rsp),%xmm1
   1407d3fd0:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407d3fd4:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d3fd9:	48 89 c8             	mov    %rcx,%rax
   1407d3fdc:	48 c1 e8 34          	shr    $0x34,%rax
   1407d3fe0:	25 ff 07 00 00       	and    $0x7ff,%eax
   1407d3fe5:	48 3d ff 03 00 00    	cmp    $0x3ff,%rax
   1407d3feb:	73 29                	jae    0x1407d4016
   1407d3fed:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
   1407d3ff4:	00 00 80 
   1407d3ff7:	48 21 d1             	and    %rdx,%rcx
   1407d3ffa:	48 be 00 00 00 00 00 	movabs $0x3ff0000000000000,%rsi
   1407d4001:	00 f0 3f 
   1407d4004:	48 09 ce             	or     %rcx,%rsi
   1407d4007:	48 3d fe 03 00 00    	cmp    $0x3fe,%rax
   1407d400d:	48 0f 44 ce          	cmove  %rsi,%rcx
   1407d4011:	48 89 ce             	mov    %rcx,%rsi
   1407d4014:	eb 3d                	jmp    0x1407d4053
   1407d4016:	48 3d 33 04 00 00    	cmp    $0x433,%rax
   1407d401c:	73 32                	jae    0x1407d4050
   1407d401e:	48 8d 90 01 fc ff ff 	lea    -0x3ff(%rax),%rdx
   1407d4025:	48 89 c8             	mov    %rcx,%rax
   1407d4028:	48 89 d1             	mov    %rdx,%rcx
   1407d402b:	48 be 00 00 00 00 00 	movabs $0x8000000000000,%rsi
   1407d4032:	00 08 00 
   1407d4035:	48 d3 ee             	shr    %cl,%rsi
   1407d4038:	48 01 c6             	add    %rax,%rsi
   1407d403b:	48 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%rdi
   1407d4042:	ff 0f 00 
   1407d4045:	48 d3 ef             	shr    %cl,%rdi
   1407d4048:	48 f7 d7             	not    %rdi
   1407d404b:	48 21 fe             	and    %rdi,%rsi
   1407d404e:	eb 03                	jmp    0x1407d4053
   1407d4050:	48 89 ce             	mov    %rcx,%rsi
   1407d4053:	f2 0f 10 05 fd 1d 40 	movsd  0x401dfd(%rip),%xmm0        # 0x140bd5e58
   1407d405a:	00 
   1407d405b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407d405f:	66 48 0f 6e d6       	movq   %rsi,%xmm2
   1407d4064:	f2 0f 2c d2          	cvttsd2si %xmm2,%edx
   1407d4068:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d406d:	48 89 ce             	mov    %rcx,%rsi
   1407d4070:	48 c1 ee 34          	shr    $0x34,%rsi
   1407d4074:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407d407a:	90                   	nop
   1407d407b:	89 15 47 13 2c 04    	mov    %edx,0x42c1347(%rip)        # 0x144a953c8
   1407d4081:	90                   	nop
   1407d4082:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407d4089:	73 2a                	jae    0x1407d40b5
   1407d408b:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
   1407d4092:	00 00 80 
   1407d4095:	48 21 d1             	and    %rdx,%rcx
   1407d4098:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407d409f:	00 f0 3f 
   1407d40a2:	48 09 cf             	or     %rcx,%rdi
   1407d40a5:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407d40ac:	48 0f 44 cf          	cmove  %rdi,%rcx
   1407d40b0:	48 89 ce             	mov    %rcx,%rsi
   1407d40b3:	eb 3e                	jmp    0x1407d40f3
   1407d40b5:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407d40bc:	73 32                	jae    0x1407d40f0
   1407d40be:	48 8d 96 01 fc ff ff 	lea    -0x3ff(%rsi),%rdx
   1407d40c5:	48 89 c8             	mov    %rcx,%rax
   1407d40c8:	48 89 d1             	mov    %rdx,%rcx
   1407d40cb:	48 be 00 00 00 00 00 	movabs $0x8000000000000,%rsi
   1407d40d2:	00 08 00 
   1407d40d5:	48 d3 ee             	shr    %cl,%rsi
   1407d40d8:	48 01 c6             	add    %rax,%rsi
   1407d40db:	48 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%rdi
   1407d40e2:	ff 0f 00 
   1407d40e5:	48 d3 ef             	shr    %cl,%rdi
   1407d40e8:	48 f7 d7             	not    %rdi
   1407d40eb:	48 21 fe             	and    %rdi,%rsi
   1407d40ee:	eb 03                	jmp    0x1407d40f3
   1407d40f0:	48 89 ce             	mov    %rcx,%rsi
   1407d40f3:	f2 0f 10 05 fd 1c 40 	movsd  0x401cfd(%rip),%xmm0        # 0x140bd5df8
   1407d40fa:	00 
   1407d40fb:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407d40ff:	66 48 0f 6e d6       	movq   %rsi,%xmm2
   1407d4104:	f2 0f 2c d2          	cvttsd2si %xmm2,%edx
   1407d4108:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d410d:	48 89 ce             	mov    %rcx,%rsi
   1407d4110:	48 c1 ee 34          	shr    $0x34,%rsi
   1407d4114:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407d411a:	90                   	nop
   1407d411b:	89 15 ab 12 2c 04    	mov    %edx,0x42c12ab(%rip)        # 0x144a953cc
   1407d4121:	90                   	nop
   1407d4122:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407d4129:	73 2a                	jae    0x1407d4155
   1407d412b:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
   1407d4132:	00 00 80 
   1407d4135:	48 21 d1             	and    %rdx,%rcx
   1407d4138:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407d413f:	00 f0 3f 
   1407d4142:	48 09 cf             	or     %rcx,%rdi
   1407d4145:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407d414c:	48 0f 44 cf          	cmove  %rdi,%rcx
   1407d4150:	48 89 ce             	mov    %rcx,%rsi
   1407d4153:	eb 3e                	jmp    0x1407d4193
   1407d4155:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407d415c:	73 32                	jae    0x1407d4190
   1407d415e:	48 8d 96 01 fc ff ff 	lea    -0x3ff(%rsi),%rdx
   1407d4165:	48 89 c8             	mov    %rcx,%rax
   1407d4168:	48 89 d1             	mov    %rdx,%rcx
   1407d416b:	48 be 00 00 00 00 00 	movabs $0x8000000000000,%rsi
   1407d4172:	00 08 00 
   1407d4175:	48 d3 ee             	shr    %cl,%rsi
   1407d4178:	48 01 c6             	add    %rax,%rsi
   1407d417b:	48 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%rdi
   1407d4182:	ff 0f 00 
   1407d4185:	48 d3 ef             	shr    %cl,%rdi
   1407d4188:	48 f7 d7             	not    %rdi
   1407d418b:	48 21 fe             	and    %rdi,%rsi
   1407d418e:	eb 03                	jmp    0x1407d4193
   1407d4190:	48 89 ce             	mov    %rcx,%rsi
   1407d4193:	f2 0f 10 05 55 1c 40 	movsd  0x401c55(%rip),%xmm0        # 0x140bd5df0
   1407d419a:	00 
   1407d419b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407d419f:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d41a4:	48 89 ca             	mov    %rcx,%rdx
   1407d41a7:	48 c1 ea 34          	shr    $0x34,%rdx
   1407d41ab:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407d41b1:	90                   	nop
   1407d41b2:	90                   	nop
   1407d41b3:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d41ba:	73 2a                	jae    0x1407d41e6
   1407d41bc:	48 bf 00 00 00 00 00 	movabs $0x8000000000000000,%rdi
   1407d41c3:	00 00 80 
   1407d41c6:	48 21 f9             	and    %rdi,%rcx
   1407d41c9:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407d41d0:	00 f0 3f 
   1407d41d3:	48 09 cf             	or     %rcx,%rdi
   1407d41d6:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407d41dd:	48 0f 44 cf          	cmove  %rdi,%rcx
   1407d41e1:	48 89 cf             	mov    %rcx,%rdi
   1407d41e4:	eb 3f                	jmp    0x1407d4225
   1407d41e6:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407d41ed:	73 33                	jae    0x1407d4222
   1407d41ef:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407d41f6:	48 89 c8             	mov    %rcx,%rax
   1407d41f9:	48 89 d1             	mov    %rdx,%rcx
   1407d41fc:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407d4203:	00 08 00 
   1407d4206:	48 d3 ef             	shr    %cl,%rdi
   1407d4209:	48 01 c7             	add    %rax,%rdi
   1407d420c:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407d4213:	ff 0f 00 
   1407d4216:	49 d3 e8             	shr    %cl,%r8
   1407d4219:	49 f7 d0             	not    %r8
   1407d421c:	4c 21 c7             	and    %r8,%rdi
   1407d421f:	90                   	nop
   1407d4220:	eb 03                	jmp    0x1407d4225
   1407d4222:	48 89 cf             	mov    %rcx,%rdi
   1407d4225:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407d422a:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407d422e:	8b 54 24 44          	mov    0x44(%rsp),%edx
   1407d4232:	29 ca                	sub    %ecx,%edx
   1407d4234:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   1407d4239:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407d423d:	8b 74 24 40          	mov    0x40(%rsp),%esi
   1407d4241:	29 ce                	sub    %ecx,%esi
   1407d4243:	2b 15 7f 11 2c 04    	sub    0x42c117f(%rip),%edx        # 0x144a953c8
   1407d4249:	89 54 24 3c          	mov    %edx,0x3c(%rsp)
   1407d424d:	2b 35 79 11 2c 04    	sub    0x42c1179(%rip),%esi        # 0x144a953cc
   1407d4253:	89 74 24 38          	mov    %esi,0x38(%rsp)
   1407d4257:	90                   	nop
   1407d4258:	90                   	nop
   1407d4259:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   1407d425e:	bb 0a 00 00 00       	mov    $0xa,%ebx
   1407d4263:	e8 98 09 84 ff       	call   0x140014c00
   1407d4268:	b9 12 00 00 00       	mov    $0x12,%ecx
   1407d426d:	48 89 c7             	mov    %rax,%rdi
   1407d4270:	48 89 de             	mov    %rbx,%rsi
   1407d4273:	4c 8d 05 f0 53 0f 00 	lea    0xf53f0(%rip),%r8        # 0x1408c966a
   1407d427a:	41 b9 3f 00 00 00    	mov    $0x3f,%r9d
   1407d4280:	31 c0                	xor    %eax,%eax
   1407d4282:	48 8d 1d 76 4c 0c 00 	lea    0xc4c76(%rip),%rbx        # 0x140898eff
   1407d4289:	e8 b2 64 89 ff       	call   0x14006a740
   1407d428e:	48 83 3d f2 11 2c 04 	cmpq   $0x0,0x42c11f2(%rip)        # 0x144a95488
   1407d4295:	00 
   1407d4296:	0f 85 f3 00 00 00    	jne    0x1407d438f
   1407d429c:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   1407d42a1:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   1407d42a8:	00 
   1407d42a9:	48 8d 05 48 12 0c 00 	lea    0xc1248(%rip),%rax        # 0x1408954f8
   1407d42b0:	bb 10 00 00 00       	mov    $0x10,%ebx
   1407d42b5:	e8 66 56 fc ff       	call   0x140799920
   1407d42ba:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   1407d42c1:	00 
   1407d42c2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   1407d42c9:	00 
   1407d42ca:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   1407d42cf:	e8 4c 56 fc ff       	call   0x140799920
   1407d42d4:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   1407d42db:	00 
   1407d42dc:	48 8d 05 2d 7d ae 00 	lea    0xae7d2d(%rip),%rax        # 0x1412bc010
   1407d42e3:	e8 18 db 84 ff       	call   0x140021e00
   1407d42e8:	48 c7 00 88 00 00 08 	movq   $0x8000088,(%rax)
   1407d42ef:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   1407d42f6:	00 
   1407d42f7:	48 89 48 08          	mov    %rcx,0x8(%rax)
   1407d42fb:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   1407d4302:	00 
   1407d4303:	48 89 48 10          	mov    %rcx,0x10(%rax)
   1407d4307:	b9 00 00 00 80       	mov    $0x80000000,%ecx
   1407d430c:	48 89 48 18          	mov    %rcx,0x18(%rax)
   1407d4310:	8b 4c 24 3c          	mov    0x3c(%rsp),%ecx
   1407d4314:	48 63 c9             	movslq %ecx,%rcx
   1407d4317:	48 89 48 20          	mov    %rcx,0x20(%rax)
   1407d431b:	8b 4c 24 38          	mov    0x38(%rsp),%ecx
   1407d431f:	48 63 c9             	movslq %ecx,%rcx
   1407d4322:	48 89 48 28          	mov    %rcx,0x28(%rax)
   1407d4326:	48 63 0d 9b 10 2c 04 	movslq 0x42c109b(%rip),%rcx        # 0x144a953c8
   1407d432d:	48 89 48 30          	mov    %rcx,0x30(%rax)
   1407d4331:	48 63 0d 94 10 2c 04 	movslq 0x42c1094(%rip),%rcx        # 0x144a953cc
   1407d4338:	48 89 48 38          	mov    %rcx,0x38(%rax)
   1407d433c:	44 0f 11 78 40       	movups %xmm15,0x40(%rax)
   1407d4341:	48 8b 0d 38 11 2c 04 	mov    0x42c1138(%rip),%rcx        # 0x144a95480
   1407d4348:	48 89 48 50          	mov    %rcx,0x50(%rax)
   1407d434c:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
   1407d4353:	00 
   1407d4354:	48 8b 0d ed 6b 21 04 	mov    0x4216bed(%rip),%rcx        # 0x1449eaf48
   1407d435b:	48 8d 1d 7a f8 0b 00 	lea    0xbf87a(%rip),%rbx        # 0x140893bdc
   1407d4362:	48 89 c7             	mov    %rax,%rdi
   1407d4365:	be 0c 00 00 00       	mov    $0xc,%esi
   1407d436a:	41 89 f0             	mov    %esi,%r8d
   1407d436d:	48 89 c8             	mov    %rcx,%rax
   1407d4370:	b9 0f 00 00 00       	mov    $0xf,%ecx
   1407d4375:	e8 26 56 fc ff       	call   0x1407999a0
   1407d437a:	48 89 05 07 11 2c 04 	mov    %rax,0x42c1107(%rip)        # 0x144a95488
   1407d4381:	48 85 c0             	test   %rax,%rax
   1407d4384:	75 68                	jne    0x1407d43ee
   1407d4386:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   1407d438d:	5d                   	pop    %rbp
   1407d438e:	c3                   	ret
   1407d438f:	e8 8c 55 fc ff       	call   0x140799920
   1407d4394:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   1407d439b:	00 
   1407d439c:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d43a1:	48 8d 1d a0 a4 ae 00 	lea    0xaea4a0(%rip),%rbx        # 0x1412be848
   1407d43a8:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d43ad:	e8 ae fc 84 ff       	call   0x140024060
   1407d43b2:	48 8b 0d cf 10 2c 04 	mov    0x42c10cf(%rip),%rcx        # 0x144a95488
   1407d43b9:	48 89 08             	mov    %rcx,(%rax)
   1407d43bc:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   1407d43c3:	00 
   1407d43c4:	48 89 48 08          	mov    %rcx,0x8(%rax)
   1407d43c8:	48 8b 0d 79 6b 21 04 	mov    0x4216b79(%rip),%rcx        # 0x1449eaf48
   1407d43cf:	48 8d 1d 6c e2 0b 00 	lea    0xbe26c(%rip),%rbx        # 0x140892642
   1407d43d6:	48 89 c7             	mov    %rax,%rdi
   1407d43d9:	be 02 00 00 00       	mov    $0x2,%esi
   1407d43de:	41 89 f0             	mov    %esi,%r8d
   1407d43e1:	48 89 c8             	mov    %rcx,%rax
   1407d43e4:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407d43e9:	e8 b2 55 fc ff       	call   0x1407999a0
   1407d43ee:	f2 0f 10 05 0a 1a 40 	movsd  0x401a0a(%rip),%xmm0        # 0x140bd5e00
   1407d43f5:	00 
   1407d43f6:	f2 0f 10 4c 24 50    	movsd  0x50(%rsp),%xmm1
   1407d43fc:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1407d4400:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407d4405:	48 89 ca             	mov    %rcx,%rdx
   1407d4408:	48 c1 ea 34          	shr    $0x34,%rdx
   1407d440c:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407d4412:	90                   	nop
   1407d4413:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d441a:	73 34                	jae    0x1407d4450
   1407d441c:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407d4423:	00 00 80 
   1407d4426:	48 21 ce             	and    %rcx,%rsi
   1407d4429:	48 bf 00 00 00 00 00 	movabs $0x3ff0000000000000,%rdi
   1407d4430:	00 f0 3f 
   1407d4433:	48 09 f7             	or     %rsi,%rdi
   1407d4436:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407d443d:	48 0f 44 f7          	cmove  %rdi,%rsi
   1407d4441:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d4448:	48 89 c8             	mov    %rcx,%rax
   1407d444b:	48 89 f7             	mov    %rsi,%rdi
   1407d444e:	eb 4f                	jmp    0x1407d449f
   1407d4450:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407d4457:	73 39                	jae    0x1407d4492
   1407d4459:	48 8d b2 01 fc ff ff 	lea    -0x3ff(%rdx),%rsi
   1407d4460:	48 89 c8             	mov    %rcx,%rax
   1407d4463:	48 89 f1             	mov    %rsi,%rcx
   1407d4466:	48 bf 00 00 00 00 00 	movabs $0x8000000000000,%rdi
   1407d446d:	00 08 00 
   1407d4470:	48 d3 ef             	shr    %cl,%rdi
   1407d4473:	48 01 c7             	add    %rax,%rdi
   1407d4476:	49 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%r8
   1407d447d:	ff 0f 00 
   1407d4480:	49 d3 e8             	shr    %cl,%r8
   1407d4483:	49 f7 d0             	not    %r8
   1407d4486:	4c 21 c7             	and    %r8,%rdi
   1407d4489:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d4490:	eb 0d                	jmp    0x1407d449f
   1407d4492:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d4499:	48 89 c8             	mov    %rcx,%rax
   1407d449c:	48 89 c7             	mov    %rax,%rdi
   1407d449f:	90                   	nop
   1407d44a0:	73 2a                	jae    0x1407d44cc
   1407d44a2:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407d44a9:	00 00 80 
   1407d44ac:	48 21 c6             	and    %rax,%rsi
   1407d44af:	49 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%r8
   1407d44b6:	00 f0 3f 
   1407d44b9:	49 09 f0             	or     %rsi,%r8
   1407d44bc:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407d44c3:	49 0f 44 f0          	cmove  %r8,%rsi
   1407d44c7:	48 89 f2             	mov    %rsi,%rdx
   1407d44ca:	eb 39                	jmp    0x1407d4505
   1407d44cc:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407d44d3:	73 2d                	jae    0x1407d4502
   1407d44d5:	48 8d 8a 01 fc ff ff 	lea    -0x3ff(%rdx),%rcx
   1407d44dc:	48 ba 00 00 00 00 00 	movabs $0x8000000000000,%rdx
   1407d44e3:	00 08 00 
   1407d44e6:	48 d3 ea             	shr    %cl,%rdx
   1407d44e9:	48 01 c2             	add    %rax,%rdx
   1407d44ec:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   1407d44f3:	ff 0f 00 
   1407d44f6:	48 d3 ee             	shr    %cl,%rsi
   1407d44f9:	48 f7 d6             	not    %rsi
   1407d44fc:	48 21 f2             	and    %rsi,%rdx
   1407d44ff:	90                   	nop
   1407d4500:	eb 03                	jmp    0x1407d4505
   1407d4502:	48 89 c2             	mov    %rax,%rdx
   1407d4505:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   1407d450a:	f2 0f 2c f0          	cvttsd2si %xmm0,%esi
   1407d450e:	48 63 f6             	movslq %esi,%rsi
   1407d4511:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
   1407d4516:	66 48 0f 6e c2       	movq   %rdx,%xmm0
   1407d451b:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
   1407d451f:	48 63 d2             	movslq %edx,%rdx
   1407d4522:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   1407d4527:	90                   	nop
   1407d4528:	b8 30 00 00 00       	mov    $0x30,%eax
   1407d452d:	48 8d 1d ec be ae 00 	lea    0xaebeec(%rip),%rbx        # 0x1412c0420
   1407d4534:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4539:	e8 42 02 85 ff       	call   0x140024780
   1407d453e:	8b 15 84 0e 2c 04    	mov    0x42c0e84(%rip),%edx        # 0x144a953c8
   1407d4544:	ff c2                	inc    %edx
   1407d4546:	48 63 d2             	movslq %edx,%rdx
   1407d4549:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407d454d:	8b 15 79 0e 2c 04    	mov    0x42c0e79(%rip),%edx        # 0x144a953cc
   1407d4553:	ff c2                	inc    %edx
   1407d4555:	48 63 d2             	movslq %edx,%rdx
   1407d4558:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407d455c:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
   1407d4561:	48 89 50 20          	mov    %rdx,0x20(%rax)
   1407d4565:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   1407d456a:	48 89 50 28          	mov    %rdx,0x28(%rax)
   1407d456e:	48 8b 15 e3 69 21 04 	mov    0x42169e3(%rip),%rdx        # 0x1449eaf58
   1407d4575:	48 8d 1d 71 49 0c 00 	lea    0xc4971(%rip),%rbx        # 0x140898eed
   1407d457c:	b9 12 00 00 00       	mov    $0x12,%ecx
   1407d4581:	48 89 c7             	mov    %rax,%rdi
   1407d4584:	be 06 00 00 00       	mov    $0x6,%esi
   1407d4589:	41 89 f0             	mov    %esi,%r8d
   1407d458c:	48 89 d0             	mov    %rdx,%rax
   1407d458f:	e8 0c 54 fc ff       	call   0x1407999a0
   1407d4594:	48 85 c0             	test   %rax,%rax
   1407d4597:	0f 84 a8 00 00 00    	je     0x1407d4645
   1407d459d:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   1407d45a2:	b8 18 00 00 00       	mov    $0x18,%eax
   1407d45a7:	48 8d 1d 7a aa ae 00 	lea    0xaeaa7a(%rip),%rbx        # 0x1412bf028
   1407d45ae:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d45b3:	e8 08 fd 84 ff       	call   0x1400242c0
   1407d45b8:	48 8b 15 c9 0e 2c 04 	mov    0x42c0ec9(%rip),%rdx        # 0x144a95488
   1407d45bf:	48 89 10             	mov    %rdx,(%rax)
   1407d45c2:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   1407d45c7:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d45cb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
   1407d45d2:	00 
   1407d45d3:	48 8b 15 6e 69 21 04 	mov    0x421696e(%rip),%rdx        # 0x1449eaf48
   1407d45da:	48 8d 1d a6 b2 0b 00 	lea    0xbb2a6(%rip),%rbx        # 0x14088f887
   1407d45e1:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d45e6:	48 89 c7             	mov    %rax,%rdi
   1407d45e9:	be 03 00 00 00       	mov    $0x3,%esi
   1407d45ee:	41 89 f0             	mov    %esi,%r8d
   1407d45f1:	48 89 d0             	mov    %rdx,%rax
   1407d45f4:	e8 a7 53 fc ff       	call   0x1407999a0
   1407d45f9:	48 85 c0             	test   %rax,%rax
   1407d45fc:	75 47                	jne    0x1407d4645
   1407d45fe:	b8 08 00 00 00       	mov    $0x8,%eax
   1407d4603:	48 8d 1d 66 8f ae 00 	lea    0xae8f66(%rip),%rbx        # 0x1412bd570
   1407d460a:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d460f:	e8 6c f7 84 ff       	call   0x140023d80
   1407d4614:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
   1407d4619:	48 89 10             	mov    %rdx,(%rax)
   1407d461c:	48 8b 15 35 69 21 04 	mov    0x4216935(%rip),%rdx        # 0x1449eaf58
   1407d4623:	48 8d 1d 61 b1 0b 00 	lea    0xbb161(%rip),%rbx        # 0x14088f78b
   1407d462a:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d462f:	48 89 c7             	mov    %rax,%rdi
   1407d4632:	be 01 00 00 00       	mov    $0x1,%esi
   1407d4637:	41 89 f0             	mov    %esi,%r8d
   1407d463a:	48 89 d0             	mov    %rdx,%rax
   1407d463d:	0f 1f 00             	nopl   (%rax)
   1407d4640:	e8 5b 53 fc ff       	call   0x1407999a0
   1407d4645:	b8 38 00 00 00       	mov    $0x38,%eax
   1407d464a:	48 8d 1d 0f c0 ae 00 	lea    0xaec00f(%rip),%rbx        # 0x1412c0660
   1407d4651:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4656:	e8 85 03 85 ff       	call   0x1400249e0
   1407d465b:	48 8b 15 26 0e 2c 04 	mov    0x42c0e26(%rip),%rdx        # 0x144a95488
   1407d4662:	48 89 10             	mov    %rdx,(%rax)
   1407d4665:	48 c7 40 08 ff ff ff 	movq   $0xffffffffffffffff,0x8(%rax)
   1407d466c:	ff 
   1407d466d:	8b 54 24 3c          	mov    0x3c(%rsp),%edx
   1407d4671:	48 63 d2             	movslq %edx,%rdx
   1407d4674:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407d4678:	8b 54 24 38          	mov    0x38(%rsp),%edx
   1407d467c:	48 63 d2             	movslq %edx,%rdx
   1407d467f:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407d4683:	48 63 15 3e 0d 2c 04 	movslq 0x42c0d3e(%rip),%rdx        # 0x144a953c8
   1407d468a:	48 89 50 20          	mov    %rdx,0x20(%rax)
   1407d468e:	48 63 15 37 0d 2c 04 	movslq 0x42c0d37(%rip),%rdx        # 0x144a953cc
   1407d4695:	48 89 50 28          	mov    %rdx,0x28(%rax)
   1407d4699:	48 c7 40 30 50 00 00 	movq   $0x50,0x30(%rax)
   1407d46a0:	00 
   1407d46a1:	48 8b 15 a0 68 21 04 	mov    0x42168a0(%rip),%rdx        # 0x1449eaf48
   1407d46a8:	48 8d 1d e4 b1 0b 00 	lea    0xbb1e4(%rip),%rbx        # 0x14088f893
   1407d46af:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d46b4:	48 89 c7             	mov    %rax,%rdi
   1407d46b7:	be 07 00 00 00       	mov    $0x7,%esi
   1407d46bc:	41 89 f0             	mov    %esi,%r8d
   1407d46bf:	48 89 d0             	mov    %rdx,%rax
   1407d46c2:	e8 d9 52 fc ff       	call   0x1407999a0
   1407d46c7:	b8 18 00 00 00       	mov    $0x18,%eax
   1407d46cc:	48 8d 1d 55 a9 ae 00 	lea    0xaea955(%rip),%rbx        # 0x1412bf028
   1407d46d3:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d46d8:	e8 e3 fb 84 ff       	call   0x1400242c0
   1407d46dd:	48 8b 15 a4 0d 2c 04 	mov    0x42c0da4(%rip),%rdx        # 0x144a95488
   1407d46e4:	48 89 10             	mov    %rdx,(%rax)
   1407d46e7:	44 0f 11 78 08       	movups %xmm15,0x8(%rax)
   1407d46ec:	48 8b 15 55 68 21 04 	mov    0x4216855(%rip),%rdx        # 0x1449eaf48
   1407d46f3:	48 8d 1d 3a df 0b 00 	lea    0xbdf3a(%rip),%rbx        # 0x140892634
   1407d46fa:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407d46ff:	48 89 c7             	mov    %rax,%rdi
   1407d4702:	be 03 00 00 00       	mov    $0x3,%esi
   1407d4707:	41 89 f0             	mov    %esi,%r8d
   1407d470a:	48 89 d0             	mov    %rdx,%rax
   1407d470d:	e8 8e 52 fc ff       	call   0x1407999a0
   1407d4712:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
   1407d4717:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
   1407d471c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407d4720:	48 39 f2             	cmp    %rsi,%rdx
   1407d4723:	74 07                	je     0x1407d472c
   1407d4725:	31 c0                	xor    %eax,%eax
   1407d4727:	e8 14 86 ff ff       	call   0x1407ccd40
   1407d472c:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   1407d4733:	5d                   	pop    %rbp
   1407d4734:	c3                   	ret
   1407d4735:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   1407d473c:	5d                   	pop    %rbp
   1407d473d:	c3                   	ret
   1407d473e:	66 90                	xchg   %ax,%ax
   1407d4740:	e8 fb 7b 8b ff       	call   0x14008c340
   1407d4745:	e9 56 f7 ff ff       	jmp    0x1407d3ea0
   1407d474a:	cc                   	int3
   1407d474b:	cc                   	int3
   1407d474c:	cc                   	int3
   1407d474d:	cc                   	int3
   1407d474e:	cc                   	int3
   1407d474f:	cc                   	int3
   1407d4750:	cc                   	int3
   1407d4751:	cc                   	int3
   1407d4752:	cc                   	int3
   1407d4753:	cc                   	int3
   1407d4754:	cc                   	int3
   1407d4755:	cc                   	int3
   1407d4756:	cc                   	int3
   1407d4757:	cc                   	int3
   1407d4758:	cc                   	int3
   1407d4759:	cc                   	int3
   1407d475a:	cc                   	int3
   1407d475b:	cc                   	int3
   1407d475c:	cc                   	int3
   1407d475d:	cc                   	int3
   1407d475e:	cc                   	int3
   1407d475f:	cc                   	int3

# main.toastDisplayArea @ 0x1407d4760
   1407d4760:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407d4764:	0f 86 d1 00 00 00    	jbe    0x1407d483b
   1407d476a:	55                   	push   %rbp
   1407d476b:	48 89 e5             	mov    %rsp,%rbp
   1407d476e:	e8 ed 64 ff ff       	call   0x1407cac60
   1407d4773:	48 83 3d 15 0d 2c 04 	cmpq   $0x0,0x42c0d15(%rip)        # 0x144a95490
   1407d477a:	00 
   1407d477b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407d4780:	0f 8e af 00 00 00    	jle    0x1407d4835
   1407d4786:	48 83 3d fa 0c 2c 04 	cmpq   $0x0,0x42c0cfa(%rip)        # 0x144a95488
   1407d478d:	00 
   1407d478e:	0f 84 a1 00 00 00    	je     0x1407d4835
   1407d4794:	f2 0f 10 0d dc 16 40 	movsd  0x4016dc(%rip),%xmm1        # 0x140bd5e78
   1407d479b:	00 
   1407d479c:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1407d47a0:	66 48 0f 7e ca       	movq   %xmm1,%rdx
   1407d47a5:	48 89 d6             	mov    %rdx,%rsi
   1407d47a8:	48 c1 ea 34          	shr    $0x34,%rdx
   1407d47ac:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407d47b2:	90                   	nop
   1407d47b3:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407d47ba:	73 2c                	jae    0x1407d47e8
   1407d47bc:	49 b8 00 00 00 00 00 	movabs $0x8000000000000000,%r8
   1407d47c3:	00 00 80 
   1407d47c6:	49 21 f0             	and    %rsi,%r8
   1407d47c9:	48 be 00 00 00 00 00 	movabs $0x3ff0000000000000,%rsi
   1407d47d0:	00 f0 3f 
   1407d47d3:	4c 09 c6             	or     %r8,%rsi
   1407d47d6:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407d47dd:	4c 0f 44 c6          	cmove  %rsi,%r8
   1407d47e1:	89 ca                	mov    %ecx,%edx
   1407d47e3:	4d 89 c1             	mov    %r8,%r9
   1407d47e6:	eb 3f                	jmp    0x1407d4827
   1407d47e8:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407d47ef:	73 31                	jae    0x1407d4822
   1407d47f1:	4c 8d 82 01 fc ff ff 	lea    -0x3ff(%rdx),%r8
   1407d47f8:	89 ca                	mov    %ecx,%edx
   1407d47fa:	4c 89 c1             	mov    %r8,%rcx
   1407d47fd:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407d4804:	00 08 00 
   1407d4807:	49 d3 e9             	shr    %cl,%r9
   1407d480a:	4c 01 ce             	add    %r9,%rsi
   1407d480d:	49 b9 ff ff ff ff ff 	movabs $0xfffffffffffff,%r9
   1407d4814:	ff 0f 00 
   1407d4817:	49 d3 e9             	shr    %cl,%r9
   1407d481a:	49 f7 d1             	not    %r9
   1407d481d:	49 21 f1             	and    %rsi,%r9
   1407d4820:	eb 05                	jmp    0x1407d4827
   1407d4822:	89 ca                	mov    %ecx,%edx
   1407d4824:	49 89 f1             	mov    %rsi,%r9
   1407d4827:	66 49 0f 6e c9       	movq   %r9,%xmm1
   1407d482c:	f2 0f 2c f1          	cvttsd2si %xmm1,%esi
   1407d4830:	29 f7                	sub    %esi,%edi
   1407d4832:	90                   	nop
   1407d4833:	eb 02                	jmp    0x1407d4837
   1407d4835:	89 ca                	mov    %ecx,%edx
   1407d4837:	89 d1                	mov    %edx,%ecx
   1407d4839:	5d                   	pop    %rbp
   1407d483a:	c3                   	ret
   1407d483b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407d4840:	e8 fb 7a 8b ff       	call   0x14008c340
   1407d4845:	e9 16 ff ff ff       	jmp    0x1407d4760
   1407d484a:	cc                   	int3
   1407d484b:	cc                   	int3
   1407d484c:	cc                   	int3
   1407d484d:	cc                   	int3
   1407d484e:	cc                   	int3
   1407d484f:	cc                   	int3
   1407d4850:	cc                   	int3
   1407d4851:	cc                   	int3
   1407d4852:	cc                   	int3
   1407d4853:	cc                   	int3
   1407d4854:	cc                   	int3
   1407d4855:	cc                   	int3
   1407d4856:	cc                   	int3
   1407d4857:	cc                   	int3
   1407d4858:	cc                   	int3
   1407d4859:	cc                   	int3
   1407d485a:	cc                   	int3
   1407d485b:	cc                   	int3
   1407d485c:	cc                   	int3
   1407d485d:	cc                   	int3
   1407d485e:	cc                   	int3
   1407d485f:	cc                   	int3

# main.unreadBadgeProc @ 0x1407d4ae0
   1407d4ae0:	4c 8d 64 24 d0       	lea    -0x30(%rsp),%r12
   1407d4ae5:	4d 3b 66 10          	cmp    0x10(%r14),%r12
   1407d4ae9:	0f 86 fd 04 00 00    	jbe    0x1407d4fec
   1407d4aef:	55                   	push   %rbp
   1407d4af0:	48 89 e5             	mov    %rsp,%rbp
   1407d4af3:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
   1407d4afa:	66 44 0f d6 bc 24 a0 	movq   %xmm15,0xa0(%rsp)
   1407d4b01:	00 00 00 
   1407d4b04:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   1407d4b0b:	00 
   1407d4b0c:	89 9c 24 c0 00 00 00 	mov    %ebx,0xc0(%rsp)
   1407d4b13:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
   1407d4b1a:	00 
   1407d4b1b:	48 89 bc 24 d0 00 00 	mov    %rdi,0xd0(%rsp)
   1407d4b22:	00 
   1407d4b23:	c6 44 24 37 00       	movb   $0x0,0x37(%rsp)
   1407d4b28:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4b2f:	00 00 
   1407d4b31:	83 fb 10             	cmp    $0x10,%ebx
   1407d4b34:	0f 87 96 03 00 00    	ja     0x1407d4ed0
   1407d4b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407d4b40:	83 fb 02             	cmp    $0x2,%ebx
   1407d4b43:	0f 84 68 03 00 00    	je     0x1407d4eb1
   1407d4b49:	83 fb 0f             	cmp    $0xf,%ebx
   1407d4b4c:	74 1d                	je     0x1407d4b6b
   1407d4b4e:	83 fb 10             	cmp    $0x10,%ebx
   1407d4b51:	0f 85 d1 03 00 00    	jne    0x1407d4f28
   1407d4b57:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4b5e:	00 00 
   1407d4b60:	31 c0                	xor    %eax,%eax
   1407d4b62:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4b69:	5d                   	pop    %rbp
   1407d4b6a:	c3                   	ret
   1407d4b6b:	b8 48 00 00 00       	mov    $0x48,%eax
   1407d4b70:	48 8d 1d 41 0b c0 00 	lea    0xc00b41(%rip),%rbx        # 0x1413d56b8
   1407d4b77:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4b7c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407d4b80:	e8 bb 00 85 ff       	call   0x140024c40
   1407d4b85:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   1407d4b8c:	00 
   1407d4b8d:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   1407d4b94:	00 
   1407d4b95:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d4b9a:	48 8d 1d a7 9c ae 00 	lea    0xae9ca7(%rip),%rbx        # 0x1412be848
   1407d4ba1:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4ba6:	e8 b5 f4 84 ff       	call   0x140024060
   1407d4bab:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   1407d4bb2:	00 
   1407d4bb3:	48 89 10             	mov    %rdx,(%rax)
   1407d4bb6:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   1407d4bbd:	00 
   1407d4bbe:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d4bc2:	48 8b 15 7f 63 21 04 	mov    0x421637f(%rip),%rdx        # 0x1449eaf48
   1407d4bc9:	48 8d 1d d4 7b 0b 00 	lea    0xb7bd4(%rip),%rbx        # 0x14088c7a4
   1407d4bd0:	b9 0a 00 00 00       	mov    $0xa,%ecx
   1407d4bd5:	48 89 c7             	mov    %rax,%rdi
   1407d4bd8:	be 02 00 00 00       	mov    $0x2,%esi
   1407d4bdd:	41 89 f0             	mov    %esi,%r8d
   1407d4be0:	48 89 d0             	mov    %rdx,%rax
   1407d4be3:	e8 b8 4d fc ff       	call   0x1407999a0
   1407d4be8:	48 85 c0             	test   %rax,%rax
   1407d4beb:	75 14                	jne    0x1407d4c01
   1407d4bed:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4bf4:	00 00 
   1407d4bf6:	31 c0                	xor    %eax,%eax
   1407d4bf8:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4bff:	5d                   	pop    %rbp
   1407d4c00:	c3                   	ret
   1407d4c01:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   1407d4c06:	48 8b 15 3b 63 21 04 	mov    0x421633b(%rip),%rdx        # 0x1449eaf48
   1407d4c0d:	4c 8d 0d 2c 9c 02 00 	lea    0x29c2c(%rip),%r9        # 0x1407fe840
   1407d4c14:	4c 89 4c 24 58       	mov    %r9,0x58(%rsp)
   1407d4c19:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   1407d4c1e:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   1407d4c25:	00 
   1407d4c26:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   1407d4c2b:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   1407d4c32:	00 
   1407d4c33:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
   1407d4c38:	48 8d 54 24 58       	lea    0x58(%rsp),%rdx
   1407d4c3d:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
   1407d4c44:	00 
   1407d4c45:	c6 44 24 37 01       	movb   $0x1,0x37(%rsp)
   1407d4c4a:	8b 3d 78 07 2c 04    	mov    0x42c0778(%rip),%edi        # 0x144a953c8
   1407d4c50:	8b 35 76 07 2c 04    	mov    0x42c0776(%rip),%esi        # 0x144a953cc
   1407d4c56:	31 db                	xor    %ebx,%ebx
   1407d4c58:	89 d9                	mov    %ebx,%ecx
   1407d4c5a:	41 b8 4f 66 e7 00    	mov    $0xe7664f,%r8d
   1407d4c60:	e8 7b 8d ff ff       	call   0x1407cd9e0
   1407d4c65:	f2 0f 10 05 33 ca c4 	movsd  0xc4ca33(%rip),%xmm0        # 0x1414216a0
   1407d4c6c:	00 
   1407d4c6d:	48 8d 05 1f 22 0b 00 	lea    0xb221f(%rip),%rax        # 0x140886e93
   1407d4c74:	bb 07 00 00 00       	mov    $0x7,%ebx
   1407d4c79:	e8 62 64 ff ff       	call   0x1407cb0e0
   1407d4c7e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   1407d4c83:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d4c88:	48 8d 1d b9 9b ae 00 	lea    0xae9bb9(%rip),%rbx        # 0x1412be848
   1407d4c8f:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4c94:	e8 c7 f3 84 ff       	call   0x140024060
   1407d4c99:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d4c9e:	48 89 10             	mov    %rdx,(%rax)
   1407d4ca1:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   1407d4ca6:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d4caa:	48 8b 15 a7 62 21 04 	mov    0x42162a7(%rip),%rdx        # 0x1449eaf58
   1407d4cb1:	48 8d 1d df aa 0b 00 	lea    0xbaadf(%rip),%rbx        # 0x14088f797
   1407d4cb8:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d4cbd:	48 89 c7             	mov    %rax,%rdi
   1407d4cc0:	be 02 00 00 00       	mov    $0x2,%esi
   1407d4cc5:	41 89 f0             	mov    %esi,%r8d
   1407d4cc8:	48 89 d0             	mov    %rdx,%rax
   1407d4ccb:	e8 d0 4c fc ff       	call   0x1407999a0
   1407d4cd0:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   1407d4cd5:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d4cda:	48 8d 1d 67 9b ae 00 	lea    0xae9b67(%rip),%rbx        # 0x1412be848
   1407d4ce1:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4ce6:	e8 75 f3 84 ff       	call   0x140024060
   1407d4ceb:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d4cf0:	48 89 10             	mov    %rdx,(%rax)
   1407d4cf3:	48 c7 40 08 ff ff ff 	movq   $0xffffff,0x8(%rax)
   1407d4cfa:	00 
   1407d4cfb:	48 8b 15 56 62 21 04 	mov    0x4216256(%rip),%rdx        # 0x1449eaf58
   1407d4d02:	48 8d 1d 9a aa 0b 00 	lea    0xbaa9a(%rip),%rbx        # 0x14088f7a3
   1407d4d09:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d4d0e:	48 89 c7             	mov    %rax,%rdi
   1407d4d11:	be 02 00 00 00       	mov    $0x2,%esi
   1407d4d16:	41 89 f0             	mov    %esi,%r8d
   1407d4d19:	48 89 d0             	mov    %rdx,%rax
   1407d4d1c:	0f 1f 40 00          	nopl   0x0(%rax)
   1407d4d20:	e8 7b 4c fc ff       	call   0x1407999a0
   1407d4d25:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d4d2a:	48 8d 1d 17 9b ae 00 	lea    0xae9b17(%rip),%rbx        # 0x1412be848
   1407d4d31:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4d36:	e8 25 f3 84 ff       	call   0x140024060
   1407d4d3b:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d4d40:	48 89 10             	mov    %rdx,(%rax)
   1407d4d43:	48 c7 40 08 01 00 00 	movq   $0x1,0x8(%rax)
   1407d4d4a:	00 
   1407d4d4b:	48 8b 15 06 62 21 04 	mov    0x4216206(%rip),%rdx        # 0x1449eaf58
   1407d4d52:	48 8d 1d 3c 5e 0b 00 	lea    0xb5e3c(%rip),%rbx        # 0x14088ab95
   1407d4d59:	b9 09 00 00 00       	mov    $0x9,%ecx
   1407d4d5e:	48 89 c7             	mov    %rax,%rdi
   1407d4d61:	be 02 00 00 00       	mov    $0x2,%esi
   1407d4d66:	41 89 f0             	mov    %esi,%r8d
   1407d4d69:	48 89 d0             	mov    %rdx,%rax
   1407d4d6c:	e8 2f 4c fc ff       	call   0x1407999a0
   1407d4d71:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d4d76:	48 8d 1d 5b 5d be 00 	lea    0xbe5d5b(%rip),%rbx        # 0x1413baad8
   1407d4d7d:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4d82:	e8 d9 f2 84 ff       	call   0x140024060
   1407d4d87:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   1407d4d8e:	00 
   1407d4d8f:	8b 15 33 06 2c 04    	mov    0x42c0633(%rip),%edx        # 0x144a953c8
   1407d4d95:	44 8b 0d 30 06 2c 04 	mov    0x42c0630(%rip),%r9d        # 0x144a953cc
   1407d4d9c:	89 50 08             	mov    %edx,0x8(%rax)
   1407d4d9f:	44 89 48 0c          	mov    %r9d,0xc(%rax)
   1407d4da3:	48 8b 05 e6 06 2c 04 	mov    0x42c06e6(%rip),%rax        # 0x144a95490
   1407d4daa:	90                   	nop
   1407d4dab:	bb 0a 00 00 00       	mov    $0xa,%ebx
   1407d4db0:	e8 4b fe 83 ff       	call   0x140014c00
   1407d4db5:	e8 66 4b fc ff       	call   0x140799920
   1407d4dba:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   1407d4dc1:	00 
   1407d4dc2:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
   1407d4dc9:	00 
   1407d4dca:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   1407d4dcf:	b8 28 00 00 00       	mov    $0x28,%eax
   1407d4dd4:	48 8d 1d ed b0 ae 00 	lea    0xaeb0ed(%rip),%rbx        # 0x1412bfec8
   1407d4ddb:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4de0:	e8 9b f9 84 ff       	call   0x140024780
   1407d4de5:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d4dea:	48 89 10             	mov    %rdx,(%rax)
   1407d4ded:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1407d4df4:	00 
   1407d4df5:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d4df9:	48 c7 40 10 ff ff ff 	movq   $0xffffffffffffffff,0x10(%rax)
   1407d4e00:	ff 
   1407d4e01:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1407d4e06:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407d4e0a:	48 c7 40 20 25 08 00 	movq   $0x825,0x20(%rax)
   1407d4e11:	00 
   1407d4e12:	48 8b 15 2f 61 21 04 	mov    0x421612f(%rip),%rdx        # 0x1449eaf48
   1407d4e19:	48 8d 1d 7e 5d 0b 00 	lea    0xb5d7e(%rip),%rbx        # 0x14088ab9e
   1407d4e20:	b9 09 00 00 00       	mov    $0x9,%ecx
   1407d4e25:	48 89 c7             	mov    %rax,%rdi
   1407d4e28:	be 05 00 00 00       	mov    $0x5,%esi
   1407d4e2d:	41 89 f0             	mov    %esi,%r8d
   1407d4e30:	48 89 d0             	mov    %rdx,%rax
   1407d4e33:	e8 68 4b fc ff       	call   0x1407999a0
   1407d4e38:	b8 10 00 00 00       	mov    $0x10,%eax
   1407d4e3d:	48 8d 1d 04 9a ae 00 	lea    0xae9a04(%rip),%rbx        # 0x1412be848
   1407d4e44:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4e49:	e8 12 f2 84 ff       	call   0x140024060
   1407d4e4e:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   1407d4e53:	48 89 10             	mov    %rdx,(%rax)
   1407d4e56:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407d4e5b:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d4e5f:	48 8b 15 f2 60 21 04 	mov    0x42160f2(%rip),%rdx        # 0x1449eaf58
   1407d4e66:	48 8d 1d 2a a9 0b 00 	lea    0xba92a(%rip),%rbx        # 0x14088f797
   1407d4e6d:	b9 0c 00 00 00       	mov    $0xc,%ecx
   1407d4e72:	48 89 c7             	mov    %rax,%rdi
   1407d4e75:	be 02 00 00 00       	mov    $0x2,%esi
   1407d4e7a:	41 89 f0             	mov    %esi,%r8d
   1407d4e7d:	48 89 d0             	mov    %rdx,%rax
   1407d4e80:	e8 1b 4b fc ff       	call   0x1407999a0
   1407d4e85:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4e8c:	00 00 
   1407d4e8e:	c6 44 24 37 00       	movb   $0x0,0x37(%rsp)
   1407d4e93:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   1407d4e9a:	00 
   1407d4e9b:	4c 8b 0a             	mov    (%rdx),%r9
   1407d4e9e:	66 90                	xchg   %ax,%ax
   1407d4ea0:	41 ff d1             	call   *%r9
   1407d4ea3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1407d4ea8:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4eaf:	5d                   	pop    %rbp
   1407d4eb0:	c3                   	ret
   1407d4eb1:	48 c7 05 cc 05 2c 04 	movq   $0x0,0x42c05cc(%rip)        # 0x144a95488
   1407d4eb8:	00 00 00 00 
   1407d4ebc:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4ec3:	00 00 
   1407d4ec5:	31 c0                	xor    %eax,%eax
   1407d4ec7:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4ece:	5d                   	pop    %rbp
   1407d4ecf:	c3                   	ret
   1407d4ed0:	83 fb 21             	cmp    $0x21,%ebx
   1407d4ed3:	77 38                	ja     0x1407d4f0d
   1407d4ed5:	83 fb 14             	cmp    $0x14,%ebx
   1407d4ed8:	74 1c                	je     0x1407d4ef6
   1407d4eda:	83 fb 21             	cmp    $0x21,%ebx
   1407d4edd:	75 49                	jne    0x1407d4f28
   1407d4edf:	48 c7 44 24 38 03 00 	movq   $0x3,0x38(%rsp)
   1407d4ee6:	00 00 
   1407d4ee8:	b8 03 00 00 00       	mov    $0x3,%eax
   1407d4eed:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4ef4:	5d                   	pop    %rbp
   1407d4ef5:	c3                   	ret
   1407d4ef6:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   1407d4efd:	00 00 
   1407d4eff:	b8 01 00 00 00       	mov    $0x1,%eax
   1407d4f04:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4f0b:	5d                   	pop    %rbp
   1407d4f0c:	c3                   	ret
   1407d4f0d:	81 fb 02 02 00 00    	cmp    $0x202,%ebx
   1407d4f13:	0f 84 a7 00 00 00    	je     0x1407d4fc0
   1407d4f19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407d4f20:	81 fb 05 02 00 00    	cmp    $0x205,%ebx
   1407d4f26:	74 7a                	je     0x1407d4fa2
   1407d4f28:	b8 20 00 00 00       	mov    $0x20,%eax
   1407d4f2d:	48 8d 1d ac a9 ae 00 	lea    0xaea9ac(%rip),%rbx        # 0x1412bf8e0
   1407d4f34:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407d4f39:	e8 e2 f5 84 ff       	call   0x140024520
   1407d4f3e:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   1407d4f45:	00 
   1407d4f46:	48 89 10             	mov    %rdx,(%rax)
   1407d4f49:	8b 94 24 c0 00 00 00 	mov    0xc0(%rsp),%edx
   1407d4f50:	89 d2                	mov    %edx,%edx
   1407d4f52:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407d4f56:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
   1407d4f5d:	00 
   1407d4f5e:	48 89 50 10          	mov    %rdx,0x10(%rax)
   1407d4f62:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
   1407d4f69:	00 
   1407d4f6a:	48 89 50 18          	mov    %rdx,0x18(%rax)
   1407d4f6e:	48 8b 15 d3 5f 21 04 	mov    0x4215fd3(%rip),%rdx        # 0x1449eaf48
   1407d4f75:	48 8d 1d e2 d6 0b 00 	lea    0xbd6e2(%rip),%rbx        # 0x14089265e
   1407d4f7c:	b9 0e 00 00 00       	mov    $0xe,%ecx
   1407d4f81:	48 89 c7             	mov    %rax,%rdi
   1407d4f84:	be 04 00 00 00       	mov    $0x4,%esi
   1407d4f89:	41 89 f0             	mov    %esi,%r8d
   1407d4f8c:	48 89 d0             	mov    %rdx,%rax
   1407d4f8f:	e8 0c 4a fc ff       	call   0x1407999a0
   1407d4f94:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   1407d4f99:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4fa0:	5d                   	pop    %rbp
   1407d4fa1:	c3                   	ret
   1407d4fa2:	e8 39 fa ff ff       	call   0x1407d49e0
   1407d4fa7:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4fae:	00 00 
   1407d4fb0:	31 c0                	xor    %eax,%eax
   1407d4fb2:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4fb9:	5d                   	pop    %rbp
   1407d4fba:	c3                   	ret
   1407d4fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407d4fc0:	e8 9b f8 ff ff       	call   0x1407d4860
   1407d4fc5:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   1407d4fcc:	00 00 
   1407d4fce:	31 c0                	xor    %eax,%eax
   1407d4fd0:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4fd7:	5d                   	pop    %rbp
   1407d4fd8:	c3                   	ret
   1407d4fd9:	e8 a2 95 87 ff       	call   0x14004e580
   1407d4fde:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1407d4fe3:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   1407d4fea:	5d                   	pop    %rbp
   1407d4feb:	c3                   	ret
   1407d4fec:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1407d4ff1:	89 5c 24 10          	mov    %ebx,0x10(%rsp)
   1407d4ff5:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   1407d4ffa:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   1407d4fff:	90                   	nop
   1407d5000:	e8 3b 73 8b ff       	call   0x14008c340
   1407d5005:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1407d500a:	8b 5c 24 10          	mov    0x10(%rsp),%ebx
   1407d500e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   1407d5013:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   1407d5018:	e9 c3 fa ff ff       	jmp    0x1407d4ae0
   1407d501d:	cc                   	int3
   1407d501e:	cc                   	int3
   1407d501f:	cc                   	int3

# main.paintToast.func1 @ 0x1407fd480
   1407fd480:	48 8b 52 08          	mov    0x8(%rdx),%rdx
   1407fd484:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407fd487:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   1407fd48c:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407fd493:	00 
   1407fd494:	66 48 0f 7e c6       	movq   %xmm0,%rsi
   1407fd499:	49 89 f0             	mov    %rsi,%r8
   1407fd49c:	48 c1 ee 34          	shr    $0x34,%rsi
   1407fd4a0:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407fd4a6:	90                   	nop
   1407fd4a7:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407fd4ae:	73 30                	jae    0x1407fd4e0
   1407fd4b0:	49 b9 00 00 00 00 00 	movabs $0x8000000000000000,%r9
   1407fd4b7:	00 00 80 
   1407fd4ba:	4d 21 c8             	and    %r9,%r8
   1407fd4bd:	49 ba 00 00 00 00 00 	movabs $0x3ff0000000000000,%r10
   1407fd4c4:	00 f0 3f 
   1407fd4c7:	4d 09 c2             	or     %r8,%r10
   1407fd4ca:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407fd4d1:	4d 0f 44 c2          	cmove  %r10,%r8
   1407fd4d5:	48 89 ce             	mov    %rcx,%rsi
   1407fd4d8:	eb 44                	jmp    0x1407fd51e
   1407fd4da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1407fd4e0:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407fd4e7:	73 32                	jae    0x1407fd51b
   1407fd4e9:	4c 8d 8e 01 fc ff ff 	lea    -0x3ff(%rsi),%r9
   1407fd4f0:	48 89 ce             	mov    %rcx,%rsi
   1407fd4f3:	4c 89 c9             	mov    %r9,%rcx
   1407fd4f6:	49 ba 00 00 00 00 00 	movabs $0x8000000000000,%r10
   1407fd4fd:	00 08 00 
   1407fd500:	49 d3 ea             	shr    %cl,%r10
   1407fd503:	4d 01 d0             	add    %r10,%r8
   1407fd506:	49 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%r10
   1407fd50d:	ff 0f 00 
   1407fd510:	49 d3 ea             	shr    %cl,%r10
   1407fd513:	49 f7 d2             	not    %r10
   1407fd516:	4d 21 d0             	and    %r10,%r8
   1407fd519:	eb 03                	jmp    0x1407fd51e
   1407fd51b:	48 89 ce             	mov    %rcx,%rsi
   1407fd51e:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407fd521:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
   1407fd526:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407fd52d:	00 
   1407fd52e:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407fd533:	49 89 c9             	mov    %rcx,%r9
   1407fd536:	49 c1 e9 34          	shr    $0x34,%r9
   1407fd53a:	41 81 e1 ff 07 00 00 	and    $0x7ff,%r9d
   1407fd541:	90                   	nop
   1407fd542:	90                   	nop
   1407fd543:	49 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9
   1407fd54a:	73 2a                	jae    0x1407fd576
   1407fd54c:	49 ba 00 00 00 00 00 	movabs $0x8000000000000000,%r10
   1407fd553:	00 00 80 
   1407fd556:	4c 21 d1             	and    %r10,%rcx
   1407fd559:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407fd560:	00 f0 3f 
   1407fd563:	49 09 cb             	or     %rcx,%r11
   1407fd566:	49 81 f9 fe 03 00 00 	cmp    $0x3fe,%r9
   1407fd56d:	49 0f 44 cb          	cmove  %r11,%rcx
   1407fd571:	49 89 ca             	mov    %rcx,%r10
   1407fd574:	eb 3e                	jmp    0x1407fd5b4
   1407fd576:	49 81 f9 33 04 00 00 	cmp    $0x433,%r9
   1407fd57d:	73 32                	jae    0x1407fd5b1
   1407fd57f:	49 81 c1 01 fc ff ff 	add    $0xfffffffffffffc01,%r9
   1407fd586:	49 89 ca             	mov    %rcx,%r10
   1407fd589:	4c 89 c9             	mov    %r9,%rcx
   1407fd58c:	49 bb 00 00 00 00 00 	movabs $0x8000000000000,%r11
   1407fd593:	00 08 00 
   1407fd596:	49 d3 eb             	shr    %cl,%r11
   1407fd599:	4d 01 da             	add    %r11,%r10
   1407fd59c:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407fd5a3:	ff 0f 00 
   1407fd5a6:	49 d3 eb             	shr    %cl,%r11
   1407fd5a9:	49 f7 d3             	not    %r11
   1407fd5ac:	4d 21 da             	and    %r11,%r10
   1407fd5af:	eb 03                	jmp    0x1407fd5b4
   1407fd5b1:	49 89 ca             	mov    %rcx,%r10
   1407fd5b4:	48 01 c6             	add    %rax,%rsi
   1407fd5b7:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407fd5ba:	f2 48 0f 2a c6       	cvtsi2sd %rsi,%xmm0
   1407fd5bf:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407fd5c6:	00 
   1407fd5c7:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407fd5cc:	48 89 ce             	mov    %rcx,%rsi
   1407fd5cf:	48 c1 ee 34          	shr    $0x34,%rsi
   1407fd5d3:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
   1407fd5d9:	90                   	nop
   1407fd5da:	90                   	nop
   1407fd5db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1407fd5e0:	48 81 fe ff 03 00 00 	cmp    $0x3ff,%rsi
   1407fd5e7:	73 2a                	jae    0x1407fd613
   1407fd5e9:	49 b9 00 00 00 00 00 	movabs $0x8000000000000000,%r9
   1407fd5f0:	00 00 80 
   1407fd5f3:	4c 21 c9             	and    %r9,%rcx
   1407fd5f6:	49 bb 00 00 00 00 00 	movabs $0x3ff0000000000000,%r11
   1407fd5fd:	00 f0 3f 
   1407fd600:	49 09 cb             	or     %rcx,%r11
   1407fd603:	48 81 fe fe 03 00 00 	cmp    $0x3fe,%rsi
   1407fd60a:	49 0f 44 cb          	cmove  %r11,%rcx
   1407fd60e:	49 89 c9             	mov    %rcx,%r9
   1407fd611:	eb 3e                	jmp    0x1407fd651
   1407fd613:	48 81 fe 33 04 00 00 	cmp    $0x433,%rsi
   1407fd61a:	73 32                	jae    0x1407fd64e
   1407fd61c:	48 81 c6 01 fc ff ff 	add    $0xfffffffffffffc01,%rsi
   1407fd623:	48 89 c8             	mov    %rcx,%rax
   1407fd626:	48 89 f1             	mov    %rsi,%rcx
   1407fd629:	49 b9 00 00 00 00 00 	movabs $0x8000000000000,%r9
   1407fd630:	00 08 00 
   1407fd633:	49 d3 e9             	shr    %cl,%r9
   1407fd636:	49 01 c1             	add    %rax,%r9
   1407fd639:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407fd640:	ff 0f 00 
   1407fd643:	49 d3 eb             	shr    %cl,%r11
   1407fd646:	49 f7 d3             	not    %r11
   1407fd649:	4d 21 d9             	and    %r11,%r9
   1407fd64c:	eb 03                	jmp    0x1407fd651
   1407fd64e:	49 89 c9             	mov    %rcx,%r9
   1407fd651:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
   1407fd655:	0f 57 c0             	xorps  %xmm0,%xmm0
   1407fd658:	f2 48 0f 2a c6       	cvtsi2sd %rsi,%xmm0
   1407fd65d:	f2 0f 59 82 b8 00 00 	mulsd  0xb8(%rdx),%xmm0
   1407fd664:	00 
   1407fd665:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   1407fd66a:	48 89 ca             	mov    %rcx,%rdx
   1407fd66d:	48 c1 ea 34          	shr    $0x34,%rdx
   1407fd671:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
   1407fd677:	90                   	nop
   1407fd678:	90                   	nop
   1407fd679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1407fd680:	48 81 fa ff 03 00 00 	cmp    $0x3ff,%rdx
   1407fd687:	73 2a                	jae    0x1407fd6b3
   1407fd689:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
   1407fd690:	00 00 80 
   1407fd693:	48 21 f1             	and    %rsi,%rcx
   1407fd696:	48 be 00 00 00 00 00 	movabs $0x3ff0000000000000,%rsi
   1407fd69d:	00 f0 3f 
   1407fd6a0:	48 09 ce             	or     %rcx,%rsi
   1407fd6a3:	48 81 fa fe 03 00 00 	cmp    $0x3fe,%rdx
   1407fd6aa:	48 0f 44 ce          	cmove  %rsi,%rcx
   1407fd6ae:	48 89 ce             	mov    %rcx,%rsi
   1407fd6b1:	eb 3e                	jmp    0x1407fd6f1
   1407fd6b3:	48 81 fa 33 04 00 00 	cmp    $0x433,%rdx
   1407fd6ba:	73 32                	jae    0x1407fd6ee
   1407fd6bc:	48 81 c2 01 fc ff ff 	add    $0xfffffffffffffc01,%rdx
   1407fd6c3:	48 89 c8             	mov    %rcx,%rax
   1407fd6c6:	48 89 d1             	mov    %rdx,%rcx
   1407fd6c9:	48 be 00 00 00 00 00 	movabs $0x8000000000000,%rsi
   1407fd6d0:	00 08 00 
   1407fd6d3:	48 d3 ee             	shr    %cl,%rsi
   1407fd6d6:	48 01 c6             	add    %rax,%rsi
   1407fd6d9:	49 bb ff ff ff ff ff 	movabs $0xfffffffffffff,%r11
   1407fd6e0:	ff 0f 00 
   1407fd6e3:	49 d3 eb             	shr    %cl,%r11
   1407fd6e6:	49 f7 d3             	not    %r11
   1407fd6e9:	4c 21 de             	and    %r11,%rsi
   1407fd6ec:	eb 03                	jmp    0x1407fd6f1
   1407fd6ee:	48 89 ce             	mov    %rcx,%rsi
   1407fd6f1:	66 49 0f 6e c0       	movq   %r8,%xmm0
   1407fd6f6:	f2 0f 2c c0          	cvttsd2si %xmm0,%eax
   1407fd6fa:	66 49 0f 6e c2       	movq   %r10,%xmm0
   1407fd6ff:	f2 0f 2c d8          	cvttsd2si %xmm0,%ebx
   1407fd703:	66 49 0f 6e c1       	movq   %r9,%xmm0
   1407fd708:	f2 0f 2c c8          	cvttsd2si %xmm0,%ecx
   1407fd70c:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   1407fd711:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
   1407fd715:	90                   	nop
   1407fd716:	c3                   	ret
   1407fd717:	cc                   	int3
   1407fd718:	cc                   	int3
   1407fd719:	cc                   	int3
   1407fd71a:	cc                   	int3
   1407fd71b:	cc                   	int3
   1407fd71c:	cc                   	int3
   1407fd71d:	cc                   	int3
   1407fd71e:	cc                   	int3
   1407fd71f:	cc                   	int3

# main.paintToast.deferwrap1 @ 0x1407fd720
   1407fd720:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407fd724:	76 71                	jbe    0x1407fd797
   1407fd726:	55                   	push   %rbp
   1407fd727:	48 89 e5             	mov    %rsp,%rbp
   1407fd72a:	48 83 ec 48          	sub    $0x48,%rsp
   1407fd72e:	48 8b 72 10          	mov    0x10(%rdx),%rsi
   1407fd732:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   1407fd737:	48 8b 72 18          	mov    0x18(%rdx),%rsi
   1407fd73b:	48 8b 52 08          	mov    0x8(%rdx),%rdx
   1407fd73f:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407fd744:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
   1407fd749:	b8 10 00 00 00       	mov    $0x10,%eax
   1407fd74e:	48 8d 1d f3 10 ac 00 	lea    0xac10f3(%rip),%rbx        # 0x1412be848
   1407fd755:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407fd75a:	e8 01 69 82 ff       	call   0x140024060
   1407fd75f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   1407fd764:	48 89 10             	mov    %rdx,(%rax)
   1407fd767:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407fd76c:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407fd770:	48 8d 1d 19 b6 08 00 	lea    0x8b619(%rip),%rbx        # 0x140888d90
   1407fd777:	b9 08 00 00 00       	mov    $0x8,%ecx
   1407fd77c:	48 89 c7             	mov    %rax,%rdi
   1407fd77f:	be 02 00 00 00       	mov    $0x2,%esi
   1407fd784:	41 89 f0             	mov    %esi,%r8d
   1407fd787:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1407fd78c:	e8 0f c2 f9 ff       	call   0x1407999a0
   1407fd791:	48 83 c4 48          	add    $0x48,%rsp
   1407fd795:	5d                   	pop    %rbp
   1407fd796:	c3                   	ret
   1407fd797:	e8 24 eb 88 ff       	call   0x14008c2c0
   1407fd79c:	eb 82                	jmp    0x1407fd720
   1407fd79e:	cc                   	int3
   1407fd79f:	cc                   	int3

# main.unreadBadgeProc.deferwrap1 @ 0x1407fe840
   1407fe840:	49 3b 66 10          	cmp    0x10(%r14),%rsp
   1407fe844:	76 71                	jbe    0x1407fe8b7
   1407fe846:	55                   	push   %rbp
   1407fe847:	48 89 e5             	mov    %rsp,%rbp
   1407fe84a:	48 83 ec 48          	sub    $0x48,%rsp
   1407fe84e:	48 8b 72 10          	mov    0x10(%rdx),%rsi
   1407fe852:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   1407fe857:	48 8b 72 18          	mov    0x18(%rdx),%rsi
   1407fe85b:	48 8b 52 08          	mov    0x8(%rdx),%rdx
   1407fe85f:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   1407fe864:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
   1407fe869:	b8 10 00 00 00       	mov    $0x10,%eax
   1407fe86e:	48 8d 1d d3 ff ab 00 	lea    0xabffd3(%rip),%rbx        # 0x1412be848
   1407fe875:	b9 01 00 00 00       	mov    $0x1,%ecx
   1407fe87a:	e8 e1 57 82 ff       	call   0x140024060
   1407fe87f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   1407fe884:	48 89 10             	mov    %rdx,(%rax)
   1407fe887:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   1407fe88c:	48 89 50 08          	mov    %rdx,0x8(%rax)
   1407fe890:	48 8d 1d f9 a4 08 00 	lea    0x8a4f9(%rip),%rbx        # 0x140888d90
   1407fe897:	b9 08 00 00 00       	mov    $0x8,%ecx
   1407fe89c:	48 89 c7             	mov    %rax,%rdi
   1407fe89f:	be 02 00 00 00       	mov    $0x2,%esi
   1407fe8a4:	41 89 f0             	mov    %esi,%r8d
   1407fe8a7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1407fe8ac:	e8 ef b0 f9 ff       	call   0x1407999a0
   1407fe8b1:	48 83 c4 48          	add    $0x48,%rsp
   1407fe8b5:	5d                   	pop    %rbp
   1407fe8b6:	c3                   	ret
   1407fe8b7:	e8 04 da 88 ff       	call   0x14008c2c0
   1407fe8bc:	eb 82                	jmp    0x1407fe840
   1407fe8be:	cc                   	int3
   1407fe8bf:	cc                   	int3

